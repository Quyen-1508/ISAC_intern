function build_p3_bin_figure(bins,KE,dataDir)
%BUILD_P3_BIN_FIGURE Pd and RMSE versus target power from P3 summary files.
%   Reads the compact P3_B<bin>_K<K>_E<E>.mat summaries. One figure per range
%   bin, one column per (K,E), three rows:
%
%     Pd (associated) versus target power   -- full sweep, from PdPowerSweep
%     range RMSE   (bins)                    -- NOMINAL POWER ONLY
%     Doppler RMSE (bins)                    -- NOMINAL POWER ONLY
%
%   THE P3 SUMMARIES CARRY NO RMSE SWEEP. They hold RangeRMSEm and
%   DopplerRMSEHz as one value per method at 0 dB. The full per-power RMSE
%   lives in the source result file named by S.ResultFile, which was written
%   on the machine that produced the summary and is not part of the summary.
%   The two RMSE rows therefore show a single point at 0 dB on the same
%   target-power axis, so the gap is visible rather than hidden.
%
%   Method order is Full, Block-4, Block-8. That is asserted from Speedup,
%   whose first entry must be exactly 1 for the Full reference.
%
%   build_p3_bin_figure([160 164 165])

if nargin<1 || isempty(bins), bins=[160 164 165]; end
if nargin<2 || isempty(KE), KE=[64 2; 64 4; 96 2; 96 4]; end
if nargin<3 || isempty(dataDir), dataDir='results/Data'; end
names={'Full sliding NSCM-ACE','Block-4 NSCM-ACE','Block-8 NSCM-ACE'};
styles={'--o','-s','-^'};
cols=[0.10 0.45 0.95; 0.85 0.33 0.10; 0.93 0.69 0.13];
rb=3.154382; db=25;
nC=size(KE,1);

for b=bins
    S=cell(1,nC);
    for c=1:nC
        f=fullfile(dataDir,sprintf('P3_B%d_K%d_E%d.mat',b,KE(c,1),KE(c,2)));
        assert(isfile(f),'Case2:p3Missing','No P3 summary at %s.',f);
        S{c}=load(f).S;
        assert(S{c}.InvariantsOK,'Case2:p3Invariants', ...
            '%s failed its own invariant checks; not plotting it.',f);
        assert(abs(S{c}.Speedup(1)-1)<1e-9,'Case2:p3MethodOrder', ...
            '%s: Speedup(1)=%.4f, so row 1 is not the Full reference.',f,S{c}.Speedup(1));
    end
    off=S{1}.TargetPowerOffsetDB(:).';
    for c=2:nC
        assert(isequal(S{c}.TargetPowerOffsetDB(:).',off),'Case2:p3PowerGrid', ...
            'Bin %d: configurations swept on different power grids.',b);
    end
    chk=S{1}.Checks;
    tr=chk.Measured(strcmp(chk.Quantity,'TruthRangeM'));
    fd=chk.Measured(strcmp(chk.Quantity,'TruthDopplerHz'));

    fh=figure('Color','w','Position',[50 40 1400 820]);
    tl=tiledlayout(fh,3,nC,'TileSpacing','compact','Padding','compact');
    limX=[min(off)-1.5 max(off)+1.5];
    for row=1:3
        for c=1:nC
            s=S{c};
            ax=nexttile(tl,(row-1)*nC+c); hold(ax,'on'); grid(ax,'on');
            for m=1:3
                switch row
                    case 1
                        plot(ax,off,s.PdPowerSweep(m,:),styles{m},'Color',cols(m,:), ...
                            'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor',cols(m,:));
                        plot(ax,0,s.PdAssociated(m),'o','Color',cols(m,:), ...
                            'MarkerSize',11,'LineWidth',1.3,'HandleVisibility','off');
                    case 2
                        plot(ax,0,s.RangeRMSEm(m)/rb,styles{m}(end),'Color',cols(m,:), ...
                            'MarkerSize',8,'MarkerFaceColor',cols(m,:));
                    case 3
                        plot(ax,0,s.DopplerRMSEHz(m)/db,styles{m}(end),'Color',cols(m,:), ...
                            'MarkerSize',8,'MarkerFaceColor',cols(m,:));
                end
            end
            xlim(ax,limX); xticks(ax,off);
            switch row
                case 1
                    ylim(ax,[0 1.05]); yline(ax,1,':','HandleVisibility','off');
                    title(ax,sprintf('K = %d,  E = %d   |   %d CUT',KE(c,1),KE(c,2), ...
                        str2double(s.Checks.Measured(strcmp(s.Checks.Quantity, ...
                        'numel(SpatialCutIdxNative)')))),'FontWeight','bold');
                    if c==1, ylabel(ax,'P_D (associated)'); end
                case 2
                    ylim(ax,[0 1]); yline(ax,1,':','HandleVisibility','off');
                    if c==1, ylabel(ax,{'range RMSE (bins)','chi tai 0 dB'}); end
                case 3
                    ylim(ax,[0 1]); yline(ax,1,':','HandleVisibility','off');
                    if c==1, ylabel(ax,{'Doppler RMSE (bins)','chi tai 0 dB'}); end
                    xlabel(ax,'target power offset (dB)');
            end
            if row==1 && c==nC
                lg=legend(ax,names,'Orientation','horizontal','Interpreter','none');
                lg.Layout.Tile='north';
            end
        end
    end
    title(tl,sprintf('Range bin %d  |  truth %s m, %s Hz',b,tr,fd),'FontWeight','bold');

    figDir=fullfile('results',sprintf('figures_p3bin_%s',datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
    if ~exist(figDir,'dir'), mkdir(figDir); end
    out=fullfile(figDir,sprintf('figP3_B%d',b));
    exportgraphics(fh,[out '.png'],'Resolution',150); savefig(fh,[out '.fig']);
    fprintf('saved %s\n',out);

    fprintf('B%d  Pd sweep %s dB\n',b,mat2str(off));
    for c=1:nC
        s=S{c};
        fprintf('  (%d,%d)\n',KE(c,1),KE(c,2));
        for m=1:3
            fprintf('    %-22s %s | chinh %.4f | rng %.2e m | dop %.3f Hz\n',names{m}, ...
                num2str(s.PdPowerSweep(m,:),'%6.2f'),s.PdAssociated(m),s.RangeRMSEm(m),s.DopplerRMSEHz(m));
        end
    end
    pause(1);
end
end
