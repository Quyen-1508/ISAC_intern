function stat = helperACEWhitened(yw,SW)
%helperACEWhitened Adaptive coherence estimator in the whitened domain.
%   yw is the whitened test vector and SW the whitened steering matrix, both
%   already multiplied by inv(L). Keeping the formula here lets the block
%   detector whiten the steering matrix once per block and reuse it across
%   every CUT in that block without restating the statistic.

yEnergy = real(yw'*yw);
sEnergy = real(sum(conj(SW).*SW,1));
denom = sEnergy*yEnergy;
stat = abs(SW'*yw).'.^2 ./ max(denom,realmin(class(real(denom))));
stat = min(max(real(stat),0),1+100*eps(class(real(stat))));
end
