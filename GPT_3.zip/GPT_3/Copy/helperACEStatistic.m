function stat = helperACEStatistic(y,S,L)
%helperACEStatistic Adaptive coherence estimator from a Cholesky factor.
%   y is the Nchain test vector, S the Nchain-by-Nangle steering matrix and L
%   the lower Cholesky factor of the loaded covariance. Returns one statistic
%   per angle hypothesis in [0,1]. The statistic is invariant to a complex
%   scale on y and to the scale of each steering column.

stat = helperACEWhitened(L\y,L\S);
end
