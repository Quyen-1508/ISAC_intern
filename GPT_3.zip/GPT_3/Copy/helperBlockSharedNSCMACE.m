function [statMap, info] = helperBlockSharedNSCMACE(Z, cutIdx, steering, cfg)
%helperBlockSharedNSCMACE Block-shared, leakage-excluded NSCM-ACE.
%   Z is Nrange-by-Ndoppler-by-Nchain post-Doppler data, CUTIDX lists the
%   native range bins to test, STEERING is Nchain-by-Nangle and CFG carries
%   BlockSizeRangeBins, ExclusionBins and NumTrainingCells.
%
%   Consecutive CUTs are grouped into blocks of at most BlockSizeRangeBins.
%   Every CUT in a block shares one covariance estimate and one Cholesky
%   factor per Doppler bin, which reduces the number of covariance estimates
%   per map from NumCUT*NumDoppler to NumBlocks*NumDoppler. The whitened
%   steering matrix is also formed once per (block, Doppler).
%
%   The training geometry is
%       training | exclusion | CUT BLOCK | exclusion | training
%   so the whole block and ExclusionBins further bins on each side are kept
%   out of the covariance. In the production comparison E is fixed and shared
%   by every method; it is not inferred from a target-relative PSF threshold.
%   Separate diagnostics quantify whether signal-in-training materially changes
%   the loaded covariance or ACE statistic. The rule uses no target truth.
%
%   Block sharing applies to the covariance only. Each ACE statistic is still
%   formed from a single range bin at a single Doppler bin across the RF-chain
%   dimension; range bins are never summed or averaged into a CUT vector.

validateattributes(Z,{'single','double'},{'nonempty'});
assert(ndims(Z)==3,'Case2:blockSharedDims','Z must be Nrange-by-Ndoppler-by-Nchain.');
validateattributes(cutIdx,{'numeric'},{'vector','integer','positive'});
assert(isfield(cfg,'BlockSizeRangeBins') && isfield(cfg,'ExclusionBins') && ...
       isfield(cfg,'NumTrainingCells'), 'Case2:blockSharedCfg', ...
    'cfg needs BlockSizeRangeBins, ExclusionBins and NumTrainingCells.');

[nRange,nDop,nChain] = size(Z);
cutIdx = cutIdx(:);
nCut = numel(cutIdx);
assert(nCut>=1,'Case2:blockSharedNoCut','At least one CUT is required.');
assert(all(diff(cutIdx)==1),'Case2:blockSharedCutNotContiguous', ...
    ['CUT indices must be consecutive native range bins so that a block ' ...
     'occupies one contiguous exclusion span.']);

S = steering;
if isvector(S), S = S(:); end
assert(size(S,1)==nChain,'Case2:blockSharedSteering', ...
    'Steering has %d rows; data have %d chains.',size(S,1),nChain);
for ia = 1:size(S,2)
    S(:,ia) = S(:,ia)/max(norm(S(:,ia)),realmin(class(real(S))));
end
nAng = size(S,2);

B = round(cfg.BlockSizeRangeBins);
E = round(cfg.ExclusionBins);
K = round(cfg.NumTrainingCells);
assert(B>=1,'Case2:blockSharedBlockSize','BlockSizeRangeBins must be >= 1.');
assert(E>=0,'Case2:blockSharedExclusion','ExclusionBins must be >= 0.');
% K > Nchain keeps the sample covariance full rank. The RMB K >= 2*Nchain rule
% is a statistical-efficiency guideline, not a requirement, and this study runs
% below it on purpose, so it is reported by the caller rather than asserted.
% K > Nchain was a statistical rule of thumb, not an implementation
% requirement. helperNSCM normalises every snapshot to norm sqrt(N), so
% trace(M)=N and tau=1 for every K, and helperShrinkageLoading then adds
% lambda*tau*I with lambda>0. The loaded covariance is therefore positive
% definite at any K, which the Cholesky assert below still verifies. Small K
% costs conditioning, not validity, so it is reported through the condition
% number and loading diagnostics rather than forbidden here.
assert(mod(K,2)==0 && K>=2,'Case2:blockSharedK', ...
    'Need an even K >= 2. K=%d.',K);
halfK = K/2;

blockStart = 1:B:nCut;
nBlock = numel(blockStart);
blockIdOfCut = zeros(nCut,1);
trainingIdx = cell(1,nBlock);
for ib = 1:nBlock
    a = blockStart(ib);
    b = min(a+B-1,nCut);
    blockIdOfCut(a:b) = ib;
    lo = cutIdx(a); hi = cutIdx(b);
    left  = (lo-E-halfK):(lo-E-1);
    right = (hi+E+1):(hi+E+halfK);
    assert(left(1)>=1 && right(end)<=nRange,'Case2:blockSharedSupport', ...
        ['Block %d (native bins %d to %d) cannot support %d training cells ' ...
         'with %d exclusion bins. Restrict the CUT support instead of ' ...
         'shortening the window for edge blocks.'],ib,lo,hi,K,E);
    idx = [left right];
    assert(numel(idx)==K && numel(unique(idx))==K, ...
        'Case2:blockSharedTrainingCount','Training set is not %d distinct cells.',K);
    assert(~any(idx>=lo-E & idx<=hi+E),'Case2:blockSharedExclusionViolated', ...
        'A training cell falls inside the block or its exclusion zone.');
    trainingIdx{ib} = idx;
end

statMap = nan(nCut,nDop,nAng,'like',real(Z));
covFingerprint = nan(nBlock,nDop);
nCov = 0;
for ib = 1:nBlock
    a = blockStart(ib);
    b = min(a+B-1,nCut);
    idx = trainingIdx{ib};
    for iq = 1:nDop
        Ytr = reshape(Z(idx,iq,:),K,nChain).';
        L = localFactor_(helperShrinkageLoading(helperNSCM(Ytr),K));
        nCov = nCov+1;
        covFingerprint(ib,iq) = sum(real(diag(L)));
        SW = L\S;                       % whitened once for the whole block
        for ic = a:b
            yw = L\reshape(Z(cutIdx(ic),iq,:),nChain,1);
            statMap(ic,iq,:) = reshape(helperACEWhitened(yw,SW),1,1,[]);
        end
    end
end

assert(all(isfinite(statMap(:))),'Case2:blockSharedNonFinite', ...
    'The block-shared ACE map contains non-finite entries.');

info = struct();
info.Method = sprintf("Block-%d NSCM-ACE",B);
info.BlockSizeRangeBins = B;
info.ExclusionBins = E;
info.NumTrainingCells = K;
info.NumBlocks = nBlock;
info.NumCUT = nCut;
info.NumDoppler = nDop;
info.NumChains = nChain;
info.NumAngleHypotheses = nAng;
info.NumCovarianceEstimatesPerMap = nCov;
info.NumCholeskyFactorizationsPerMap = nCov;
info.CovarianceReuseFactor = (nCut*nDop)/nCov;
info.BlockIdOfCut = blockIdOfCut;
info.TrainingIdxPerBlock = trainingIdx;
info.CovarianceFingerprint = covFingerprint;
end

function L = localFactor_(M)
[L,p] = chol((M+M')/2,'lower');
assert(p==0,'Case2:blockSharedNotPD', ...
    'Shrinkage-loaded covariance is not positive definite.');
end
