function [gamma, info] = helperCalibrateMapThreshold(h0MapMax, targetPfaMap)
%helperCalibrateMapThreshold Empirical H0 threshold for map-level false alarm.
%   H0MAPMAX contains one scalar per target-free blind-search map: the maximum
%   detector statistic over every tested range, Doppler and angle hypothesis.
%   GAMMA is an order-statistic threshold chosen so no more than the requested
%   fraction of calibration maps exceed it when detections use statistic>GAMMA.
%
%   This calibration is deliberately performed independently for each
%   detector. It therefore accounts for different dependence structures, such
%   as several CUTs sharing one covariance matrix in a block detector.

validateattributes(h0MapMax,{'single','double'},{'real','finite','vector','nonempty'});
validateattributes(targetPfaMap,{'single','double'},{'real','finite','scalar','>',0,'<',1});
v=sort(double(h0MapMax(:)),'ascend');
n=numel(v);
nAllowed=floor(double(targetPfaMap)*n);
assert(nAllowed>=1,'Case2:mapThresholdTooFewCalibrationMaps', ...
    ['The requested Pfa_map %.4g permits fewer than one false-alarm map in %d ' ...
     'calibration maps. Increase the H0 calibration count or use a larger target.'], ...
    targetPfaMap,n);
orderIndex=n-nAllowed;
assert(orderIndex>=1 && orderIndex<=n,'Case2:mapThresholdOrderIndex', ...
    'Invalid empirical threshold order index %d for %d maps.',orderIndex,n);
gamma=v(orderIndex);
calPfa=mean(v>gamma);
assert(calPfa<=targetPfaMap+10*eps(max(1,targetPfaMap)), ...
    'Case2:mapThresholdCalibrationExceeded', ...
    'Calibration Pfa_map %.6g exceeded target %.6g.',calPfa,targetPfaMap);

info=struct();
info.TargetPfaMap=double(targetPfaMap);
info.NumCalibrationMaps=n;
info.AllowedFalseAlarmMaps=nAllowed;
info.OrderIndex=orderIndex;
info.CalibrationPfaMap=calPfa;
info.NumCalibrationExceedances=nnz(v>gamma);
end
