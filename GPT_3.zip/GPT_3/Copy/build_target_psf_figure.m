function build_target_psf_figure(cubeFile,seed,rangeLabel,opts)
%BUILD_TARGET_PSF_FIGURE Target range (IFFT) and Doppler (DFT) response per bin.
%   Two panels for one range run, from post-Doppler cubes exported by
%   Detection_Case2_SpatialACE_Benchmark (validationOverride.dumpCubesTo):
%
%     range  : sum over chains of |ZT(:,truthQ,:)|^2 across the range bins,
%              at the truth Doppler bin. The range-IFFT response.
%     Doppler: sum over chains of |ZT(truthNativeRow,:,:)|^2 across the
%              Doppler bins, at the truth range bin. An explicit 64x80 DFT matrix on the true PRS
%              timestamps, NOT an FFT: the PRS slots are non-uniformly
%              spaced (diffs of 1 and 2 slots), so an FFT would misplace
%              every hypothesis.
%
%   BOTH ARE TARGET ONLY. ZT is the exact target component from the
%   benchmark's three-way split, so no clutter and no thermal noise enter
%   either curve. They show where the target's own energy goes, not what the
%   detector sees against the background; the clutter figures cover that.
%
%   Each curve is normalised to its own peak, matching how
%   localTargetLeakageProfile_ reports the range profile in the saved
%   results. The range panel is cross-checked against that stored ProfileDB
%   when the matching result file exists, so the figure cannot silently
%   disagree with the number the study already published.
%
%   build_target_psf_figure('R603_cubes.mat',41,603)

if nargin<2 || isempty(seed), seed=41; end
if nargin<3, rangeLabel=[]; end
if nargin<4 || isempty(opts), opts=struct(); end
if ~isfield(opts,'RangeSpanBins'), opts.RangeSpanBins=40; end
if ~isfield(opts,'FloorDB'), opts.FloorDB=-70; end
if ~isfield(opts,'Label'), opts.Label=''; end   % free text when the cube is not a published run
if ~isfield(opts,'Tag'), opts.Tag=''; end
if ~isfield(opts,'K'), opts.K=[]; end
if ~isfield(opts,'E'), opts.E=[]; end
resultDir='results';

S=load(cubeFile,'ZT','truthQ','dumpTruthNativeIdx','rangeGridNative', ...
    'dopplerHz','truthRangeM','truthDopplerHz');
ZT=S.ZT;
truthQ=S.truthQ;
truthRow=S.dumpTruthNativeIdx;
rangeGrid=S.rangeGridNative(:).';
fHz=S.dopplerHz(:).';
[nRange,nDop,~]=size(ZT);
assert(numel(rangeGrid)==nRange && numel(fHz)==nDop,'Case2:psfGridSize', ...
    'Saved grids do not match the cube dimensions.');

dB=@(x)10*log10(max(x,realmin));
pR=squeeze(sum(abs(ZT(:,truthQ,:)).^2,3));          % range cut at truth Doppler
pD=squeeze(sum(abs(ZT(truthRow,:,:)).^2,3));        % Doppler cut at truth range
[pkR,peakRowR]=max(pR);
[pkD,peakColD]=max(pD);
profR=dB(pR(:).'/pkR);
profD=dB(pD(:).'/pkD);

% ---- cross-check the range panel against the published profile ----------
if ~isempty(rangeLabel)
    try
        f=helperResolveResultFile(resultDir,rangeLabel,seed,opts.K,opts.E);
    catch
        f='';
    end
    if ~isempty(f)
        L=load(f).output.Results.TargetLeakageProfile;
        d=max(abs(L.ProfileDB(:).'-profR));
        fprintf('Cross-check against stored ProfileDB: max |difference| = %.3e dB\n',d);
        assert(d<1e-9,'Case2:psfProfileMismatch', ...
            ['Recomputed range profile differs from the stored ProfileDB by ' ...
             '%.3e dB. The cube and the saved result are not the same run.'],d);
        assert(L.PeakNativeRow==peakRowR,'Case2:psfPeakMismatch', ...
            'Stored peak row %d, recomputed %d.',L.PeakNativeRow,peakRowR);
    else
        fprintf('No result file at %s; range panel not cross-checked.\n',f);
    end
end

rSel=max(1,peakRowR-opts.RangeSpanBins):min(nRange,peakRowR+opts.RangeSpanBins);
dr=median(diff(rangeGrid));
df=median(diff(fHz));

fh=figure('Name','Target range-IFFT and Doppler-DFT response', ...
    'NumberTitle','off','Color','w','Position',[80 80 1180 500]);
tl=tiledlayout(fh,1,2,'TileSpacing','compact','Padding','compact');

% ---- range panel ---------------------------------------------------------
ax=nexttile(tl); hold(ax,'on'); grid(ax,'on');
stem(ax,rSel-peakRowR,profR(rSel),'filled','Color',[0.10 0.45 0.95], ...
    'MarkerSize',3,'LineWidth',0.9);
yline(ax,-20,':','-20 dB','LabelHorizontalAlignment','left');
yline(ax,-30,':','-30 dB','LabelHorizontalAlignment','left');
yline(ax,-40,':','-40 dB','LabelHorizontalAlignment','left');
xline(ax,0,'-.','peak','Color',[0.2 0.6 0.2],'LabelVerticalAlignment','bottom');
ylim(ax,[opts.FloorDB 3]); xlim(ax,[-opts.RangeSpanBins opts.RangeSpanBins]);
xlabel(ax,sprintf('range bin offset from peak (1 bin = %.4f m)',dr));
ylabel(ax,'target power relative to peak (dB)');
title(ax,sprintf('Range IFFT response  |  peak bin %d = %.2f m', ...
    peakRowR,rangeGrid(peakRowR)));

% ---- Doppler panel -------------------------------------------------------
ax=nexttile(tl); hold(ax,'on'); grid(ax,'on');
stem(ax,1:nDop,profD,'filled','Color',[0.85 0.33 0.10], ...
    'MarkerSize',3,'LineWidth',0.9);
yline(ax,-20,':','-20 dB','LabelHorizontalAlignment','left');
yline(ax,-30,':','-30 dB','LabelHorizontalAlignment','left');
yline(ax,-40,':','-40 dB','LabelHorizontalAlignment','left');
xline(ax,truthQ,'-.',sprintf('truth %.1f Hz',S.truthDopplerHz), ...
    'Color',[0.2 0.6 0.2],'LabelVerticalAlignment','bottom');
ylim(ax,[opts.FloorDB 3]); xlim(ax,[0.5 nDop+0.5]);
xlabel(ax,sprintf('Doppler bin index (1 bin = %.2f Hz)',df));
ylabel(ax,'target power relative to peak (dB)');
title(ax,sprintf('Doppler DFT response  |  peak bin %d = %+g Hz', ...
    peakColD,fHz(peakColD)));

ttl='Target-only response, normalised to its own peak';
if ~isempty(opts.Label)
    ttl=sprintf('%s, seed %d - %s',opts.Label,seed,ttl);
elseif ~isempty(rangeLabel)
    ttl=sprintf('R%d, seed %d - %s',rangeLabel,seed,ttl);
end
title(tl,ttl,'FontWeight','bold');
subtitle(tl,sprintf(['truth %.3f m / %+.3f Hz  |  no clutter, no thermal ' ...
    'noise in either curve'],S.truthRangeM,S.truthDopplerHz),'FontSize',9);

% ---- console ------------------------------------------------------------
fprintf('\nRange IFFT, offsets -6..+6 from peak bin %d\n',peakRowR);
fprintf('  offset :'); fprintf('%9d',-6:6); fprintf('\n');
fprintf('  dB     :'); fprintf('%9.2f',profR(peakRowR+(-6:6))); fprintf('\n');
fprintf('  widths : -20 dB %d bins | -30 dB %d bins | -40 dB %d bins\n', ...
    localHalfWidth_(profR,peakRowR,-20),localHalfWidth_(profR,peakRowR,-30), ...
    localHalfWidth_(profR,peakRowR,-40));

lo=max(1,peakColD-6); hi=min(nDop,peakColD+6);
fprintf('\nDoppler DFT, bins %d..%d around peak bin %d\n',lo,hi,peakColD);
fprintf('  bin    :'); fprintf('%9d',lo:hi); fprintf('\n');
fprintf('  Hz     :'); fprintf('%9g',fHz(lo:hi)); fprintf('\n');
fprintf('  dB     :'); fprintf('%9.2f',profD(lo:hi)); fprintf('\n');
fprintf('  widths : -20 dB %d bins | -30 dB %d bins | -40 dB %d bins\n', ...
    localHalfWidth_(profD,peakColD,-20),localHalfWidth_(profD,peakColD,-30), ...
    localHalfWidth_(profD,peakColD,-40));
fprintf('  truth Doppler bin %d; peak at bin %d (%+d bins away)\n', ...
    truthQ,peakColD,peakColD-truthQ);

figDir=fullfile(resultDir,sprintf('figures_targetpsf_seed%d_%s',seed, ...
    datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
if ~isempty(opts.Tag)
    tag=opts.Tag;
elseif isempty(rangeLabel)
    tag='run';
else
    tag=sprintf('R%d',rangeLabel);
end
b=fullfile(figDir,sprintf('figTargetPSF_%s',tag));
exportgraphics(fh,[b '.png'],'Resolution',150); savefig(fh,[b '.fig']);
fprintf('\n  saved %s\n',b);
end

% =========================================================================
function e = localHalfWidth_(PdB,peakIdx,levelDB)
above=find(PdB>levelDB);
e=max(abs(above-peakIdx));
end
