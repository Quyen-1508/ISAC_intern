function f = helperResolveResultFile(resultDir,rangeLabel,seed,K,E)
%helperResolveResultFile Locate one saved benchmark result, old or new naming.
%   Results were originally named spatial_ace_R<range>_seed<seed>.mat, which
%   encodes neither K nor E. Because K and E change the CUT support and hence
%   the calibrated threshold, runs that differ only in K or E are different
%   experiments, so the name now carries them:
%
%       spatial_ace_R<range>_K<K>_E<E>_seed<seed>.mat
%
%   RESOLUTION NEVER GUESSES. With K and E supplied, exactly that file is
%   required. Without them, the legacy file and every K/E variant are
%   collected: one match is returned, zero raises an error naming the patterns
%   searched, and more than one raises an error listing the candidates and
%   asking for K and E. Silently picking a file would attach a figure to a
%   configuration the caller never chose.
%
%   f = helperResolveResultFile('results',250,41)        % any single match
%   f = helperResolveResultFile('results',250,41,64,28)  % that exact run

if nargin<4, K=[]; end
if nargin<5, E=[]; end
validateattributes(rangeLabel,{'numeric'},{'scalar','integer','positive'});
validateattributes(seed,{'numeric'},{'scalar','integer','nonnegative'});

newName=@(k,e)sprintf('spatial_ace_R%d_K%d_E%d_seed%d.mat',rangeLabel,k,e,seed);
oldName=sprintf('spatial_ace_R%d_seed%d.mat',rangeLabel,seed);

if ~isempty(K) && ~isempty(E)
    f=fullfile(resultDir,newName(K,E));
    assert(isfile(f),'Case2:resultFileMissing', ...
        'No saved result at %s.',f);
    return
end
assert(isempty(K) && isempty(E),'Case2:resultFilePartialKE', ...
    'Supply both K and E, or neither. Got K=%s, E=%s.', ...
    mat2str(K),mat2str(E));

cand={};
if isfile(fullfile(resultDir,oldName)), cand{end+1}=oldName; end
d=dir(fullfile(resultDir,sprintf('spatial_ace_R%d_K*_E*_seed%d.mat',rangeLabel,seed)));
for i=1:numel(d), cand{end+1}=d(i).name; end %#ok<AGROW>

if isscalar(cand)
    f=fullfile(resultDir,cand{1});
    return
end
if isempty(cand)
    error('Case2:resultFileMissing', ...
        'No saved result for R%d seed %d in %s. Searched:\n  %s\n  %s', ...
        rangeLabel,seed,resultDir,oldName, ...
        sprintf('spatial_ace_R%d_K*_E*_seed%d.mat',rangeLabel,seed));
end
error('Case2:resultFileAmbiguous', ...
    'R%d seed %d has %d saved results; pass K and E to choose one.\n  %s', ...
    rangeLabel,seed,numel(cand),strjoin(cand,sprintf('\n  ')));
end
