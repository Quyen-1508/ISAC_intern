function panel = helperBuildURAPanel(uraSize, numRFChains, carrierFrequency, ...
    physicalBoresightAzDeg, physicalBoresightElDeg)
%helperBuildURAPanel Build a dual-polarized TR 38.901 URA panel + analog subarray virtualization.
%
%   PANEL = helperBuildURAPanel(URASIZE, NUMRFCHAINS, CARRIERFREQUENCY,
%   PHYSICALBORESIGHTAZDEG, PHYSICALBORESIGHTELDEG) builds the SAME panel
%   geometry, TR 38.901 element, geometry-only steering vector and analog
%   subarray virtualization matrix that test_v4.m Section 2 and Section
%   8-ii build inline, for an arbitrary URASIZE = [rows cols] and
%   NUMRFCHAINS.
%
%   TEST-ONLY, INDEPENDENT COPY - NOT CALLED BY test_v4.m/test_v4_8x4panel.m.
%   This function MIRRORS test_v4.m Section 2 (panel/array/positions) and
%   Section 8-ii (subarray partition + virtualization matrix B) so Phase 3
%   SSB tests (test_phase3_ssb_beam_uniqueness, test_phase3_ssb_sector_
%   coverage) can build real steering vectors and a real virtualizationB
%   without pulling in test_v4.m's ~3000-line scenario/channel/frame
%   setup. If test_v4.m's Section 2/8-ii construction ever changes, this
%   copy must be updated by hand to match - it is NOT re-derived from the
%   production file at runtime. Kept deliberately narrow (no grating-lobe
%   probe, no tilt-inversion probe, no hard-coded port-count asserts): only
%   the structural invariants (position count, orthonormal B) that hold for
%   ANY uraSize/numRFChains combination are checked here; test_v4.m's own
%   config-specific asserts (e.g. uraSize==[8,8], numTxAntennas==128) stay
%   only in test_v4.m, since this helper must also serve the 8x4 variant.
%
%   Returns a struct PANEL with fields:
%     Element             - phased.NRAntennaElement
%     TxArray             - phased.NRRectangularPanelArray
%     TxSteeringVector    - phased.SteeringVector, IncludeElementResponse=false
%     VirtualizationB     - numRadiatingPorts x numRFChains, orthonormal columns
%     ChainColIdx         - numRFChains x 1, column rank (1..uraSize(2)) per chain
%     ChainRowGroup       - numRFChains x 1, vertical group per chain
%     NumRadiatingPorts   - uraSize(1)*uraSize(2)*2 (dual-pol)
%     SubarraySize        - ports per RF chain
%     Wavelength

    wavelength = freq2wavelen(carrierFrequency);
    element = phased.NRAntennaElement;
    panelSpacing = [wavelength/2 wavelength/2 wavelength wavelength];
    txArray = phased.NRRectangularPanelArray( ...
        'Size', [uraSize(1) uraSize(2) 1 1], 'Spacing', panelSpacing);

    numRadiatingPorts = getNumElements(txArray);
    assert(numRadiatingPorts == 2*prod(uraSize), ...
        'helperBuildURAPanel:badPortCount', ...
        'Expected %d radiating ports (2 x %dx%d), got %d.', ...
        2*prod(uraSize), uraSize(1), uraSize(2), numRadiatingPorts);

    elementPositions = round(getElementPosition(txArray).', 9);
    [uniquePositions, ~, positionOfElement] = unique(elementPositions, 'rows', 'stable');
    numElementPositions = size(uniquePositions, 1);
    assert(numElementPositions == prod(uraSize), ...
        'helperBuildURAPanel:apertureMismatch', ...
        'Expected %d distinct element positions, got %d.', prod(uraSize), numElementPositions);
    assert(all(accumarray(positionOfElement, 1) == 2), ...
        'helperBuildURAPanel:wrongElementsPerPosition', ...
        'Every position must carry exactly one polarization pair.');

    polarizationOfElement = zeros(numRadiatingPorts, 1);
    for p = 1:numElementPositions
        ep = find(positionOfElement == p);
        polarizationOfElement(ep) = 1:numel(ep);
    end

    txSteeringVector = phased.SteeringVector('SensorArray', txArray, ...
        'IncludeElementResponse', false);

    subarraySize = numRadiatingPorts/numRFChains;
    assert(subarraySize == round(subarraySize) && mod(uraSize(1), subarraySize) == 0, ...
        'helperBuildURAPanel:badSubarraySize', ...
        ['numRadiatingPorts/numRFChains (%g) must be a positive integer that ' ...
         'divides uraSize(1) (%d rows) evenly.'], subarraySize, uraSize(1));

    subarrayTiltDeg = physicalBoresightElDeg;   % broadside to the panel, see test_v4.m Section 8-ii

    yOfPosition = uniquePositions(:, 2);
    zOfPosition = uniquePositions(:, 3);
    uniqueColumnsY = unique(round(yOfPosition, 9));
    assert(numel(uniqueColumnsY) == uraSize(2), ...
        'helperBuildURAPanel:badColumnCount', ...
        'Expected %d columns, got %d.', uraSize(2), numel(uniqueColumnsY));

    subarrayOfElement = zeros(numRadiatingPorts, 1);
    chainColIdx   = zeros(numRFChains, 1);
    chainRowGroup = zeros(numRFChains, 1);
    subarrayIdx = 0;
    for polIdx = 1:2
        colIdx = 0;
        for yv = uniqueColumnsY.'
            colIdx = colIdx + 1;
            colPositions = find(abs(yOfPosition - yv) < 1e-9);
            assert(numel(colPositions) == uraSize(1), ...
                'helperBuildURAPanel:badColumnHeight', ...
                'Column at y = %.4f holds %d positions, expected %d.', ...
                yv, numel(colPositions), uraSize(1));
            [~, order] = sort(zOfPosition(colPositions));
            colPositions = colPositions(order);
            for g = 1:(uraSize(1)/subarraySize)
                subarrayIdx = subarrayIdx + 1;
                chainColIdx(subarrayIdx)   = colIdx;
                chainRowGroup(subarrayIdx) = g;
                groupPositions = colPositions((g-1)*subarraySize + (1:subarraySize));
                for pp = groupPositions.'
                    e = find(positionOfElement == pp & polarizationOfElement == polIdx);
                    assert(isscalar(e), ...
                        'helperBuildURAPanel:ambiguousElementLookup', ...
                        'Position %d polarization %d did not resolve to one element.', ...
                        pp, polIdx);
                    subarrayOfElement(e) = subarrayIdx;
                end
            end
        end
    end
    assert(subarrayIdx == numRFChains && all(subarrayOfElement > 0), ...
        'helperBuildURAPanel:incompleteSubarrayPartition', ...
        'The partition produced %d subarrays and left %d ports unassigned.', ...
        subarrayIdx, sum(subarrayOfElement == 0));

    svAtTilt = txSteeringVector(carrierFrequency, [physicalBoresightAzDeg; subarrayTiltDeg]);
    virtualizationB = zeros(numRadiatingPorts, numRFChains);
    for e = 1:numRadiatingPorts
        virtualizationB(e, subarrayOfElement(e)) = conj(svAtTilt(e))/sqrt(subarraySize);
    end
    assert(norm(virtualizationB'*virtualizationB - eye(numRFChains)) < 1e-9, ...
        'helperBuildURAPanel:virtualizationNotOrthonormal', ...
        'B must have orthonormal columns.');

    panel = struct();
    panel.Element             = element;
    panel.TxArray             = txArray;
    panel.TxSteeringVector    = txSteeringVector;
    panel.VirtualizationB     = virtualizationB;
    panel.ChainColIdx         = chainColIdx;
    panel.ChainRowGroup       = chainRowGroup;
    panel.NumRadiatingPorts   = numRadiatingPorts;
    panel.SubarraySize        = subarraySize;
    panel.Wavelength          = wavelength;
end
