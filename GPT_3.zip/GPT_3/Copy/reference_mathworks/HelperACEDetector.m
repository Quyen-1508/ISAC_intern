classdef HelperACEDetector < matlab.System
%   Copyright 2025 The MathWorks, Inc.

% HelperACEDetector - Adaptive Coherence Estimator (ACE) Detection System Object
%
% This System object implements the Adaptive Coherence Estimator (ACE) detection 
% algorithm, which is a statistical detector used in radar and array processing 
% applications. ACE is particularly effective for detecting targets in unknown 
% noise environments by using pre-computed noise covariance matrices.
%
% Key Features:
%   - Accepts pre-computed covariance matrices for maximum flexibility
%   - Configurable probability of false alarm (PFA) with automatic threshold computation
%   - Efficient batch processing of multiple target cells and signature vectors
%
% Mathematical Background:
%   ACE computes the detection statistic as:
%   Λ_ACE = |s^H * R^(-1) * x|^2 / [(s^H * R^(-1) * s) * (x^H * R^(-1) * x)]
%   where s is the signature vector, R is the noise covariance matrix,
%   and x is the target data vector.
%
% Dimensional Notation:
%   N - Dimension of data vectors (e.g., number of array elements × time samples)
%   M - Number of target cells to process simultaneously
%   K - Number of training samples used to estimate covariance (for threshold computation)
%   D - Number of signature vectors (e.g., steering vectors at different angles)
%
% Input Arguments:
%   x (target data)     - N×M matrix of target cell data
%   sv (signature matrix) - N×D matrix of signature vectors to test
%   ncov (noise covariance) - N×N matrix (shared) or N×N×M array (individual per cell)
%
% Output Arguments:
%   yout (detection result) - D×M logical matrix (true = target detected)
%   stat (test statistics)  - D×M matrix of ACE detection statistics
%   th (threshold)         - Scalar detection threshold
%
% Usage Example:
%   % Create ACE detector with 1% false alarm rate
%   detector = HelperACEDetector('ProbabilityFalseAlarm', 0.01, 'NumTrainingSamples', 100);
%   
%   % Process target data with pre-computed covariance matrix
%   [detections, statistics, threshold] = detector(targetData, signatures, covarianceMatrix);

%   References:
%   [1] Fulvio Gini and Maria Greco, "Covariance matrix estimation for
%       CFAR detection in correlated heavy tailed clutter." Signal
%       Processing, 2002.
%   [2] F. Pascal, P. Forster, J. -P. Ovarlez and P. Larzabal,
%       "Performance Analysis of Covariance Matrix Estimates in Impulsive
%       Noise," IEEE Transactions on Signal Processing, vol. 56, no. 6,
%       pp. 2206-2217, June 2008.
%   [3] Antonio De Maio and Maria Greco, Modern Radar Detection Theory,
%       Chapter 8, pp. 295-332, 2016.
%   [4] J. Liu, H. Li and B. Himed, "Threshold Setting for Adaptive
%       Matched Filter and Adaptive Coherence Estimator," IEEE Signal
%       Processing Letters, vol. 22, no. 1, pp. 11-15, Jan. 2015.

    properties (Nontunable)
        % ProbabilityFalseAlarm - Target probability of false alarm
        %   Specify the desired probability of false alarm as a scalar value
        %   between 0 and 1. The detection threshold is automatically computed
        %   to achieve this false alarm rate. Lower values result in higher
        %   detection thresholds and fewer false alarms.
        %   Default: 0.1 (10% false alarm rate)
        ProbabilityFalseAlarm(1,1) {mustBeReal,...
            mustBeA(ProbabilityFalseAlarm,{'double','single'}),...
            mustBeGreaterThan(ProbabilityFalseAlarm,0),...
            mustBeLessThan(ProbabilityFalseAlarm,1)} = 1e-1;

        % NumTrainingSamples - Number of training samples used for covariance estimation
        %   Specify the number of training samples that were used to estimate
        %   the noise covariance matrix. This parameter is required for accurate
        %   threshold computation based on the theoretical distribution of the
        %   ACE statistic under the null hypothesis.
        %   Default: 100
        NumTrainingSamples(1,1) {mustBeReal,...
            mustBeA(NumTrainingSamples,{'double','single'}),...
            mustBeInteger, mustBePositive} = 100;
    end

    properties (Access = private)
        % pth - Precomputed detection threshold
        %   Stores the detection threshold computed from the specified
        %   probability of false alarm during system initialization.
        pth
    end

    methods
        function obj = HelperACEDetector(varargin)
            % HelperACEDetector - Constructor for ACE detector system object
            %
            % Syntax:
            %   obj = HelperACEDetector()
            %   obj = HelperACEDetector(Name, Value, ...)
            %
            % Description:
            %   Creates an ACE detector system object with optional name-value
            %   pair arguments to configure the detector properties.
            %
            % Name-Value Arguments:
            %   'ProbabilityFalseAlarm' - Desired false alarm probability (default: 0.1)
            %   'NumTrainingSamples' - Number of training samples used for covariance estimation (default: 100)
            %
            % Example:
            %   % Create detector with 1% false alarm rate and 200 training samples
            %   detector = HelperACEDetector('ProbabilityFalseAlarm', 0.01, ...
            %                               'NumTrainingSamples', 200);
            
            % Support name-value pair arguments
            setProperties(obj, nargin, varargin{:});
        end
    end

    methods (Access = protected)
        function setupImpl(obj, ~, ~, ncov)
            % setupImpl - Initialize the ACE detector system object
            %
            % This method is called once during the first call to step() and
            % performs the following initialization tasks:
            % 1. Computes the detection threshold from the specified PFA
            % 2. Validates that the covariance matrix dimensions are consistent
            
            % Extract dimensions from covariance matrix
            N = size(ncov, 1);  % Number of variables (data dimension)            
            K = obj.NumTrainingSamples;  % Number of training samples
            
            % Compute detection threshold for specified false alarm probability
            obj.pth = obj.acepfa2th(obj.ProbabilityFalseAlarm, N, K);
        end

        function validateInputsImpl(obj, x, sv, ncov)
            % validateInputsImpl - Validate input arguments at initialization
            %
            % This method checks that the input dimensions are compatible and
            % that the covariance matrix is properly formatted.
            %
            % Input validation rules:
            % - Number of training samples (K) must exceed data dimension (N)
            % - All input matrices must have compatible dimensions
            % - Covariance matrix must be square and positive definite
            
            % Get dimensions
            [N, M] = size(x);
            [sv_N, D] = size(sv);
            
            % Check signature vector dimensions
            if sv_N ~= N
                error('Signature vectors must have same first dimension as target data (N=%d)', N);
            end
            
            % Check covariance matrix dimensions
            if ismatrix(ncov)
                % Shared covariance matrix
                [ncov_N1, ncov_N2] = size(ncov);
                if ncov_N1 ~= N || ncov_N2 ~= N
                    error('Covariance matrix must be N×N where N=%d', N);
                end
            elseif ndims(ncov) == 3
                % Individual covariance matrices
                [ncov_N1, ncov_N2, ncov_M] = size(ncov);
                if ncov_N1 ~= N || ncov_N2 ~= N
                    error('Covariance matrices must be N×N where N=%d', N);
                end
                if ncov_M ~= M
                    error('Number of covariance matrices must match number of target cells (M=%d)', M);
                end
            else
                error('Covariance matrix must be 2D (N×N) or 3D (N×N×M)');
            end
            
            % Check fundamental requirement: K > N for valid threshold computation
            K = obj.NumTrainingSamples;
            if K <= N
                error(['HelperACEDetector:InsufficientTrainingData\n' ...
                       'Number of training samples (%d) must exceed data dimension (%d).\n' ...
                       'This is required for reliable threshold computation.'], ...
                       K, N);
            end
        end

        function [yout, stat, th] = stepImpl(obj, x, sv, ncov)
            % stepImpl - Execute ACE detection algorithm
            %
            % This method implements the core ACE detection processing:
            % 1. Uses the provided noise covariance matrices
            % 2. Computes ACE detection statistics for all signature vectors
            % 3. Applies threshold to generate binary detection decisions
            %
            % The method supports both single and multiple target cell processing.
            %
            % Covariance matrix (ncov) can be provided in two formats:
            % - N×N: Shared covariance matrix for all target cells
            % - N×N×M: Individual covariance matrix for each target cell

            % Compute ACE detection statistics
            stat = obj.acestat(x, sv, ncov);

            % Apply threshold to generate binary decisions
            th = obj.pth;
            yout = stat > th;
        end

        function numInputs = getNumInputsImpl(obj)
            % getNumInputsImpl - Return number of inputs
            %
            % The detector has exactly 3 inputs: x, sv, ncov
            
            numInputs = 3;
        end

        function varargout = getInputNamesImpl(obj)
            % getInputNamesImpl - Provide input port names
            %
            % Returns cell array of input port names for display purposes.
            
            inputNames = {'x', 'sv', 'ncov'};
            varargout = {inputNames};
        end

        function flag = isInactivePropertyImpl(obj, ~)
            % isInactivePropertyImpl - Check if properties are inactive
            %
            % All properties are always active in this implementation.
            
            flag = false;
        end
        
        function flag = isInputSizeMutableImpl(obj, ~)
            % isInputSizeMutableImpl - Allow input size changes
            %
            % Input sizes can change between calls to accommodate different
            % numbers of target cells and signature vectors.
            
            flag = true;
        end
        
        function flag = isInputComplexityMutableImpl(obj, ~)
            % isInputComplexityMutableImpl - Allow input complexity changes
            %
            % Input complexity (real vs complex) can change between calls.

            flag = true;
        end
    end

    methods (Access = private)

        function stat = acestat(obj, x, sv, ncov)
            % acestat - Compute ACE detection statistics
            %
            % Mathematical Formula:
            % ACE = |s^H * R^(-1) * x|^2 / [(s^H * R^(-1) * s) * (x^H * R^(-1) * x)]
            %
            % Key Optimizations:
            % - Single Cholesky decomposition for shared covariance
            % - Fully vectorized matrix operations
            % - Precomputed inverse transformations
            % - Eliminated inner loops for shared covariance case
            %
            % Input Arguments:
            % x - N×M target data matrix
            % sv - N×D signature vector matrix
            % ncov - N×N×M noise covariance matrices (or N×N for shared covariance)
            %
            % Output Arguments:
            % stat - D×M detection statistics matrix

            % Check if covariance is shared (single N×N matrix)
            if ismatrix(ncov)
                % OPTIMIZED PATH: Shared covariance matrix
                stat = obj.acestat_shared_ncov(x, sv, ncov);
            else
                % FALLBACK PATH: Individual covariance matrices
                stat = obj.acestat_individual_ncov(x, sv, ncov);
            end

        end

        function stat = acestat_shared_ncov(~, x, sv, ncov)
            % ACE detection statistics for shared noise covariance matrix

            % Cholesky decomposition
            try
                L = chol(ncov);
            catch ME
                error('Covariance matrix must be positive definite');
            end

            % Vectorized computation of R^(-1) * x for all targets
            X_transformed = L \ (L' \ x);  % N×M matrix

            % Vectorized computation of R^(-1) * sv for all signatures
            SV_transformed = L \ (L' \ sv);  % N×D matrix

            % Compute all quadratic forms simultaneously
            % x^H * R^(-1) * x for all targets (1×M vector)
            x_terms = sum(conj(x) .* X_transformed, 1); 

            % s^H * R^(-1) * s for all signatures (1×D vector)
            sv_terms = sum(conj(sv) .* SV_transformed, 1);

            % Compute all cross terms s^H * R^(-1) * x simultaneously
            cross_terms = sv' * X_transformed;  % D×M matrix (complex conjugate handled in sv')

            % Compute ACE statistics using vectorized operations
            numerator = abs(cross_terms).^2;  % D×M matrix
            denominator = abs(sv_terms.' * x_terms);  % D×M matrix (outer product)

            % Final ACE statistics
            stat = numerator ./ denominator;
        end

        function stat = acestat_individual_ncov(~, x, sv, ncov)
            % ACE detection statistics for individual noise covariance matrices
            [N, M] = size(x);
            D = size(sv, 2);
            stat = zeros(D, M);

            % Precompute target-dependent terms
            Y = zeros(N, M);
            x_term = zeros(1, M);
            R_cell = cell(1, M);

            for m = 1:M
                try
                    R_cell{m} = chol(ncov(:,:,m));
                catch ME
                    error('Covariance matrix %d must be positive definite', m);
                end
                Y(:,m) = R_cell{m} \ (R_cell{m}' \ x(:,m));
                x_term(m) = abs(x(:,m)' * Y(:,m));
            end

            % Process each signature vector
            for modelIdx = 1:D
                svCurr = sv(:, modelIdx);
                for m = 1:M
                    z_m = R_cell{m} \ (R_cell{m}' \ svCurr);
                    numerator = abs(svCurr' * Y(:,m))^2;
                    denominator = abs(svCurr' * z_m);
                    amfStat = numerator / denominator;
                    stat(modelIdx, m) = amfStat / x_term(m);
                end
            end
        end

        function th = acepfa2th(obj, pfa, N, K)
            % acepfa2th - Convert probability of false alarm to detection threshold
            %
            % This method computes the detection threshold that achieves the
            % specified probability of false alarm using the theoretical
            % distribution of the ACE statistic under the null hypothesis.
            %
            % Input Arguments:
            %   pfa - Desired probability of false alarm
            %   N   - Data dimension (number of variables)
            %   K   - Number of training samples
            %
            % Output Arguments:
            %   th  - Detection threshold
            %
            % Mathematical Background:
            %   The threshold is computed by solving the equation:
            %   P_FA = (1-th)^(K-N+1) * (1-(K-N+1)/(K+1)*th)^(-(K-N+2))
            %   
            %   This approximation is valid for large K and provides accurate
            %   threshold values for practical applications [4].
            
            % Define the false alarm probability equation to solve
            % Based on the theoretical distribution of ACE under H0
            f = @(th) (1 - th)^(K - N + 1) * ...
                      (1 - (K - N + 1)/(K + 1) * th)^(-(K - N + 2)) - pfa;
            
            % Solve for threshold using numerical root finding
            % Initial guess of 0 works well for typical PFA values
            th = fzero(f, 0);
        end
    end
end