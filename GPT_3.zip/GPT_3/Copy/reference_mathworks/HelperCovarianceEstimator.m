classdef HelperCovarianceEstimator < matlab.System
%   Copyright 2025 The MathWorks, Inc.

% HelperCovarianceEstimator - Adaptive covariance matrix estimation
%
% DESCRIPTION:
%   This System object provides robust covariance matrix estimation with
%   support for both Sample Covariance Matrix (SCM) and Normalized Sample
%   Covariance Matrix (NSCM) methods. It supports sequential processing
%   for adaptive estimation and includes diagonal loading options for
%   improved numerical stability.
%
% SYNTAX:
%   obj = HelperCovarianceEstimator()
%   obj = HelperCovarianceEstimator(Name, Value)
%   R = obj(x)
%   R = obj(x, epsilon)
%
% INPUTS:
%   x       - Input data matrix (P-by-N)
%             P: Number of samples/snapshots
%             N: Dimension of each sample (number of variables)
%   epsilon - Diagonal loading parameter (scalar, non-negative)
%             Only required when DiagonalLoading is set to 'Input port'
%
% OUTPUTS:
%   R       - Estimated covariance matrix (N-by-N)
%             Hermitian positive semi-definite matrix
%
% PROPERTIES:
%   Method          - Estimation method ('SCM' | 'NSCM')
%                     'SCM':  Sample Covariance Matrix (default)
%                     'NSCM': Normalized Sample Covariance Matrix
%   DiagonalLoading - Regularization method (scalar | 'Input port' | 'Shrinkage')
%                     scalar:      Fixed diagonal loading value (default: 0)
%                     'Input port': Diagonal loading via input parameter
%                     'Shrinkage': Automatic shrinkage estimation
%
% METHODS:
%   obj(x)         - Static covariance estimation (resets internal state)
%   reset(obj)     - Reset internal state
%   release(obj)   - Release resources
%
% ESTIMATION METHODS:
%   SCM (Sample Covariance Matrix):
%     R = (1/P) * X' * X
%     Standard maximum likelihood estimator
%
%   NSCM (Normalized Sample Covariance Matrix):
%     Each sample is normalized to unit norm before covariance computation
%     Useful for scenarios with varying signal amplitudes
%
% DIAGONAL LOADING OPTIONS:
%   Fixed Value:
%     R_reg = R + epsilon * I
%     where epsilon is a user-specified scalar
%
%   Shrinkage:
%     Automatic estimation of optimal shrinkage parameter using
%     Ledoit-Wolf type shrinkage towards scaled identity matrix
%
%   Input Port:
%     Diagonal loading parameter provided as input argument
%
% USAGE EXAMPLES:
%   % Basic usage with default settings (SCM method)
%   obj = HelperCovarianceEstimator();
%   x = randn(100, 8);  % 100 samples, 8 dimensions
%   R = obj(x);         % Compute covariance matrix
%
%   % NSCM method with fixed diagonal loading
%   obj = HelperCovarianceEstimator('Method', 'NSCM', 'DiagonalLoading', 0.01);
%   R = obj(x);
%
%   % Automatic shrinkage regularization
%   obj = HelperCovarianceEstimator('DiagonalLoading', 'Shrinkage');
%   R = obj(x);
%
%   % Diagonal loading via input port
%   obj = HelperCovarianceEstimator('DiagonalLoading', 'Input port');
%   epsilon = 0.05;
%   R = obj(x, epsilon);
%
% NOTES:
%   - For sequential processing, use the update() method to accumulate data
%   - For static processing, use obj() which resets state each time
%   - The output matrix R is guaranteed to be Hermitian
%   - NSCM method normalizes each sample to sqrt(N) to preserve scale
%   - Shrinkage method requires sufficient samples (P > N) for optimal performance
%   - Input data complexity (real/complex) is automatically handled
%
% REFERENCES:
%   [1] O. Ledoit and M. Wolf, "A well-conditioned estimator for
%   large-dimensional covariance matrices" J. Multivariate Analysis, 2004
%   [2] F. Pascal, Y. Chitour, J. -P. Ovarlez, P. Forster and P. Larzabal,
%   "Covariance Structure Maximum-Likelihood Estimates in Compound Gaussian
%   Noise: Existence and Algorithm Analysis," in IEEE Transactions on
%   Signal Processing, vol. 56, no. 1, pp. 34-48, Jan. 2008.
%   [3] Y. Chen, A. Wiesel and A. O. Hero, "Robust Shrinkage Estimation of
%   High-Dimensional Covariance Matrices," in IEEE Transactions on Signal
%   Processing, vol. 59, no. 9, pp. 4097-4107, Sept. 2011

    properties (Nontunable)
        % Method - Covariance estimation method
        % Specify the algorithm used for covariance matrix estimation.
        % 'SCM' uses standard sample covariance (default). 'NSCM' normalizes
        % each sample to unit norm before estimation, useful for data with
        % varying amplitudes or energy levels.
        % Default: 'SCM'
        Method = 'SCM'; % 'SCM' or 'NSCM'
        
        % DiagonalLoading - Regularization method for numerical stability
        % Specify how diagonal loading is applied to improve matrix conditioning.
        % Use a scalar value (e.g., 0.01) for fixed regularization, 'Input port'
        % to specify the loading value as an input parameter, or 'Shrinkage'
        % for automatic regularization based on the data.
        % Default: 0 (no regularization)
        DiagonalLoading ...
            {matlab.system.presetMember(DiagonalLoading,{'Input port','Shrinkage'},{'double','single'})} ...
            = 0; % scalar or 'Input port' or 'Shrinkage'
    end

    properties(Constant, Hidden)
        % MethodSet - Valid method options for property validation
        % Internal property used by MATLAB's System object framework
        % to validate Method property values and populate GUI dropdowns.
        MethodSet = matlab.system.StringSet(...
            {'SCM','NSCM'});
    end
    
    properties (Access = private)
        % pCov - Current covariance matrix estimate
        % Internal N-by-N matrix storing the current covariance estimate
        % during sequential processing. Updated incrementally as new
        % samples are processed through the update() method.
        pCov; % Current covariance estimate (N x N)
        
        % pNumSamples - Total number of samples processed
        % Internal counter tracking the total number of samples incorporated
        % into the current covariance estimate. Used for proper weighting
        % in sequential updates and shrinkage calculations.
        % Default: 0
        pNumSamples = 0; % Number of samples processed (K)
        
        % pDimension - Dimension of input samples
        % Internal property storing the number of variables (columns) in
        % each input sample. Set automatically from the first input data
        % and validated for consistency in subsequent calls.
        pDimension; % Dimension of variables (N)
    end
    
    methods
        function obj = HelperCovarianceEstimator(varargin)
            % HelperCovarianceEstimator - Constructor
            %
            % SYNTAX:
            %   obj = HelperCovarianceEstimator()
            %   obj = HelperCovarianceEstimator(Name, Value)
            %
            % OPTIONAL NAME-VALUE PAIRS:
            %   'Method'          - Estimation method ('SCM' | 'NSCM'), default: 'SCM'
            %   'DiagonalLoading' - Regularization (scalar | 'Input port' | 'Shrinkage'), default: 0
            %
            % EXAMPLES:
            %   obj = HelperCovarianceEstimator();
            %   obj = HelperCovarianceEstimator('Method', 'NSCM');
            %   obj = HelperCovarianceEstimator('Method', 'SCM', 'DiagonalLoading', 0.01);
            
            setProperties(obj, nargin, varargin{:});
        end
    end
    
    methods (Access = protected)
        function setupImpl(obj, varargin)
            obj.pCov = [];
            obj.pNumSamples = 0;
        end
        
        function R = stepImpl(obj, varargin)
            % stepImpl - Static covariance estimation (resets state)
            % This method computes covariance from the current batch only
            % and resets the internal state
            
            x = varargin{1};
            
            % Parse diagonal loading parameter
            diagonalLoadingValue = obj.parseDiagonalLoadingInput(varargin(2:end));
            
            % Reset state for static computation
            obj.resetState();
            
            % Validate and initialize dimensions
            obj.validateAndInitializeDimensions(x);
            
            % Accumulate data (static - single batch)
            obj.accumulateDataStatic(x);
            
            % Compute final covariance matrix
            R = obj.computeCovarianceMatrix(diagonalLoadingValue);
        end
        
        function numInputs = getNumInputsImpl(obj)
            numInputs = 1; % Start with x
            
            if strcmp(obj.DiagonalLoading, 'Input port')
                numInputs = numInputs + 1;
            end
        end

        function varargout = getInputNamesImpl(obj)
            inputNames = {'x'};
            
            if strcmp(obj.DiagonalLoading, 'Input port')
                inputNames{end+1} = 'epsilon';
            end
            
            varargout = inputNames;
        end

        function resetImpl(obj)
            obj.resetState();
        end
    end
    
    methods (Access = private)
        function diagonalLoadingValue = parseDiagonalLoadingInput(obj, varargin)
            % Parse diagonal loading parameter from input arguments
            if strcmp(obj.DiagonalLoading, 'Shrinkage')
                diagonalLoadingValue = 'Shrinkage'; % Will be computed later
            elseif strcmp(obj.DiagonalLoading, 'Input port')
                if isempty(varargin)
                    error('Diagonal loading input required when DiagonalLoading is set to ''Input port''');
                end
                diagonalLoadingValue = varargin{1};
                
                % Validate diagonal loading input
                if ~isnumeric(diagonalLoadingValue) || ~isscalar(diagonalLoadingValue) || diagonalLoadingValue < 0
                    error('Diagonal loading input must be a non-negative scalar');
                end
            else % scalar property input
                diagonalLoadingValue = obj.DiagonalLoading;
            end
        end
        
        function validateAndInitializeDimensions(obj, x)
            % Validate input dimensions and initialize if needed
            [~, N] = size(x);
            
            if isempty(obj.pCov)
                obj.pDimension = N;
                obj.pCov = zeros(obj.pDimension, obj.pDimension);
            elseif N ~= obj.pDimension
                error('Dimension mismatch: expected %d columns, got %d', obj.pDimension, N);
            end
        end
        
        function x_normalized = normalizeData(obj, x)
            % Normalize data based on the selected method
            if strcmp(obj.Method, 'NSCM')
                norms = vecnorm(x, 2, 2); % L2 norm of each row (snapshot)
                % Avoid division by zero
                norms(norms == 0) = 1;
                x_normalized = x ./ norms * sqrt(obj.pDimension); % Normalize each snapshot
            else
                x_normalized = x;
            end
        end
        
        function resetState(obj)
            % Reset internal state
            obj.pCov = [];
            obj.pNumSamples = 0;
        end
        
        function accumulateDataStatic(obj, x)
            % Accumulate data for static covariance estimation
            x_normalized = obj.normalizeData(x);
            [P, ~] = size(x_normalized);
            
            % Static covariance estimation from current batch only
            obj.pCov = (x_normalized.' * conj(x_normalized)) / P;
            obj.pNumSamples = P;
        end

        function diagonalLoadingValue = computeDiagonalLoading(obj)
            % Compute diagonal loading value for shrinkage method
            if obj.pNumSamples > obj.pDimension
                % Sufficient samples for shrinkage estimation
                F = trace(obj.pCov) / obj.pDimension * eye(obj.pDimension); % Target matrix (scaled identity)
                
                % Calculate squared Frobenius norm differences
                R_centered = obj.pCov - F;
                denominator = trace(R_centered' * R_centered);
                
                if denominator > 0
                    % Estimate variance of sample covariance entries
                    numerator = trace(obj.pCov)^2 / obj.pDimension^2 / obj.pNumSamples;
                    shrinkage = min(numerator / denominator, 1);
                else
                    shrinkage = 0;
                end
                
                diagonalLoadingValue = shrinkage * trace(obj.pCov) / obj.pDimension;
            else
                % Not enough samples, use regularization based on condition number
                eigvals = eig(obj.pCov);
                eigvals = real(eigvals); % Take real part in case of numerical errors
                eigvals = eigvals(eigvals > 0); % Remove non-positive eigenvalues
                
                if length(eigvals) > 1
                    cond_num = max(eigvals) / min(eigvals);
                    if cond_num > 1e12
                        diagonalLoadingValue = 0.01 * trace(obj.pCov) / obj.pDimension;
                    else
                        diagonalLoadingValue = 0;
                    end
                else
                    diagonalLoadingValue = 0.01 * trace(obj.pCov) / obj.pDimension;
                end
            end
        end
        
        function R = computeCovarianceMatrix(obj, diagonalLoadingValue)
            % Compute final covariance matrix with diagonal loading
            
            % Determine actual diagonal loading value
            if ischar(diagonalLoadingValue) && strcmp(diagonalLoadingValue, 'Shrinkage')
                actualDiagonalLoading = obj.computeDiagonalLoading();
            else
                actualDiagonalLoading = diagonalLoadingValue;
            end
            
            % Apply diagonal loading
            R = obj.pCov + actualDiagonalLoading * eye(obj.pDimension);
            
            % Ensure Hermitian property
            R = (R + R') / 2;
        end
    end
end