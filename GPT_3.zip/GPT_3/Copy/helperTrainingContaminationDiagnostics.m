function D = helperTrainingContaminationDiagnostics(ZB,ZT,cutNativeIdx,truthQ,steering,cfg)
%helperTrainingContaminationDiagnostics Diagnose signal-in-training effects.
%   D = helperTrainingContaminationDiagnostics(ZB,ZT,CUT,TRUTHQ,STEERING,CFG)
%   compares background-only and background-plus-target loaded covariance
%   matrices without changing the production detector. The diagnostic uses
%   the same NSCM, shrinkage loading and ACE statistic as the benchmark.
%
%   Required CFG fields:
%       NumTrainingCells  even training-cell count K
%       ExclusionBins     vector of exclusion values to test
%       TargetGainDB      vector of target amplitude offsets in dB
%
%   Optional CFG fields:
%       RangeGateBins     native-bin offsets around CUT, default -1:1
%       DopplerGateBins   Doppler-index offsets around TRUTHQ, default -1:1
%       GeometryComparisonBins  two E values for a direct geometry comparison
%
%   For every (E,g) pair, the helper reports:
%     * relative Frobenius covariance perturbation
%     * relative inverse-covariance perturbation
%     * maximum steering-direction perturbation after background whitening
%     * ACE ratio using the same composite CUT vector with M_B and M_BT
%     * a correctly normalized adaptive SINR ratio for every steering column
%
%   These quantities are diagnostics only. They do not alter thresholds,
%   training windows or detections in the primary benchmark.

validateattributes(ZB,{'single','double'},{'nonempty'});
validateattributes(ZT,{'single','double'},{'size',size(ZB)});
assert(ndims(ZB)==3,'Case2:trainingDiagDims', ...
    'ZB and ZT must be Nrange-by-Ndoppler-by-Nchain post-Doppler cubes.');
validateattributes(cutNativeIdx,{'numeric'},{'scalar','integer','positive'});
validateattributes(truthQ,{'numeric'},{'scalar','integer','positive'});
assert(isfield(cfg,'NumTrainingCells') && isfield(cfg,'ExclusionBins') && ...
       isfield(cfg,'TargetGainDB'),'Case2:trainingDiagCfg', ...
    'cfg needs NumTrainingCells, ExclusionBins and TargetGainDB.');

[nRange,nDop,nChain]=size(ZB);
assert(truthQ<=nDop,'Case2:trainingDiagTruthQ','truthQ exceeds the Doppler grid.');
S=steering;
if isvector(S), S=S(:); end
assert(size(S,1)==nChain,'Case2:trainingDiagSteering', ...
    'Steering has %d rows; data have %d chains.',size(S,1),nChain);
for ia=1:size(S,2)
    S(:,ia)=S(:,ia)/max(norm(S(:,ia)),realmin(class(real(S))));
end

K=round(cfg.NumTrainingCells);
Elist=double(cfg.ExclusionBins(:).');
gDB=double(cfg.TargetGainDB(:).');
% K > Nchain was a statistical rule of thumb, not an implementation
% requirement. helperNSCM normalises every snapshot to norm sqrt(N), so
% trace(M)=N and tau=1 for every K, and helperShrinkageLoading then adds
% lambda*tau*I with lambda>0. The loaded covariance is therefore positive
% definite at any K, which the Cholesky assert below still verifies. Small K
% costs conditioning, not validity, so it is reported through the condition
% number and loading diagnostics rather than forbidden here.
assert(mod(K,2)==0 && K>=2,'Case2:trainingDiagK', ...
    'Need an even K >= 2. K=%d.',K);
assert(all(Elist>=0 & Elist==round(Elist)),'Case2:trainingDiagExclusion', ...
    'Every ExclusionBins value must be a nonnegative integer.');

if isfield(cfg,'RangeGateBins'), rOff=double(cfg.RangeGateBins(:).'); else, rOff=-1:1; end
if isfield(cfg,'DopplerGateBins'), qOff=double(cfg.DopplerGateBins(:).'); else, qOff=-1:1; end
rGate=cutNativeIdx+rOff;
qGate=truthQ+qOff;
rGate=rGate(rGate>=1 & rGate<=nRange);
qGate=qGate(qGate>=1 & qGate<=nDop);
assert(~isempty(rGate) && ~isempty(qGate),'Case2:trainingDiagEmptyGate', ...
    'The requested diagnostic gate is empty.');

nE=numel(Elist); nG=numel(gDB);
template=struct('ExclusionBins',NaN,'TargetGainDB',NaN, ...
    'TrainingTargetToBackgroundDB',NaN, ...
    'RelativeFrobeniusPerturbation',NaN, ...
    'RelativeInversePerturbation',NaN, ...
    'MaxAbsDirectionalPerturbation',NaN, ...
    'ACEBackgroundCovariance',NaN, ...
    'ACEContaminatedCovariance',NaN, ...
    'ACEContaminatedToBackgroundRatio',NaN, ...
    'ACEChangeDB',NaN, ...
    'AdaptiveSINRRatioAtBackgroundBestAngle',NaN, ...
    'AdaptiveSINRLossAtBackgroundBestAngleDB',NaN, ...
    'MinAdaptiveSINRRatio',NaN, ...
    'MaxAdaptiveSINRLossDB',NaN, ...
    'ConditionNumberBackground',NaN, ...
    'ConditionNumberContaminated',NaN, ...
    'BestAngleBackground',NaN,'BestAngleContaminated',NaN);
entry=repmat(template,nE,nG);
halfK=K/2;

for iE=1:nE
    E=Elist(iE);
    idx=[(cutNativeIdx-E-halfK):(cutNativeIdx-E-1), ...
         (cutNativeIdx+E+1):(cutNativeIdx+E+halfK)];
    assert(idx(1)>=1 && idx(end)<=nRange && numel(idx)==K, ...
        'Case2:trainingDiagSupport', ...
        'CUT %d cannot support K=%d and E=%d.',cutNativeIdx,K,E);

    YB=reshape(ZB(idx,truthQ,:),K,nChain).';
    MB=localLoadedCovariance_(YB,K);
    invMB=localHermitianInverse_(MB);
    [LB,pB]=chol(MB,'lower');
    assert(pB==0,'Case2:trainingDiagBackgroundNotPD', ...
        'Loaded background covariance is not positive definite.');
    trainingBgPower=sum(abs(YB).^2,'all');

    for ig=1:nG
        g=10^(gDB(ig)/20);
        YT=reshape(g*ZT(idx,truthQ,:),K,nChain).';
        YBT=YB+YT;
        MBT=localLoadedCovariance_(YBT,K);
        invMBT=localHermitianInverse_(MBT);
        [LBT,pBT]=chol(MBT,'lower');
        assert(pBT==0,'Case2:trainingDiagContaminatedNotPD', ...
            'Loaded background-plus-target covariance is not positive definite.');

        delta=MBT-MB;
        cF=norm(delta,'fro')/max(norm(MB,'fro'),realmin);
        cInv=norm(invMBT-invMB,'fro')/max(norm(invMB,'fro'),realmin);

        % Background-whitened directional perturbation for every steering column.
        SW=LB\S;
        DW=LB\delta/(LB');
        dir=zeros(1,size(S,2));
        for ia=1:size(S,2)
            aw=SW(:,ia);
            dir(ia)=real(aw'*DW*aw)/max(real(aw'*aw),realmin);
        end

        % Production-close ACE comparison: same deterministic composite data,
        % same gate and steering bank; only the covariance estimate changes.
        aceB=-Inf; aceBT=-Inf; bestB=NaN; bestBT=NaN;
        for rr=rGate
            for qq=qGate
                y=reshape(ZB(rr,qq,:)+g*ZT(rr,qq,:),nChain,1);
                aB=helperACEStatistic(y,S,LB);
                aBT=helperACEStatistic(y,S,LBT);
                [vB,iB]=max(aB); [vBT,iBT]=max(aBT);
                if vB>aceB, aceB=vB; bestB=iB; end
                if vBT>aceBT, aceBT=vBT; bestBT=iBT; end
            end
        end
        aceRatio=aceBT/max(aceB,realmin);

        % Adaptive SINR ratio. MB is treated as the disturbance covariance at
        % the CUT; MBT is the covariance used to form the adaptive weight.
        % Ratio 1 means no loss relative to the MB-optimum weight.
        sinrRatio=nan(1,size(S,2));
        for ia=1:size(S,2)
            a=S(:,ia);
            v=invMBT*a;
            achieved=abs(a'*v)^2/max(real(v'*MB*v),realmin);
            optimum=max(real(a'*invMB*a),realmin);
            sinrRatio(ia)=min(max(real(achieved/optimum),0),1+1e-10);
        end
        minRatio=min(sinrRatio);

        tgtPow=sum(abs(YT).^2,'all');
        e=template;
        e.ExclusionBins=E;
        e.TargetGainDB=gDB(ig);
        e.TrainingTargetToBackgroundDB=10*log10(max(tgtPow,realmin)/max(trainingBgPower,realmin));
        e.RelativeFrobeniusPerturbation=cF;
        e.RelativeInversePerturbation=cInv;
        e.MaxAbsDirectionalPerturbation=max(abs(dir));
        e.ACEBackgroundCovariance=aceB;
        e.ACEContaminatedCovariance=aceBT;
        e.ACEContaminatedToBackgroundRatio=aceRatio;
        e.ACEChangeDB=10*log10(max(aceBT,realmin)/max(aceB,realmin));
        e.AdaptiveSINRRatioAtBackgroundBestAngle=sinrRatio(bestB);
        e.AdaptiveSINRLossAtBackgroundBestAngleDB=-10*log10(max(sinrRatio(bestB),realmin));
        e.MinAdaptiveSINRRatio=minRatio;
        e.MaxAdaptiveSINRLossDB=-10*log10(max(minRatio,realmin));
        e.ConditionNumberBackground=cond(MB);
        e.ConditionNumberContaminated=cond(MBT);
        e.BestAngleBackground=bestB;
        e.BestAngleContaminated=bestBT;
        entry(iE,ig)=e;
    end
end

D=struct();
D.NumTrainingCells=K;
D.TruthNativeRangeBin=cutNativeIdx;
D.TruthDopplerIndex=truthQ;
D.ExclusionBins=Elist;
D.TargetGainDB=gDB;
D.RangeGateBins=rOff;
D.DopplerGateBins=qOff;
D.Entry=entry;
D.GeometryComparison=[];
if isfield(cfg,'GeometryComparisonBins') && numel(cfg.GeometryComparisonBins)==2
    pair=double(cfg.GeometryComparisonBins(:).');
    i1=find(Elist==pair(1),1); i2=find(Elist==pair(2),1);
    assert(~isempty(i1) && ~isempty(i2),'Case2:trainingDiagGeometryPair', ...
        'GeometryComparisonBins must both be present in ExclusionBins.');
    G=repmat(struct('TargetGainDB',NaN,'FirstExclusionBins',pair(1), ...
        'SecondExclusionBins',pair(2),'BackgroundACESecondToFirstRatio',NaN, ...
        'ContaminatedACESecondToFirstRatio',NaN),1,nG);
    for ig=1:nG
        G(ig).TargetGainDB=gDB(ig);
        G(ig).BackgroundACESecondToFirstRatio= ...
            entry(i2,ig).ACEBackgroundCovariance/max(entry(i1,ig).ACEBackgroundCovariance,realmin);
        G(ig).ContaminatedACESecondToFirstRatio= ...
            entry(i2,ig).ACEContaminatedCovariance/max(entry(i1,ig).ACEContaminatedCovariance,realmin);
    end
    D.GeometryComparison=G;
end
D.Definition=['Background covariance and background-plus-target covariance use identical ' ...
    'training indices, NSCM and shrinkage loading. ACE uses the same composite gate data; ' ...
    'only the covariance supplied to whitening changes.'];
end

function M=localLoadedCovariance_(Y,K)
M=helperShrinkageLoading(helperNSCM(Y),K);
M=(M+M')/2;
end

function Ainv=localHermitianInverse_(A)
[L,p]=chol((A+A')/2,'lower');
assert(p==0,'Case2:trainingDiagInverseNotPD','Loaded covariance is not positive definite.');
I=eye(size(A),'like',A);
Ainv=L'\(L\I);
Ainv=(Ainv+Ainv')/2;
end
