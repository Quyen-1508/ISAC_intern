classdef h38901ISACChannel < matlab.System
%h38901ISACChannel TR 38.901 ISAC channel model
%
%   h38901ISACChannel properties:
%
%   SensingMode           - ISAC sensing mode
%                           ("TRP Monostatic", "UE Monostatic",
%                           "TRP-UE Bistatic", "UE-TRP Bistatic",
%                           "TRP-TRP Bistatic", "UE-UE Bistatic")
%                           (default "TRP-UE Bistatic")
%   SensingScenario       - ISAC sensing scenario
%                           ("ISAC-UAV", "ISAC-Human", "ISAC-AGV",
%                           "ISAC-Automotive") (default "ISAC-Human")
%   CommunicationScenario - Communication scenario (values "UMi", "UMa",
%                           "RMa", "InH", "InF-SL", "InF-DL", "InF-SH",
%                           "InF-DH", "InF-HH", "UMi-AV", "UMa-AV",
%                           "RMa-AV") (default "UMa")
%   STX                   - Configuration of sensing transmitter (STX) node
%   STs                   - Configurations of sensing target (ST) nodes
%   SRX                   - Configuration of sensing receiver (SRX) node
%   RCSModel              - RCS model option ("Model 1", "Model 2")
%                           (default "Model 1")
%   SigmaD                - Second component of RCS-related coefficient
%                           (default [])
%   LinkRayCoupling       - Link ray coupling option
%                           ("Option 1", "Option 2") (default "Option 1")
%   ThresholdPower        - Threshold X (dB) for removing paths in Step 10
%                           (default -25)
%   InterSiteDistance     - Intersite distance in meters (default 500)
%   Wrapping              - Geographical distance-based wrapping
%                           (true, false) (default true)
%   UpdateDistance        - Update distance (m) for spatially consistent
%                           mobility (default 1.0)
%   Seed                  - Random number generator (RNG) seed (default 0)
%   OfficeType            - Office type for InH scenario ("Mixed", "Open")
%                           (default "Mixed")
%   ScenarioExtents       - Location and size of the scenario (default [])
%   HallSize              - Dimensions of hall for InF scenarios
%                           (default [120 60 10])
%   ClutterSize           - Clutter size for InF scenarios (default 2)
%   ClutterDensity        - Clutter density for InF scenarios (default 0.6)
%   ClutterHeight         - Clutter height for InF scenarios (default 6)
%   CenterFrequency       - Center frequency of the carrier in Hz
%                           (default 6e9)
%   LOSProbability        - LOS probability (default [])
%   SampleRate            - Input signal sample rate (Hz) (default 30.72e6)
%   PathGainSampleRate    - Path gain generation sample rate choice
%                           ('signal' or 'auto') (default 'auto')
%   InitialTime           - Start time of fading process (s) (default 0.0)
%   BackgroundChannel     - Enable / disable background channel
%                           (true, false) (default true)
%   TargetChannel         - Enable / disable target channel (true, false)
%                           (default true)
%   ChannelFiltering      - Perform filtering of input signal (true, false)
%                           (default true)
%   NumTimeSamples        - Number of time samples (positive integer)
%                           (default 30720)
%   HasSmallScale         - Enable / disable small scale channel 
%                           (true, false) (default true)
%   FastFading            - Enable / disable fast fading (true, false)
%                           (default true)
%   AbsoluteTOA           - Absolute time of arrival for background channel
%                           (true, false) (default true)
%   BackgroundPowerOffset - Power offset (dB) for background channel
%                           (default 0)
%   TargetPowerOffset     - Power offset (dB) for target channel
%                           (default 0)
%
%   h38901ISACChannel object functions:
%
%   h38901ISACChannel           - Create ISAC channel model
%   h38901ISACChannel.Node      - Create a default node
%   step                        - Filter input signal through ISAC channel
%                                 model (ChannelFiltering = true) or
%                                 generate channel coefficients
%                                 (ChannelFiltering = false)
%   release                     - Allow property value and input
%                                 characteristics changes
%   clone                       - Create an ISAC channel object with same
%                                 property values
%   isLocked                    - Locked status (logical)
%   reset                       - Reset states of filters
%   info                        - Return characteristic information about
%                                 the ISAC channel model
%   getPathFilters              - Get filter impulse responses for the 
%                                 filters which apply the path delays to
%                                 the input waveform
%
%   See also nrCDLChannel. 

%   Copyright 2025-2026 The MathWorks, Inc.
    
    properties (Access = public)

        % InitialTime
        InitialTime (1,1) double ...
            {mustBeReal, mustBeNonnegative, mustBeFinite} ...
            = 0.0;

    end

    properties(Access = public, Nontunable)

        % Input signal sample rate (Hz) (default 30.72e6)
        SampleRate (1,1) double ...
            {mustBePositive, mustBeFinite} ...
            = 30.72e6;

        % Path gain generation sample rate choice ("signal" or "auto")
        % (default "auto"). 
        PathGainSampleRate (1,1) string ...
            {matlab.system.mustBeMember(PathGainSampleRate, ...
            ["auto" "signal"])} ...
            = "auto";

        % ISAC sensing mode ("TRP Monostatic", "UE Monostatic", "TRP-UE
        % Bistatic", "UE-TRP Bistatic", "TRP-TRP Bistatic", "UE-UE
        % Bistatic") (default "TRP-UE Bistatic")
        SensingMode (1,1) string ...
            {matlab.system.mustBeMember(SensingMode, ...
            ["TRP Monostatic" "UE Monostatic" "TRP-UE Bistatic" ...
            "UE-TRP Bistatic" "TRP-TRP Bistatic" "UE-UE Bistatic"])} ...
            = "TRP-UE Bistatic";

        % ISAC sensing scenario ("ISAC-UAV", "ISAC-Human", "ISAC-AGV",
        % "ISAC-Automotive") (default "ISAC-Human")
        SensingScenario (1,1) string ...
            {matlab.system.mustBeMember(SensingScenario, ...
            ["ISAC-UAV" "ISAC-Human" "ISAC-AGV" "ISAC-Automotive"])} ...
            = "ISAC-Human";

        % RCS model option ("Model 1", "Model 2") (default "Model 1").
        % "Model 1" characterizes a sensing target as a single scattering
        % point. "Model 2" supports multiple scattering points. "Model
        % 1" can only be used for the "ISAC-Human" and "ISAC-UAV" sensing
        % scenarios. 
        RCSModel (1,1) string ...
            {matlab.system.mustBeMember(RCSModel, ...
            ["Model 1" "Model 2"])} ...
            = "Model 1";

        % Second component of RCS-related coefficient (default []),
        % representing the small-scale angular-dependent factor of the RCS.
        % When a value is not provided (by default), this property is
        % derived from other RCS-related components. 
        SigmaD double {mustBeScalarOrEmpty,mustBeReal} = []; 

        % Communication scenario (values "UMi", "UMa", "RMa", "InH",
        % "InF-SL", "InF-DL", "InF-SH", "InF-DH", "InF-HH", "UMi-AV",
        % "UMa-AV", "RMa-AV") (default "UMa")
        CommunicationScenario (1,1) string ...
            {matlab.system.mustBeMember(CommunicationScenario, ...
            ["UMi" "UMa" "RMa" "InH" ...
            "InF-SL" "InF-DL" "InF-SH" "InF-DH" "InF-HH" ...
            "UMi-AV" "UMa-AV" "RMa-AV"])} ...
            = "UMa";

        % Link ray coupling option for Step 9 ("Option 1", "Option 2")
        % (default "Option 1"). Option 1 directly couples all rays while
        % option 2 randomly couples the rays.
        LinkRayCoupling (1,1) string ...
            {matlab.system.mustBeMember(LinkRayCoupling, ...
            ["Option 1" "Option 2"])} ...
            = "Option 1";

        % Threshold X (dB) for removing paths in Step 10 (default -25)
        ThresholdPower (1,1) double ...
            {mustBeReal, mustBeFinite} ...
            = -25;

    end

    properties (Access = public)

        % The sensing transmitter (STX) node is a structure configured 
        % using the following fields:
        % Position                 - Position of STX in Cartesian 
        %                            coordinates [x y z] (m)
        % Velocity                 - Velocity (v) of STX in the form 
        %                            [vx vy vz] (m/s)
        % RotationVelocity         - Rotation velocity (ω) of the STX in
        %                            the direction of positive bearing
        %                            angle α, downtilt angle β, and slant
        %                            angle γ, specified as a real-valued
        %                            vector of the form [ωα; ωβ; ωγ] (RPM).
        %                            These values are used to update the
        %                            orientation of the antenna array of
        %                            the STX.
        % TransmitAntennaArray     - Structure specifying the transmit 
        %                            antenna array characteristics, see
        %                            nrCDLChannel/TransmitAntennaArray for
        %                            details. If empty, the array is
        %                            created based on the value of the
        %                            NumTransmitAntennas property.
        % NumTransmitAntennas      - The number of transmit antennas. The
        %                            default value is 1. 
        % TransmitArrayOrientation - Orientation of the transmit antenna
        %                            array. See
        %                            nrCDLChannel/TransmitArrayOrientation.
        STX (1,1) struct ...
            {validateNodes(STX,"STX",0)} ...
            = validateNodes(struct(Position=[0 0 25],NumTransmitAntennas=1),"STX",0);

        % STs (sensing targets) is a structure array configured using the 
        % following fields:
        % Position          - Position of ST, specified as a real-valued
        %                     vector in Cartesian coordinates [x y z] (m)
        % Velocity          - Velocity (v) of ST in the x-, y-, and 
        %                     z-directions, specified as a real-valued 
        %                     vector of the form [vx vy vz] (m/s)
        % RotationVelocity  - Rotation velocity (ω) of the ST in the 
        %                     direction of positive bearing angle α,
        %                     downtilt angle β, and slant angle γ,
        %                     specified as a real-valued vector of the form
        %                     [ωα; ωβ; ωγ] in rotations per minute (RPM). 
        % Orientation       - Orientation of the ST [alpha; beta; gamma] in
        %                     degrees (bearing, downtilt, slant). The
        %                     default values [0; 0; 0] indicate that the ST
        %                     faces the positive x-axis.
        % Size              - Size of the ST, a 3-by-1 vector [L W H]
        %                     where L is the ST length, W is the ST width
        %                     and H is the ST height in meters (default
        %                     [0.5 0.5 1.75]).
        % MultipleSPSTs     - Specify whether sensing target is comprised
        %                     of more than one scattering point 
        %                     (false, true) (default false). Can only be
        %                     set to true with "ISAC-Automotive" and 
        %                     "ISAC-AGV" sensing scenarios combined with 
        %                     RCS Model 2.
        %
        % Provide multiple STs as a 1-by-K struct array, where K is the
        % number of sensing targets present in the channel
        STs (1,:) struct ...
            {validateNodes(STs,"STs",0)} ...
            = validateNodes(struct(Position=[145 -122 1.75/2]),"STs",0);

        % The sensing receiver (SRX) node is a structure configured 
        % using the following fields:
        % Position                 - Position of SRX in Cartesian 
        %                            coordinates [x y z] (m)
        % Velocity                 - Velocity (v) of SRX in the form 
        %                            [vx vy vz] (m/s)
        % RotationVelocity         - Rotation velocity (ω) of the SRX in
        %                            the direction of positive bearing
        %                            angle α, downtilt angle β, and slant
        %                            angle γ, specified as a real-valued
        %                            vector of the form [ωα; ωβ; ωγ] (RPM).
        %                            These values are used to update the
        %                            orientation of the antenna array of
        %                            the SRX.
        % ReceiveAntennaArray      - Structure specifying the receive 
        %                            antenna array characteristics, see
        %                            nrCDLChannel/ReceiveAntennaArray for
        %                            details. If empty, the array is
        %                            created based on the value of the
        %                            NumReceiveAntennas property.
        % NumReceiveAntennas       - The number of receive antennas. The
        %                            default value is 1. 
        % ReceiveArrayOrientation  - Orientation of the receive antenna
        %                            array. See
        %                            nrCDLChannel/ReceiveArrayOrientation.
        SRX (1,1) struct ...
            {validateNodes(SRX,"SRX",0)} ...
            = validateNodes(struct(Position=[3 100 1.75/2],NumReceiveAntennas=1),"SRX",0);

     end

    properties(Access = public, Nontunable)

        % Location and size of the scenario, a four-element vector of the
        % form [left bottom width height]. The elements are defined as 
        % follows:
        %   left -   The X coordinate of the left edge of the scenario in 
        %            meters
        %   bottom - The Y coordinate of the bottom edge of the scenario in 
        %            meters
        %   width  - The width of the scenario in meters, that is, the 
        %            right edge of the scenario is left + width
        %   height - The height of the scenario in meters, that is, the 
        %            top edge of the scenario is bottom + height
        % Use empty ([]) to automatically calculate the value. For UMi, UMa
        % and RMa scenarios, the value is calculated assuming that each TRP
        % lies at the center of a hexagonal cell with the size given by the
        % InterSiteDistance property. For InF scenarios, the value is
        % calculated from the HallSize property assuming that the hall is
        % centered on (0,0). For other scenarios, the value is calculated
        % from the locations of the STX, STs and SRX. (default [])
        ScenarioExtents double ...
            {validateScenarioExtents(ScenarioExtents)} ...
            = [];

        % Intersite distance in meters (default 500)
        InterSiteDistance (1,1) double ...
            {mustBeReal, mustBePositive, mustBeFinite} ...
            = 500;

        % Random number generator (RNG) seed (default 0)
        Seed (1,1) double ...
            {mustBeReal, mustBeInteger, mustBeNonnegative} ...
            = 0;

        % Center frequency of the carrier in Hz (default 6e9)
        CenterFrequency (1,1) double ...
            {mustBeReal, mustBeNonnegative, mustBeFinite} ...
            = 6e9;

        % Geographical distance-based wrapping (true, false) (default
        % true).
        Wrapping (1,1) ...
            {mustBeNumericOrLogical} ...
            = false;

        % LOS probability (default []). Set this property to a value
        % between 0 and 1. 
        LOSProbability double ...
            {mustBeScalarOrEmpty, mustBeBetween(LOSProbability,0,1)} ...
            = [];

        % Office type for InH scenario ("Mixed", "Open") (default "Mixed")
        OfficeType (1,1) string ...
            {matlab.system.mustBeMember(OfficeType, ...
            ["Mixed" "Open"])} ...
            = "Mixed";

        % Dimensions of hall for InF scenarios (default [120 60 10])
        HallSize (1,3) double ...
            {mustBeReal, mustBePositive, mustBeFinite} ...
            = [120 60 10];

        % Clutter size for InF scenarios (default 2)
        ClutterSize (1,1) double ...
            {mustBeReal, mustBeNonnegative, mustBeFinite} ...
            = 2;

        % Clutter density for InF scenarios (default 0.6)
        ClutterDensity (1,1) double ...
            {mustBeBetween(ClutterDensity,0,1)} ...
            = 0.6;

        % Clutter height for InF scenarios (default 6)
        ClutterHeight (1,1) double ...
            {mustBeReal, mustBeNonnegative, mustBeFinite} ...
            = 6;

        % Update distance (m) for spatially consistent mobility (default
        % 1.0).
        UpdateDistance (1,1) double ...
            {mustBeReal, mustBeNonnegative, mustBeFinite} ...
            = 1.0;

        % Enable / disable background channel (true, false) (default true).
        BackgroundChannel (1,1) ...
            {mustBeNumericOrLogical} ...
            = true;

        % Enable / disable target channel (true, false) (default true). 
        TargetChannel (1,1) ...
            {mustBeNumericOrLogical} ...
            = true;

        % Perform filtering of input signal (true, false) (default true).
        ChannelFiltering (1,1) ...
            {mustBeNumericOrLogical} ...
            = true;

        % Number of time samples (default 30720). This value must be a
        % positive integer.
        NumTimeSamples (1,1) ...
            {mustBeReal, mustBePositive, mustBeFinite} ...
            = 30720;

        % Enable / disable small scale channel (true, false) (default
        % true).
        HasSmallScale (1,1) ...
            {mustBeNumericOrLogical} ...
            = true;

        % Enable / disable fast fading (true, false) (default true).
        FastFading (1,1) ...
            {mustBeNumericOrLogical} ...
            = true;

        % Absolute time of arrival for background channel (true, false)
        % (default true). This property must be set to "true" for all four
        % TRP-TRP, TRP-UE, UE-TRP and UE-UE bistatic sensing modes. 
        AbsoluteTOA (1,1) ...
            {mustBeNumericOrLogical} ...
            = true;

        % Power offset for background channel for Section 7.9.5.3 power
        % normalization
        BackgroundPowerOffset (1,1) double ...
            {mustBeReal, mustBeFinite} ...
            = 0;

        % Power offset for target channel for Section 7.9.5.3 power
        % normalization
        TargetPowerOffset (1,1) double ...
            {mustBeReal, mustBeFinite} ...
            = 0;

    end

    methods (Access = public)

        % constructor 
        function obj = h38901ISACChannel(varargin)

            setProperties(obj,nargin,varargin{:});

        end

        % get path filters 
        function pf = getPathFilters(obj)

            performSetup(obj);
            if (obj.ChannelFiltering && isLocked(obj))
                pf = obj.pathFilters;
            else
                pf = makePathFilters(obj);
            end

        end

    end

    methods (Static, Access = public)

        function n = Node()

            n = validateNode([],false);

        end

    end

    methods (Access = protected)

        function setupImpl(obj)

            performSetup(obj);

        end

        function num = getNumInputsImpl(obj)

            num = double(obj.ChannelFiltering);

        end

        function varargout = stepImpl(obj,varargin)
            % Filter a waveform through the channels, or generate channel
            % coefficients

            % Validate input signal
            if (obj.ChannelFiltering)
                txWaveform = varargin{1};
                validateInputSignal(obj,txWaveform);
            end

            if (obj.HasSmallScale && isSpatiallyConsistentMobility(obj))
                % Perform spatially-consistent mobility check / update,
                % based on current node property values. The channel is
                % updated when the distance between nodes has changed by an
                % amount greater than or equal to the UpdateDistance
                % property. The distance is calculated based on time since
                % the last update and the value of Velocity properties of
                % the nodes at the last update. Note that none of the node
                % property values are updated here, for example the
                % Position is not updated on account of the Velocity, and
                % Orientation is not updated on account of the
                % RotationVelocity; all updates to property values must be
                % made externally
                spatiallyConsistentMobility(obj);
            end

            if (obj.ChannelFiltering)
                T = size(txWaveform,1);
            else 
                T = obj.NumTimeSamples;
            end
            Nc = numel(obj.channels);
            sampleDensity = getSampleDensity(obj);

            pg = cell(1,Nc);
            st = cell(1,Nc);
            for i = 1:Nc % background and target links

                c = obj.channels{i};

                % Execute small scale channel
                [pg{i},st{i}] = c.SmallScaleStep(i,T);

                % Execute large scale channel
                PLdB = c.LargeScaleStep(i);
                pg{i} = pg{i} * db2mag(-PLdB);

            end

            % Store path gains and sample times in info output
            obj.theInfo.PathGains = pg;
            obj.theInfo.SampleTimes = st;

            % Assemble overall path gains and sample times
            if (sampleDensity==Inf)
                pathGains = cat(2,pg{:});
                sampleTimes = st{1};
            else
                [sampleTimes,cidx] = getHighestRateSampleTimes(st);
                pathGains = assembleOverallPathGains(obj.SampleRate,pg,st,cidx);
            end

            % Combine path gains that map to the same channel filter delay
            Np = size(pathGains,2);
            if (Nc > 1 && Np > 1)
                pdm = obj.pathDelayMapping;
                pathGains = combineSameDelayPathGains(pdm,pathGains);
            end

            % Perform channel filtering
            if (obj.ChannelFiltering)
                f = obj.channelFilter;
                rxWaveform = wireless.internal.channelmodels.smartChannelFiltering(txWaveform,f,f.SampleRate,pathGains,size(txWaveform),sampleDensity,sampleTimes,class(txWaveform),1);
                if (isempty(obj.pathFilters))
                    obj.pathFilters = makePathFilters(obj);
                end
            end

            % Advance the time according to the input length
            obj.theTime = obj.theTime + (T / obj.SampleRate);

            if (obj.ChannelFiltering)
                varargout = {rxWaveform,pathGains,sampleTimes};
            else
                varargout = {pathGains,sampleTimes};
            end
            varargout = varargout(1:max(nargout,1));

        end

        function resetImpl(obj)

            % reset the time to the last InitialTime property value set
            obj.theTime = obj.InitialTime;

            % reset the background channel
            ss = obj.channels{1}.SmallScale;
            if (~isempty(ss) && ~isstruct(ss))
                reset(obj.channels{1}.SmallScale);
            end

            % reset channel filter
            if (obj.ChannelFiltering)
                reset(obj.channelFilter);
            end

            % reset Doppler phase continuity information, to ensure phase
            % is not continuous. When initial time is changed, this is to
            % get the channel starting from initial time without any
            % dependency on previous channel evolution
            Nc = numel(obj.channels);
            Nbc = getNumBackgroundChannels(obj.SensingMode);
            if (Nc > Nbc && obj.HasSmallScale)
                obj.theDopplerStruct = newDopplerStructs(obj);
            end

            % reset mobility management
            for i = 1:Nbc
                obj.channels{i}.Mobility.manager = [];
            end
            for i = (Nbc+1):Nc
                obj.channels{i}.tx2st.Mobility.manager = [];
                obj.channels{i}.st2rx.Mobility.manager = [];
            end

        end

        function releaseImpl(obj)

            if (obj.ChannelFiltering)
                release(obj.channelFilter);
            end

            for n = ["STX" "STs" "SRX"]
                for i = 1:numel(obj.(n))
                    node = obj.(n);
                    node = node(i);
                    releaseArrayObject(node.TransmitAntennaArray);
                    releaseArrayObject(node.ReceiveAntennaArray);
                end
            end

            function releaseArrayObject(aa)
                if (~isempty(aa) && ~isstruct(aa))
                    release(aa);
                end
            end

        end

        function s = infoImpl(obj)

            performSetup(obj);
            s = obj.theInfo;

        end

        function processTunedPropertiesImpl(obj)

            if (isChangedProperty(obj,'InitialTime'))

                % If the tuned InitialTime changes the current time (to the
                % same tolerance as used to design fractional delay
                % filters)
                if (abs(obj.theTime - obj.InitialTime) > (obj.maxFractionalDelayError/obj.SampleRate))

                    % Set the time to the InitialTime property value
                    obj.theTime = obj.InitialTime;

                    % Update the background channel time
                    ss = obj.channels{1}.SmallScale;
                    if (~isempty(ss) && ~isstruct(ss))
                        obj.channels{1}.SmallScale.InitialTime = obj.InitialTime;
                    end

                    % Reset channel filter
                    if (obj.ChannelFiltering)
                        reset(obj.channelFilter);
                    end

                    % Reset Doppler phase continuity information, to ensure
                    % phase is not continuous. When initial time is
                    % changed, this is to get the channel starting from
                    % initial time without any dependency on previous
                    % channel evolution
                    if (obj.HasSmallScale)
                        obj.theDopplerStruct = newDopplerStructs(obj);
                    end

                end

            end

            if (isChangedProperty(obj,'STX'))
                obj.STX = validateNodes(obj.STX,"STX",true);
            end

            if (isChangedProperty(obj,'STs'))
                obj.STs = validateNodes(obj.STs,"STs",true);
            end

            if (isChangedProperty(obj,'SRX'))
                obj.SRX = validateNodes(obj.SRX,"SRX",true);
            end

        end

    end

    properties (Access = private, Constant)

        % maximum allowable fractional delay error, used to determine if an
        % InitialTime update requires a filter reset
        maxFractionalDelayError = 0.01;

        % source of low-level TR 38.901 processing steps
        nr5g = nr5g.internal.channel38901;

    end

    properties (Access = public, Hidden)

        SpatialConsistency;

        % Enable / disable reference TR updates (true, false) (default
        % true). 
        ReferenceTR (1,1) ...
            {mustBeNumericOrLogical} ...
            = true;

        % If true, only the LOS ray is modeled and free space path loss
        % (fspl) is used as the path loss model (true, false) (default
        % false).
        LOSRayOnly (1,1) ...
            {mustBeNumericOrLogical} ...
            = false;

    end

    properties (Access = private)

        channels;

        % State set up during performSetup()
        theTime;
        SCRVs;
        theInfo;
        pathDelays;
        pathDelayMapping;
        channelFilter;
        pathFilters;

        % State set up during performSetup(), resetImpl() or
        % processTunedPropertiesImpl()
        theDopplerStruct;

    end

    methods (Access = public, Hidden)

        function c = getChannels(obj)

            performSetup(obj);
            c = obj.channels;

        end

    end

    methods (Access = private)

        function validate(obj)

            validateThresholdPower(obj);

            if (~obj.BackgroundChannel && ~obj.TargetChannel)
                error('nr5g:h38901ISACChannel:NoChannelsEnabled','The background channel and target channel cannot both be disabled.');
            end

            if (~obj.BackgroundChannel && numel(obj.STs)==0)
                error('nr5g:h38901ISACChannel:NoBackgroundOrSTs','The background channel must be enabled if no STs are configured.');
            end

            if (strcmpi(obj.RCSModel,"Model 1"))
                if (~any(strcmpi(obj.SensingScenario,["ISAC-UAV" "ISAC-Human"])))
                    error('nr5g:h38901ISACChannel:InvalidScenarioRCSModel1','RCS model 1 is only applicable for "ISAC-Human" and "ISAC-UAV" sensing scenarios.');
                end
            end

            validateApplicableCommunicationScenarios(obj);

            obj.STX = validateNodes(obj.STX,"STX",true);
            obj.STs = validateNodes(obj.STs,"STs",true);
            obj.SRX = validateNodes(obj.SRX,"SRX",true);

            if (any(strcmpi(obj.SensingMode,["UE Monostatic" "TRP Monostatic"])))

                if (any(obj.STX.Position ~= obj.SRX.Position) || ...
                    any(obj.STX.Velocity ~= obj.SRX.Velocity) || ...
                    any(obj.STX.RotationVelocity ~= obj.SRX.RotationVelocity) || ...
                    any(obj.STX.Orientation ~= obj.SRX.Orientation) || ...
                    any(obj.STX.Size ~= obj.SRX.Size))

                    error('nr5g:h38901ISACChannel:InvalidMonostaticConfiguration','For "UE Monostatic" and "TRP Monostatic" sensing modes, the following fields of both the STX and SRX properties must be equal: Position, Velocity, RotationVelocity, Orientation, and Size.');

                end

                if ~isequal(obj.STX.NodeSiz,obj.SRX.NodeSiz) || ~isequal(obj.STX.NodeSubs,obj.SRX.NodeSubs)

                    error('nr5g:h38901ISACChannel:InvalidMonostaticConfiguration','For "UE Monostatic" and "TRP Monostatic" sensing modes, the following fields of both the STX and SRX properties must be equal: NodeSiz and NodeSubs.');

                end

            end

        end

        function validateInputSignal(obj,in)

            ninsig = obj.info.NumInputSignals;
            if (size(in,2)~=ninsig)
                error('nr5g:h38901ISACChannel:SignalInputNotMatchTxArray','The number of columns of the signal input (%d) must be equal to the number of antenna elements or subarrays defined in TransmitAntennaArray (%d).',size(in,2),ninsig);
            end

        end

    end

end

function validateScenarioExtents(val)

    if (~isempty(val))
        if (~isrow(val) || ~(numel(val)==4))
            error('nr5g:h38901ISACChannel:InvalidScenarioExtents','Value must be empty or be a 4-element row vector [left bottom width height].');
        end
    end

end

function out = validateNodes(val,role,crossvalidate)

    N = numel(val);
    out = repmat(validateNode([],false),1,N);
    for i = 1:N
        nvps = namedargs2cell(val(i));
        out(i) = validateNode(role,crossvalidate,nvps{:});
    end

end

function s = validateNode(role,crossvalidate,s)

    arguments

        role;

        crossvalidate;

        % All roles
        s.Position (1,3) double ...
            {mustBeReal,mustBeFinite} ...
            = [0 0 0];
        s.Velocity (1,3) double ...
            {mustBeReal,mustBeFinite} ...
            = [0 0 0];
        s.RotationVelocity (3,1) double ...
            {mustBeReal,mustBeFinite} ...
            = [0; 0; 0];
        s.NodeSubs (1,:) double ...
             {mustBeReal,mustBeNonnegative,mustBeInteger} ...
             = [];
        s.NodeSiz (1,:) double ...
            {mustBeReal,mustBeNonnegative,mustBeInteger} ...
            = [];

        % STX
        s.NumTransmitAntennas double ...
            {mustBeScalarOrEmpty,mustBeReal, ...
            mustBePositive,mustBeInteger} ...
            = [];
        s.TransmitAntennaArray ...
            {mustBeScalarOrEmpty} ... 
            = [];
        s.TransmitArrayOrientation double ...
            {mustBeReal,mustBeFinite} ...
            = [];

        % ST
        s.Orientation (3,1) double ...
            {mustBeReal,mustBeFinite} ...
            = [0; 0; 0];
        s.Size (1,3) double ...
            {mustBeReal,mustBePositive,mustBeFinite} ...
            = [0.5 0.5 1.75];
        s.MultipleSPSTs (1,1) ...
            {mustBeNumericOrLogical} ...
            = false;

        % SRX
        s.NumReceiveAntennas double ...
            {mustBeScalarOrEmpty,mustBeReal, ...
            mustBePositive,mustBeInteger} ...
            = [];
        s.ReceiveAntennaArray ...
            {mustBeScalarOrEmpty} ... 
            = [];
        s.ReceiveArrayOrientation double ...
            {mustBeReal,mustBeFinite} ...
            = [];

        % TRP
        s.TXRUVirtualization struct ...
            {mustBeScalarOrEmpty} ... 
            = [];

        % UE
        s.d_2D_in double ...
            {mustBeScalarOrEmpty,mustBeReal, ...
            mustBeNonnegative,mustBeFinite} ...
            = [];
        s.n_fl double ...
            {mustBeScalarOrEmpty,mustBeReal, ...
            mustBeNonnegative,mustBeInteger} ...
            = [];

    end

    if (~isempty(role))
        switch (role)
            case "STX"
                if (crossvalidate && isempty(s.NumTransmitAntennas) && isempty(s.TransmitAntennaArray))
                    error('nr5g:h38901ISACChannel:NoAntennasSTX','For the STX, either NumTransmitAntennas or TransmitAntennaArray must be specified.');
                end
                warnNonEmpty(s,'STX','NumReceiveAntennas');
                warnNonEmpty(s,'STX','ReceiveAntennaArray');
                warnNonEmpty(s,'STX','ReceiveArrayOrientation');
            case "STs"
                warnNonEmpty(s,'ST','NumTransmitAntennas');
                warnNonEmpty(s,'ST','TransmitAntennaArray');
                warnNonEmpty(s,'ST','TransmitArrayOrientation');
                warnNonEmpty(s,'ST','NumReceiveAntennas');
                warnNonEmpty(s,'ST','ReceiveAntennaArray');
                warnNonEmpty(s,'ST','ReceiveArrayOrientation');
            case "SRX"
                if (crossvalidate && isempty(s.NumReceiveAntennas) && isempty(s.ReceiveAntennaArray))
                    error('nr5g:h38901ISACChannel:NoAntennasSRX','For the SRX, either NumReceiveAntennas or ReceiveAntennaArray must be specified.');
                end
                warnNonEmpty(s,'SRX','NumTransmitAntennas');
                warnNonEmpty(s,'SRX','TransmitAntennaArray');
                warnNonEmpty(s,'SRX','TransmitArrayOrientation');
        end
    end

end

function warnNonEmpty(s,role,f)

    if (~isempty(s.(f)))
        warning(['nr5g:h38901ISACChannel:NonRelevantProperty' role],'For an %s, the %s property of the node is not relevant.',role,f);
    end

end

function validateThresholdPower(obj)
    % "The value of X can be up to -25 and -40 respectively for Option 1 and
    % Option 2 in Step 9. The value X is up to company choice"

    lrc = obj.LinkRayCoupling;
    switch (lrc)
        case "Option 1"
            maxX = -25;
        case "Option 2"
            maxX = -40;
    end

    X = obj.ThresholdPower;
    if (X > maxX)
        eargs = {'For LinkRayCoupling = "%s", ThresholdPower (X = %g dB) must be less than or equal to %g dB.',lrc,X,maxX};
        error('nr5g:h38901ISACChannel:InvalidThresholdPower',eargs{:});
    end

end

function validateApplicableCommunicationScenarios(obj)

    % Table 7.9.1-1
    if (strcmpi(obj.SensingScenario,"ISAC-UAV"))
        if (~any(strcmpi(obj.CommunicationScenario,["UMi" "UMa" "RMa" "UMi-AV" "UMa-AV" "RMa-AV"])))
            error('nr5g:h38901ISACChannel:InvalidCommunicationScenarioUAV','For the "ISAC-UAV" sensing scenario, the communication scenario must be one of: "UMi", "UMa", "RMa", "UMi-AV", "UMa-AV", and "RMa-AV".');
        end
    end

    % Table 7.9.1-2
    if (strcmpi(obj.SensingScenario,"ISAC-Automotive"))
        if (~any(strcmpi(obj.CommunicationScenario,["UMi" "UMa" "RMa"])))
            error('nr5g:h38901ISACChannel:InvalidCommunicationScenarioAutomotive','For the "ISAC-Automotive" sensing scenario, the communication scenario must be one of: "UMi", "UMa", and "RMa".');
        end
    end

    % Table 7.9.1-3
    if (strcmpi(obj.SensingScenario,"ISAC-Human"))
        if (~any(strcmpi(obj.CommunicationScenario,["UMi" "UMa" "RMa" "InH" "InF-SL" "InF-DL" "InF-SH" "InF-DH" "InF-HH"])))
            error('nr5g:h38901ISACChannel:InvalidCommunicationScenarioHuman','For the "ISAC-Human" sensing scenario, the communication scenario must be one of: "UMi", "UMa", "RMa", "InH", "InF-SL", "InF-DL", "InF-SH", "InF-DH", and "InF-HH".');
        end
    end

    % Table 7.9.1-4
    if (strcmpi(obj.SensingScenario,"ISAC-AGV"))
        if (~any(strcmpi(obj.CommunicationScenario,["InF-SL" "InF-DL" "InF-SH" "InF-DH" "InF-HH"])))
            error('nr5g:h38901ISACChannel:InvalidCommunicationScenarioAGV','For the "ISAC-AGV" sensing scenario, the communication scenario must be be one of: "InF-SL", "InF-DL", "InF-SH", "InF-HH", and "InF-DH".');
        end
    end

end

function channel = createISACChannelLink(obj)

    % Get information about TRP and UE nodes and their roles in the links
    nodeinfo = getNodeInfo(obj);

    % Create separate channel configurations for the STX-SRX background
    % component, the STX-ST target component, the ST-SRX target component,
    % and a common cfg for shared ISAC-specific properties
    [isaccfg,bcfg,tx2stcfg,st2rxcfg] = getChannelLinkConfigurations(obj,nodeinfo);

    [K,P] = size(tx2stcfg); % K sensing targets and P scattering points per target

    % Background Channel
    backgroundChannel = backgroundChannelLink(obj,bcfg);

    % Target Channel
    if obj.TargetChannel
        S = backgroundChannel{1}.NumTransmitAntennas;
        U = backgroundChannel{1}.NumReceiveAntennas;
        targetChannel = cell(K,P);
        for k = 1:K
            for p = 0:P-1
                targetChannel{k,p+1} = fastFadingChannelModelISAC(obj,isaccfg(k,p+1),tx2stcfg(k,p+1),st2rxcfg(k,p+1),nodeinfo,S,U);
            end
        end
        channel = [backgroundChannel,targetChannel(:).'];
    else
        channel = backgroundChannel;
    end
    
end

function [isaccfg,bcfg,tx2stcfg,st2rxcfg] = getChannelLinkConfigurations(obj,nodeinfo)
% Set up separate link configurations for the background and target channel
% components to align with Section 7.5 fast fading model terminology 

% The ISAC channel uses STX/ST/SRX terminology but needs configured to
% UE/TRP and their respective TX/RX roles for the separate component links.

% This function handles the six ISAC sensing modes of "TRP Monostatic", "UE
% Monostatic", "TRP-UE Bistatic", "UE-TRP Bistatic", "TRP-TRP Bistatic", &
% "UE-UE Bistatic"

% Note: the target channel and ISAC-related link configurations tx2stcfg,
% st2rxcfg and isaccfg are K-by-P arrays of configurations, where K is the
% number of sensing targets and P is the number of scattering points per
% target

    % ---------------------------------------------------------------------
    % Set the parameters common to both the background and target channel
    % configurations. These parameters are used by Section 7.5 Steps 1-8.

    chcfg.HasSmallScale = obj.HasSmallScale;
    if (~isempty(obj.SpatialConsistency))
        chcfg.SpatialConsistency = obj.SpatialConsistency;
    else
        chcfg.SpatialConsistency = "ProcedureB";
    end
    chcfg.Wrapping = obj.Wrapping;
    chcfg.CenterFrequency = obj.CenterFrequency;
    chcfg.Seed = obj.Seed;
    chcfg.LOSProbability = obj.LOSProbability;
    chcfg.InterSiteDistance = obj.InterSiteDistance;
    chcfg.OfficeType = obj.OfficeType;
    chcfg.HallSize = obj.HallSize;
    chcfg.ClutterSize = obj.ClutterSize;
    chcfg.ClutterDensity = obj.ClutterDensity;
    chcfg.ClutterHeight = obj.ClutterHeight;
    chcfg.SampleRate = obj.SampleRate;
    chcfg.CommunicationScenario = obj.CommunicationScenario;

    % ---------------------------------------------------------------------
    % Set ISAC-related parameters used by Section 7.9.4 Steps 9-15

    isaccfg = struct();
    isaccfg.SensingTarget = getSensingTarget(obj.SensingScenario);
    isaccfg.SensingMode = obj.SensingMode;
    isaccfg.RCSModel = obj.RCSModel;
    isaccfg.SigmaD = obj.SigmaD;
    isaccfg.LinkRayCoupling = obj.LinkRayCoupling;
    isaccfg.ThresholdPower = obj.ThresholdPower;
    isaccfg.Seed = obj.Seed;
    isaccfg.TargetChannel = obj.TargetChannel;
    isaccfg.HasSmallScale = obj.HasSmallScale;
    isaccfg.FastFading = obj.FastFading;
    isaccfg.LOSRayOnly = obj.LOSRayOnly;

    % ---------------------------------------------------------------------
    % Background (STX -> SRX) configuration

    bcfg = chcfg;
    bcfg.FastFading = obj.FastFading;
    
    % Additional fields required for Section 7.5 Steps 9-12
    bcfg.AbsoluteTOA = obj.AbsoluteTOA; 

    bcfg = getLinkConfiguration(obj,isaccfg,bcfg,nodeinfo,"STX","SRX");

    % Set the TRP site positions for the background channel - the SCRVs
    % will be generated from the background channel createChannelLink call
    % and re-used for the target channel
    sitePositions = getNodePositions(nodeinfo.TRPs);
    UEtoUE = (nodeinfo.STs=="UE") && (nodeinfo.STX=="UE" || nodeinfo.SRX=="UE");
    if (UEtoUE)
        % If any UE-to-UE links exist, set up site positions for all TRPs
        % and UEs for the following reasons:
        % * Some UEs are treated as TRPs when creating channel links
        %   according to Section 7.5 (see sameTypeNodeSubs() for details)
        % * To ensure that the site positions are not empty for 
        %   UE-UE Bistatic and UE Monostatic sensing modes
        % * To ensure that the "link-correlated" spatial consistency type
        %   is implemented for UE-UE links as noted in Table 7.9.5.1-1
        sitePositions = [sitePositions; getNodePositions(nodeinfo.UEs)];
    end
    bcfg.SitePositions = unique(sitePositions,"stable","rows");

    % For monostatic sensing modes, the STX-SRX background channel is
    % generated according to Section 7.9.4.2, which creates the background
    % channel according to three randomly positioned reference points
    if contains(obj.SensingMode,"Monostatic")
        bcfg = monostaticBackgroundReferenceProcedure(obj,bcfg); 
    end

    % ---------------------------------------------------------------------
    % First target (STX -> ST) configuration

    tx2stcfg = chcfg;

    % Empty site positions (SCRVs come from background channel)
    tx2stcfg.SitePositions = [];

    % FastFading must be true if HasSmallScale is true, because some
    % outputs of Section 7.5 Steps 5 to 8 are required in the overall
    % target channel even if fast fading is disabled there
    tx2stcfg.FastFading = obj.HasSmallScale;

    % Additional fields required for Section 7.5 Steps 9-12
    tx2stcfg.AbsoluteTOA = false; 

    if (isaccfg.TargetChannel)
        tx2stcfg = getLinkConfiguration(obj,isaccfg,tx2stcfg,nodeinfo,"STX","STs");
    end

    % ---------------------------------------------------------------------
    % Second target (ST -> SRX) configuration

    st2rxcfg = chcfg;

    % FastFading must be true if HasSmallScale is true, because some
    % outputs of Section 7.5 Steps 5 to 8 are required in the overall
    % target channel even if fast fading is disabled there
    st2rxcfg.FastFading = obj.HasSmallScale;
 
    % Empty site positions (SCRVs come from background channel)
    st2rxcfg.SitePositions = [];

    % Additional fields required for Section 7.5 Steps 9-12
    st2rxcfg.AbsoluteTOA = false;

    if (isaccfg.TargetChannel)
        st2rxcfg = getLinkConfiguration(obj,isaccfg,st2rxcfg,nodeinfo,"STs","SRX");
    end

    % ---------------------------------------------------------------------
    % Per-ST configuration

    % 'tx2stcfg' and 'st2rxcfg' created above are K-by-1 structure arrays
    % where K is the number of STs

    % Set up per-ST aspects of 'isaccfg'
    K = numel(obj.STs);
    isaccfg = arrayfun(@(k)setupPerST(isaccfg,obj.STs(k)),(1:K).');

    % ---------------------------------------------------------------------
    % Per-SPST configuration

    % Add SPST-wise RCS parameters, make isaccfg a K-by-P array
    isaccfg = getRCSparameters(isaccfg);

    % Add SPST-wise Sensing Target parameters, make the target
    % configurations K-by-P arrays
    [tx2stcfg,st2rxcfg] = getSPSTparameters(obj,tx2stcfg,st2rxcfg,isaccfg);

end

function isaccfg = setupPerST(isaccfg,ST)

    isaccfg.TargetSize = ST.Size;
    isaccfg.TargetOrientation = ST.Orientation; 
    isaccfg.TargetVelocity = ST.Velocity;
    isaccfg.MultipleSPSTs = ST.MultipleSPSTs;

end

function sensingTarget = getSensingTarget(sensingScenario)    
% Define sensing target from sensing scenario. The target names are taken
% from the "Target" column of Table 7.9.3-2

    switch (sensingScenario)

        case "ISAC-UAV"

            % "In the ISAC-UAV sensing scenarios, the sensing targets are
            % outdoor UAVs"
            sensingTarget = "UAV";

        case "ISAC-Automotive"

            % "In the ISAC-Automotive sensing scenarios, the sensing
            % targets are passenger vehicles or trucks and buses"
            sensingTarget = "vehicle";

        case "ISAC-Human"

            % "In the ISAC-Human sensing scenarios, the sensing targets are
            % children and adult persons"
            sensingTarget = "human";

        case "ISAC-AGV"

            % "In the ISAC-AGV sensing scenarios, the sensing targets are
            % automated guided vehicles (AGVs)"
            sensingTarget = "AGV";

        case "ISAC-Objects"

            % "In the ISAC-Objects creating hazards on roads/railways
            % sensing scenarios, the sensing targets are adult humans and
            % children and animals"
            sensingTarget = "object (hazard)";

    end

end

function isaccfg = getRCSparameters(isaccfg)
% Obtain the RCS parameters from Tables 7.9.2.1-(1-7), according to the
% target type and RCS model used, and use this to prepare the terms for
% Eqs 7.9.2-1 through to 7.9.2-3, i.e. to define sigma_M*sigma_D,
% sigma_M and sigma_S

% These tables are used in Step 10 of the fast fading model to apply to
% the RCS components to the obtained powers from a path. Note: for
% human with RCS model 2, and for AGV/vehicle with a single scattering
% point, these tables are indexed into based on the theta/phi angles
% within the RCS model. For all other combinations the indexing is
% according to the SPST number.

    K = numel(isaccfg);
    P = zeros(numel(K),1);

    for k = 1:K
        % get RCS params for all the scattering points that apply to this target 
        [rcsParams(:,:,k),P(k)] = rcsParameterTables(isaccfg(k).RCSModel,isaccfg(k).SensingTarget,isaccfg(k).MultipleSPSTs);
    end

    if ~all(P==P(1))
        P = max(P); % to facilitate different sensing target types with different num SPSTs
    else
        P = P(1);
    end

    isaccfg = repmat(isaccfg,1,P);
    
    for k = 1:K
        if P == 1
            isaccfg(k).RCSParameters = rcsParams(:,:,k);
            isaccfg(k).Seed = isaccfg(k).Seed + (k-1); 
        else
            for p = 0:P-1
                isaccfg(k,p+1).RCSParameters = rcsParams(p+1,:,k);
                
                % ensure each isaccfg has different seed for sigma_S to be
                % independent for each SPST of an ST
                isaccfg(k,p+1).Seed = sub2ind([K P],k,p+1) - 1 + isaccfg(k,p+1).Seed; 

                % for targets that can have multiple scattering points,
                % assign each SPST the recommended side of the ST
                if isequal(isaccfg(k,p+1).SensingTarget,"AGV") || isequal(isaccfg(k,p+1).SensingTarget,"vehicle")
                    isaccfg(k,p+1).Side = getTargetSidePerSPST(isaccfg(k,p+1),p+1);
                end
            end
        end
    end

end

function bcfg = monostaticBackgroundReferenceProcedure(obj,bcfg)

    % Section 7.9.4.2: For both TRP monostatic and UE monostatic sensing
    % modes, after Step 1 in Section 7.9.4.0, which is implemented in
    % getLinkConfiguration, the following steps are applied to generate the
    % background channel.

    %----------------------------------------------------------------------
    % Step 2: generate 3 reference points (RPs) for the STX/SRX

    % A) Generate random 2D distances from the STX/SRX and each RP, and the
    % height of each RP, according to a shape-rate parameterized Gamma
    % distribution using parameters from Tables 7.9.4.2-(1-2)

    nRPs = 3; % 3 reference points

    [alpha_d,beta_d,c_d,alpha_h,beta_h,c_h] = getMonostaticReferencePointParameters(obj.SensingMode,bcfg.CommunicationScenario,bcfg.UEPosition(3));

    rs = RandStream('mt19937ar','Seed',bcfg.Seed);
    gammarv = @(a,b)(b * gammaincinv(rs.rand,a));
    d = zeros(1,nRPs);
    h = zeros(1,nRPs);
    for i = 1:nRPs
        d(i) = gammarv(alpha_d,1/beta_d) + c_d; % 2-D distances from the monostatic TRP/UE
        h(i) = gammarv(alpha_h,1/beta_h) + c_h; % heights of each RP
    end

    % B) Draw the LOS AOD for the first RP from a uniform distribution, and
    % subsequently derive the same for the second and third RPs from a set
    % of rotations
    losAOD1 = 2*pi*rs.rand - pi + eps; % uniformly distributed in (-pi,pi]
    losAOD = [losAOD1; losAOD1 + 2*pi/3; losAOD1 + 4*pi/3];

    % C) Consequently find the 3D locations of each RP

    posRP = zeros(nRPs,3);
    for i = 1:nRPs
        posRP(i,1) = bcfg.UEPosition(1) + d(i)*cos(losAOD(i));
        posRP(i,2) = bcfg.UEPosition(1) + d(i)*sin(losAOD(i));
        posRP(i,3) = h(i);
    end

    % Note: Determining LOS ZOD is performed as part of
    % createISACChannelLink. Setting each RP to have the same antenna field
    % patterns and array orientations as the STX/SRX has already been done
    % in getLinkConfiguration. Setting each RP to have the same velocity as
    % the STX/SRX is handled in stepImpl.

    %----------------------------------------------------------------------
    % Step 3: Assign NLOS propagation condition to the channel between the
    % STX/SRX and each of the 3 RPs. Note: O2I is not applicable.

    % This step is handled by setting the LOS probability to zero (ensure
    % NLOS) and d_2D_in to zero (ensure O2I does not apply) for all
    % monostatic background channel configurations. LOS probability is not
    % set when the communication scenario is "InF-HH" as Table 7.4.1-1
    % requires an LOS condition.

    if ~isequal(bcfg.CommunicationScenario,"InF-HH")
        bcfg.LOSProbability = 0;
    end
    bcfg.d_2D_in = 0;

    %----------------------------------------------------------------------
    % Step 4: Generate the channel between the STX/SRX and each of the 3
    % RPs

    % Note: The modifications to Steps 7 and 8 of Section 7.5 are not
    % implemented. The adjustment to the absolute time of arrival is
    % performed as part of createISACChannelLink.

    % "NOTE: In the UT monostatic sensing in UMa and UMi scenario, the ZOD
    % offset should be set as 0"
    if (any(bcfg.CommunicationScenario==["UMa" "UMi"]))
        bcfg.ReferenceTR.ZeroZODOffset = @(ch)zeroZODOffset(obj,ch);
    end

    %----------------------------------------------------------------------
    % Step 5: Generate the background channel for the STX/SRX

    % Note: this step is performed as part of stepImpl.

    %----------------------------------------------------------------------
    % Setup channel configurations for all RPs

    bcfg = positionRPs(obj,bcfg,posRP);

end

function bcfg = positionRPs(obj,bcfg,posRP)

    if obj.SensingMode == "UE Monostatic"

        % Section 7.9.3: "For UT monostatic sensing mode, a RP is
        % considered as a TRP". Set BS positions for RPs and enable
        % swapTransmitAndReceive
        bcfg.swapTransmitAndReceive = true;
        field = "BSPosition";

    else % "TRP Monostatic"

        % For TRP monostatic sensing mode, a reference point (RP) is
        % considered as a terrestrial UE
        field = "UEPosition";

    end

    % Assign reference point positions
    nRPs = size(posRP,2);
    bcfg = repmat(bcfg,1,nRPs);
    for i = 1:nRPs
        bcfg(i).(field) = posRP(i,:);
    end

    scenarioExtents = obj.ScenarioExtents;

    % Check that if scenario extents have been supplied, the system
    % boundary holds the reference point positions
    if (~isempty(scenarioExtents))
        minpos = scenarioExtents(1:2);
        maxpos = minpos + scenarioExtents(3:4);
        for i = 1:nRPs
            if (any(posRP(i,1:2) < minpos) || any(posRP(i,1:2) > maxpos))
                warning('nr5g:h38901ISACChannel:MonostaticBackgroundChannelRPsOutsideScenarioExtents','Reference point position x=%0.3f, y=%0.3f for the monostatic background channel is outside the system boundary x=%0.3f...%0.3f, y=%0.3f...%0.3f. The ScenarioExtents input provided will not be used.',posRP(1,i),posRP(2,i),minpos(1),maxpos(1),minpos(2),maxpos(2));
                scenarioExtents = [];
            end
        end
    end

    if (isempty(scenarioExtents))

        % extend scenario extents based on generated reference point
        % positions
        minB = bcfg(1).ScenarioExtents(1:2);
        maxB = minB + bcfg(1).ScenarioExtents(3:4);
        minRP = [min(posRP(:,1)) min(posRP(:,2))] - [1 1];
        maxRP = [max(posRP(:,1)) max(posRP(:,2))] + [1 1];

        minpos = [min(minB(1),minRP(1)) min(minB(2),minRP(2))];
        maxpos = [max(maxB(1),maxRP(1)) max(maxB(2),maxRP(2))];

        scenarioExtents = [minpos maxpos-minpos];

        [bcfg(1:nRPs).ScenarioExtents] = deal(scenarioExtents);

    end

end

function [alpha_d,beta_d,c_d,alpha_h,beta_h,c_h] = getMonostaticReferencePointParameters(mode,cs,h)
% From Tables 7.9.4.2-(1-2), obtain distance and height parameters for
% monostatic sensing background channel reference points according to the
% sensing mode and communication scenario. Note: the 'h' input is the UE
% height (h_UT), which is only used with '-AV' communication scenarios

    if mode == "TRP Monostatic"

        % Table 7.9.4.2-1
        switch cs

            case {"UMi" "UMi-AV"} 

                alpha_d = 6.1996;
                beta_d = 0.1558;
                c_d = 15.2697;
                alpha_h = 12.0487;
                beta_h = 2.3261;
                c_h = 0.0157;

            case {"UMa" "UMa-AV"}

                alpha_d = 10.3370;
                beta_d = 0.1317;
                c_d = 68.7778;
                alpha_h = 16.2253;
                beta_h = 1.9218;
                c_h = 2.6142;  

            case {"RMa" "RMa-AV"}

                alpha_d = 6.2025;
                beta_d = 0.0391;
                c_d = 1.2940;
                alpha_h = 0.0007;
                beta_h = 5.0146;
                c_h = 0.0522;

            case "InH"

                alpha_d = 4.236;
                beta_d = 0.19255;
                c_d = 4.99;
                alpha_h = 1.3293;
                beta_h = 0.1442;
                c_h = -13.19;  

            case {"InF-SL", "InF-DL", "InF-SH", "InF-DH", "InF-HH"}

                alpha_d = 0.039836;
                beta_d = 0.179783;
                c_d = 1.130020;
                alpha_h = 0.283447;
                beta_h = 0.435965;
                c_h = -17.043530;  

        end

    elseif mode == "UE Monostatic"

        % Table 7.9.4.2-2
        switch cs

            case "UMi"

                alpha_d = 10.0220;
                beta_d = 1.2522;
                c_d = 11.0040;
                alpha_h = 3.0487;
                beta_h = 1.9128;
                c_h = 0.1785;

            case "UMa"

                alpha_d = 2.9072;
                beta_d = 0.1031;
                c_d = 3.8471;
                alpha_h = 1.6640;
                beta_h = 1.6215;
                c_h = -1.4205;

            case "RMa"

                alpha_d = 10.2421;
                beta_d = 0.0526;
                c_d = 3.3131;
                alpha_h = 0.3175;
                beta_h = 1.4150;
                c_h = 1.5906;

            case "UMi-AV"

                alpha_d = 0.0156*h + 5.5399;
                beta_d = 40.4517/(h + 254.6318);
                c_d = 0.0140*h + 15.1184;
                alpha_h = 0.0123*h + 11.9569;
                beta_h = 17.8047/(h - 0.2202);
                c_h = 0.0532*h - 0.0120;

            case "UMa-AV"

                alpha_d = 0.83 + 0.00015*h;
                beta_d = 1/(536.305 + 1.0279*h);
                c_d = 13.824 + 0.03085*h;
                alpha_h = 0.9054 - 0.0001117*h;
                beta_h = 1/(38.672 - 0.04658*h);
                c_h = 25.4898 - 0.02398*h;

            case "RMa-AV"

                alpha_d = 4.423 + 0.001926*h;
                beta_d =  1/(3.8467 + 0.6547*h);
                c_d = 3.864 + 0.1538*h;
                alpha_h = 1.4231 + 0.00192*h;
                beta_h = 1/(1.7157 - 0.00538*h);
                c_h = 2.6541 - 0.003851*h;

            case "InH"

                alpha_d = 4.3733;
                beta_d = 0.4457;
                c_d = 4.6302;
                alpha_h = 0.2974;
                beta_h = 0.4103;
                c_h = 2.9711;

            case {"InF-SL", "InF-DL", "InF-SH", "InF-DH", "InF-HH"}

                alpha_d = 0.231418;
                beta_d = 0.128133;
                c_d = 2.004903;
                alpha_h = 0.462968;
                beta_h = 0.281526;
                c_h = -16.921515;

        end

    end

end

function [rcsParams,P] = rcsParameterTables(rcsModel,sensingTarget,multipleSPSTs)

    if rcsModel == "Model 1" 

        % For RCS Model 1, the target is modelled as a single scattering
        % point so isaccfg is a K-by-1 array of configurations

        % Table 7.9.2.1-1
        % rcsParams is [sigma_M_dB,std_S_dB]
        switch sensingTarget
            case "UAV" 
                outM = -12.81; outS = 3.74;
            case "human"
                outM =  -1.37; outS = 3.94;
            otherwise
                assert(sensingTarget == "UAV" || sensingTarget == "human","For RCS Model 1, the sensing target can only be a human or UAV")
        end 

        rcsParams = [outM,outS]; 
        P = 1;

    elseif rcsModel == "Model 2"

        % For RCS Model 2, the target can be modelled as either a single
        % scattering point or multiple scattering points so isaccfg is a
        % K-by-P array of configurations where P >= 1

        % Tables 7.9.2.1-(2-7)

        % rcsParams is P rows of [phiC,phi3dB,thetaC,theta3dB,G_max,sigma_max,sigma_M_dB,std_S_dB]
        % NaNs represent '-' (N/A) values in the tables 

        switch sensingTarget

            case "UAV"
                %Table 7.9.2.1-2
                % N.B. NaN represents special handling of theta ranges 
                rcsParams = [ 90  7.13  90  8.68  7.43 14.30 -5.85 2.50;
                             180 10.09  90 11.43  3.99 10.86 -5.85 2.50;
                             270  7.13  90  8.68  7.43 14.30 -5.85 2.50;
                               0 14.19  90 16.53  1.02  7.89 -5.85 2.50;
                             NaN   NaN 180  4.93 13.55 20.42 -5.85 2.50;
                             NaN   NaN   0  4.93 13.55 20.42 -5.85 2.50];

                P = 1;

            case "human"
                %Table 7.9.2.1-3
                % 1 SPST with angular dependent behaviour, 8 parameters
                rcsParams = [  0 216.65 90 55.7 2.14 7.7 -1.37 3.94;
                             180 216.65 90 55.7 2.14 7.7 -1.37 3.94];

                P = 1; 
   
            case "vehicle"

                if ~multipleSPSTs
                % Table 7.9.2.1-4 (single co-located scattering point with applicable phi range)
                % 8 parameters (range of theta/phi not output)
                rcsParams = [90 26.90 79.70 44.42 20.75 13.68 11.25 3.41;
                            180 36.32 79.65 36.73 14.56 7.50 11.25 3.41;
                            270 26.90 79.70 44.42 20.75 13.68 11.25 3.41;
                            0 40.54 71.75 29.13 15.52 8.45 11.25 3.41;
                            NaN NaN 0 18.13 21.26 14.19 11.25 3.41];
                P = 1;
                else
                % Table 7.9.2.1-5 (multiple scattering points)
                % 5 SPSTs, 8 parameters (range of theta/phi not output)
                rcsParams = [90 26.90 79.70 44.42 20.60 20.52 11.25 3.41;         
                            180 36.32 79.65 36.73 13.90 13.82 11.25 3.41;  
                            270 26.90 79.70 44.42 20.60 20.52 11.25 3.41; 
                            0 40.54 71.75 29.13 14.99 14.91 11.25 3.41;  
                            NaN NaN 0.00 18.13 21.12 21.05 11.25 3.41];
                P = 5; 
                end

            case "AGV"

                if ~multipleSPSTs 
                % Table 7.9.2.1-6 (single co-located scattering point with applicable theta and phi range)
                % 8 parameters (range of theta/phi not output)
                rcsParams = [0 13.68 90 13.68 13.02 23.29 -4.25 2.51;
                            90 15.53 75 20.03 7.33 17.60 -4.25 2.51; 
                            180 12.49 90 11.89 11.01 21.28 -4.25 2.51; 
                            270 15.53 75 20.03 7.33 17.60 -4.25 2.51; 
                            NaN NaN 0 11.44 11.79 22.06 -4.25 2.51]; 

                P = 1;
                else
                % Table 7.9.2.1-7 (multiple scattering points)
                % 5 SPSTs, 8 parameters (range of theta/phi not output)
                rcsParams = [0 13.68 90 13.68 13.00 30.26 -4.25 2.51;
                            90 15.53 75 20.03 7.27 24.53 -4.25 2.51;
                            180 12.49 90 11.89 10.98 28.24 -4.25 2.51;
                            270 15.53 75 20.03 7.27 24.53 -4.25 2.51;
                            NaN NaN 0 11.44 11.77 29.03 -4.25 2.51];
                P = 5;
                end

        end

    end

end

function side = getTargetSidePerSPST(isaccfg,idx)

    if isequal(isaccfg.SensingTarget,"AGV")

        % Table 7.9.2.1-7
        switch idx
            case 1
                side = "front";
            case 2 
                side = "left";
            case 3 
                side = "back";
            case 4
                side = "right";
            case 5
                side = "roof";
        end

    else % vehicle

        % Table 7.9.2.1-5 n.b. order different to AGV
        switch idx
            case 1
                side = "left";
            case 2 
                side = "back";
            case 3 
                side = "right";
            case 4
                side = "front";
            case 5
                side = "roof";
        end

    end

end


function [tx2stcfg,st2rxcfg] = getSPSTparameters(obj,tx2stcfg,st2rxcfg,isaccfg)

    % Number of targets and maximum number of scattering points per target 
    [K,P] = size(isaccfg);

    tx2stcfg = repmat(tx2stcfg,1,P);
    st2rxcfg = repmat(st2rxcfg,1,P);

    if obj.TargetChannel

        for k = 1:K
    
            for p = 0:P-1
    
                % Define SPST position in GCS 
                tx2stcfg(k,p+1) = getSPSTPosition(isaccfg(k,p+1),tx2stcfg(k,p+1),"tx2st");
                st2rxcfg(k,p+1) = getSPSTPosition(isaccfg(k,p+1),st2rxcfg(k,p+1),"st2rx");
    
            end
    
        end

    end

end

function chcfg = getSPSTPosition(isaccfg,chcfg,link)
% Get SPST position in GCS

    targetSize = isaccfg.TargetSize;
    targetOrientation = isaccfg.TargetOrientation;

    % get offset in GCS
    offset = getSPSTOffset(isaccfg,targetSize);
    R = wireless.internal.channelmodels.rotationMatrix(targetOrientation);
    offset = R*offset;

    % define SPST GCS position
    f = getSPSTPositionField(chcfg,link);
    chcfg.(f) = chcfg.(f) + offset.';
   
end

function f = getSPSTPositionField(chcfg,link)

    f = ["UEPosition" "BSPosition"];
    idx = 1 + xor(link=="st2rx",chcfg.swapTransmitAndReceive);
    f = f(idx);

end

function offset = getSPSTOffset(isaccfg,targetSize)

    switch isaccfg.SensingTarget
        
        % handle sensing target height offset 

        case "UAV"

            % for a UAV, no offset is applied, the centroid position of the
            % ST is the SPST position
            offset = [0; 0; 0];

        case "human"

            % for a human, the SPST is of height 1.5 m (defined below Table
            % 7.9.3-3), define position offset in LCS 
            hSPST = 1.5;         
            Z = targetSize(3)/1.75 * hSPST; % scale height relative to adult human
            offset = [0; 0; (Z - targetSize(3)/2)]; 

        case "vehicle"

            if isaccfg.MultipleSPSTs

                % Table 7.9.6.1-3: A vehicle with size L*W*H can be dropped with
                %5 scattering points (front/left/right/back/roof), respectively
                % with locations (L/2,0,H/2), (0,W/2,H/2), (0,-W/2,H/2),
                % (-L/2,0,H/2) and (0,0,H) in LCS
                offset = getMultipleSPSTOffsets(isaccfg.Side,targetSize);

            else

                % Table 7.9.6.1-3: a vehicle with size L*W*H can be dropped
                % with 1 scattering point with location (0,0,H/2) in LCS
                offset = [0; 0; targetSize(3)/2]; 

            end

        case "AGV"

            if isaccfg.MultipleSPSTs

                % Section 7.9.2.1: "For vehicle and AGV modelled with
                % multiple scattering points, the recommended five
                % scattering points are located at the front, left, back,
                % right and roof side of the vehicle respectively". Table
                % 7.9.6.1-3 sets options for automotive SPST positions
                % which are re-used here for AGV. 
                offset = getMultipleSPSTOffsets(isaccfg.Side,targetSize);

            else

                offset = [0; 0; targetSize(3)/2]; 

            end

    end  

end

function offset = getMultipleSPSTOffsets(side,targetSize)
    
    x = 0;
    y = 0; 
    z = 0;

    switch side
        case "front"
            x = targetSize(1)/2;
            z = targetSize(3)/2;   
        case "left"   
            y = targetSize(2)/2;
            z = targetSize(3)/2;   
        case "right"   
            y = -targetSize(2)/2;
            z = targetSize(3)/2;
        case "back"
            x = -targetSize(1)/2;
            z = targetSize(3)/2;   
        case "roof"
            z = targetSize(3);  
    end

    offset = [x; y; z]; 

end

function linkcfg = getLinkConfiguration(obj,isaccfg,linkcfg,nodeinfo,tx,rx,k)

    % Configure field name for relevant link in nodeinfo
    link = tx + "to" + rx;

    % Get "The proper case ... provided in Table [7.9.3-2 / 7.9.3-3]"
    linkcfg.Case = getLinkCase(isaccfg,nodeinfo,tx,rx);

    % Handle the case of multiple STs (or no STs)
    if (nargin==6)
        K = size(nodeinfo.(link).NodeSubs,1);
        if (K>1)
            args = {obj,isaccfg,linkcfg,nodeinfo,tx,rx};
            linkcfg = arrayfun(@(k)getLinkConfiguration(args{:},k),(1:K).');
            return;
        elseif (K==0)
            linkcfg = linkcfg(false);
            return;
        else
            k = 1;
        end
    end

    % Get node subscripts and size vector for this link and for node 'k'
    linkcfg.NodeSubs = nodeinfo.(link).NodeSubs(k,:);
    linkcfg.NodeSiz = nodeinfo.(link).NodeSiz;

    % Get transmit and receive nodes, before considering swapping
    txNode = obj.(tx);
    rxNode = obj.(rx);
    
    % Get node 'k'
    if (numel(txNode)~=1)
        txNode = txNode(k);
    end
    if (numel(rxNode)~=1)
        rxNode = rxNode(k);
    end

    % Configure number of antennas for STs, required to allow Section 7.5
    % Step 12 to run in the createChannelLink() call inside steps1to8()
    if (tx=="STs")
        txNode.NumTransmitAntennas = 1;
    end
    if (rx=="STs")
        rxNode.NumReceiveAntennas = 1;
    end

    % Swap nodes for the case of a UE -> TRP link, this also involves
    % swapping transmit and receive antenna properties
    isUplink = nodeinfo.(link).isUplink;
    linkcfg.swapTransmitAndReceive = (~isnan(isUplink) && isUplink);
    if (linkcfg.swapTransmitAndReceive)
        [txNode,rxNode] = swapNodes(txNode,rxNode);
    end

    % Configure BS and UE positions for Step 1 c)
    linkcfg.BSPosition = txNode.Position;
    linkcfg.UEPosition = rxNode.Position;

    % Configure parameters for Step 1 d) "Give BS and UT antenna field
    % patterns and array geometries"
    linkcfg = fieldprecedence(linkcfg,txNode,'TransmitAntennaArray','NumTransmitAntennas');
    linkcfg = fieldprecedence(linkcfg,rxNode,'ReceiveAntennaArray','NumReceiveAntennas');

    % Configure parameters related to UE dropping in Step 1 c) (number of
    % floors and 2-D indoor distance) and parameters for Step 1 e) "Give BS
    % and UT array orientations"
    novirt = struct(K=1,Tilt=0,L=1,Pan=0);
    default_n_fl = getDefaultNumFloors(isaccfg,rxNode,rx);
    if (isnan(isUplink))
        % TRP-to-TRP or UE-to-UE link
        if (nodeinfo.(tx)=="TRP")
            % TRP-to-TRP link, treat receiving TRP like an outdoor UE
            linkcfg.TXRUVirtualization = getFieldOrDefault(txNode,'TXRUVirtualization',novirt);
            linkcfg.TransmitArrayOrientation = getFieldOrDefault(txNode,'TransmitArrayOrientation',[]);
            linkcfg.n_fl = 0;
            linkcfg.d_2D_in = 0;
            linkcfg.ReceiveArrayOrientation = [];
        else
            % UE-to-UE link, treat transmitting UE like a TRP with no TXRU
            % virtualization
            linkcfg.TXRUVirtualization = novirt;
            linkcfg.TransmitArrayOrientation = [];
            linkcfg.n_fl = getFieldOrDefault(rxNode,"n_fl",default_n_fl);
            linkcfg.d_2D_in = getFieldOrDefault(rxNode,"d_2D_in",0);
            linkcfg.ReceiveArrayOrientation = getFieldOrDefault(rxNode,'ReceiveArrayOrientation',[]);
        end
    else
        % TRP-to-UE or UE-to-TRP link
        linkcfg.TXRUVirtualization = getFieldOrDefault(txNode,'TXRUVirtualization',novirt);
        linkcfg.TransmitArrayOrientation = getFieldOrDefault(txNode,'TransmitArrayOrientation',[]);
        linkcfg.n_fl = getFieldOrDefault(rxNode,"n_fl",default_n_fl);
        linkcfg.d_2D_in = getFieldOrDefault(rxNode,"d_2D_in",0);
        linkcfg.ReceiveArrayOrientation = getFieldOrDefault(rxNode,'ReceiveArrayOrientation',[]);
    end

    % Tables 7.9.3-1/4/5 and updates described below Table 7.9.3-3
    linkcfg = getReferenceTR(obj,linkcfg,tx,rx);

    % Get scenario extents based on link-specific communication scenario
    [linkcfg.ScenarioExtents,linkcfg.ScenarioExtentsZ] = getScenarioExtents(obj,linkcfg,nodeinfo);

end

function c = getLinkCase(isaccfg,nodeinfo,tx,rx)

    persistent k;
    persistent v;
    if (isempty(k))

        % This table merges Tables 7.9.3-2 and 7.9.3-3, including reversing
        % the statement "the targets of UAV and vehicle are respectively
        % considered as an aerial UE and vehicle UE" that appears above
        % 7.9.3-2. Also to facilitate the merging of the tables, a
        % terrestrial UE is considered as a human and an aerial UE is
        % considered as a UAV
        t = {
            % STX   ->    ST
            % SRX   <-    ST
            % STX   ->    SRX
            % SRX   <-    STX              Case
            "TRP"       "TRP"                1
            "TRP"       "human"              2
            "TRP"       "vehicle"            3
            "TRP"       "UAV"                4
            "TRP"       "AGV"                2
            "TRP"       "object (hazard)"    2
            "TRP"       "RSU-type"          10
            "human"     "human"              5
            "human"     "vehicle"            6
            "human"     "UAV"                7
            "human"     "AGV"                5
            "human"     "object (hazard)"    5
            "human"     "RSU-type"          11
            "vehicle"   "human"              6
            "vehicle"   "vehicle"            8
            "vehicle"   "object (hazard)"    6
            "vehicle"   "RSU-type"          13
            "UAV"       "UAV"                9
            "AGV"       "AGV"                5
            "RSU-type"  "human"             11
            "RSU-type"  "vehicle"           13
            "RSU-type"  "RSU-type"          12
            };

        k = cell2mat(t(:,1:2));
        v = cell2mat(t(:,3));

    end

    c0 = getCombination(isaccfg,nodeinfo,tx,rx);
    c = v(all(k==c0,2));
    if (tx=="STX" && rx=="SRX" && isempty(c))
        % If the combination was not found in Table 7.9.3-3 with the first
        % two columns as [STX SRX], search again with the first two columns
        % as [SRX STX]
        c0 = fliplr(c0);
        c = v(all(k==c0,2));
    end

end

function c = getCombination(isaccfg,nodeinfo,tx,rx)

    c = [getTxRx(isaccfg,nodeinfo,tx) getTxRx(isaccfg,nodeinfo,rx)];

    if tx == "STX" && rx == "SRX"
        if isequal(isaccfg.SensingMode,"TRP Monostatic")
            % For TRP monostatic sensing mode, a reference point (RP) is
            % considered as a terrestrial UE
            c(2) = "human";
        elseif isequal(isaccfg.SensingMode,"UE Monostatic") 
            % For UT monostatic sensing mode, a RP is considered as a TRP
            c(2) = "TRP";
        end
    end

    if (tx=="STs")
        c = fliplr(c);
    end
    if (tx=="STX" && rx=="SRX" && isaccfg.SensingMode=="UE-TRP Bistatic")
        c = fliplr(c);
    end

end

function v = getTxRx(isaccfg,nodeinfo,x)

    if (x=="STs")
        v = isaccfg.SensingTarget;
    else
        v = nodeinfo.(x);
        if (v=="UE")
            if (isaccfg.SensingTarget=="human")
                v = "human";
            else
                if (x=="STX")
                    UE = nodeinfo.UEs{1};
                else % "SRX"
                    UE = nodeinfo.UEs{end};
                end
                if (isaccfg.SensingTarget=="UAV")
                    if (UE.Position(3) >= 1.5)
                        % Aerial UE
                        v = "UAV";
                    else
                        % Terrestrial UE
                        v = "human";
                    end
                elseif (isaccfg.SensingTarget=="AGV")
                    v = "AGV";
                else % vehicle
                    v = "vehicle";
                end
            end
        else
            % v = "TRP"
        end
    end

    if isequal(isaccfg.SensingMode,"UE Monostatic") 
        % "For UT monostatic sensing mode ... an aerial UE is considered as
        % a terrestrial UE"
        if v == "UAV" && x ~= "STs"
            v = "human";
        end
    end

end

function [txNode,rxNode] = swapNodes(txNode,rxNode)

    % Swap transmit and receive antenna properties
    ap = @(x)["Num"+x+"Antennas" x+"AntennaArray" x+"ArrayOrientation"];
    txap = ap("Transmit");
    rxap = ap("Receive");
    for i = 1:3
        rxNode.(txap(i)) = rxNode.(rxap(i));
        txNode.(rxap(i)) = txNode.(txap(i));
    end

    % Swap nodes
    temp = rxNode;
    rxNode = txNode;
    txNode = temp;

end

function n_fl = getDefaultNumFloors(isaccfg,node,role)

    size = node.Size;
    isaccfg.MultipleSPSTs = node.MultipleSPSTs;
    isaccfg.Side = "front";

    if (role=="STs")
        offset = getSPSTOffset(isaccfg,size);
        offset = offset(3);
    else
        offset = 0;
    end

    H = node.Position(3);
    H = H + offset;
    n_fl = round((H-1.5)/3 + 1);

end

function ch = backgroundChannelLink(obj,bcfg)

    Nbc = getNumBackgroundChannels(obj.SensingMode);
    ch = cell(1,Nbc);

    for i = 1:Nbc
        ch{i} = backgroundChannelPoint(obj,bcfg(i));
    end
 
end

function ch = backgroundChannelPoint(obj,bcfg)

% For bistatic sensing modes, the singular STX-SRX background channel is
% generated according to the existing 38.901 fast fading model

% For monostatic sensing modes, the three background channels are generated
% according to a reference procedure defined in Section 7.9.4.2, which
% creates three reference points away from the monostatic STX-SRX. 

    bcfg = applyConfigReferenceTR(bcfg);
    if (isempty(obj.SCRVs))
        setupSCRVs(obj,bcfg);
    end
    ch = obj.nr5g.createChannelLink(setfield(setfield(bcfg,AbsoluteTOA=false),SitePositions=[]),obj.SCRVs);
    ch = respondToSmallScaleBackgroundUpdate(obj,ch);
    ch = updateChannelReferenceTR(ch,true);
    ch.SmallScaleStep = @(idx,T)backgroundStep11(obj,idx,T);

    if (bcfg.swapTransmitAndReceive)
        % channel38901.createChannelLink creates downlink links, that is,
        % TRP -> UE. For UE -> TRP links, configure as a reciprocal link.
        % The large scale channel is swapped inside largeScale() below
        if (~isempty(ch.SmallScale) && ~isstruct(ch.SmallScale))
            swapTransmitAndReceive(ch.SmallScale);
        end
    end

    ch.LargeScale = largeScale(obj,ch,ch.ChannelConfiguration,ch);
    ch.LargeScaleStep = @(idx)backgroundStep12(obj,idx);

    ch.bcfg = bcfg;

end

function ch = respondToSmallScaleBackgroundUpdate(obj,ch)

    chcfg = ch.ChannelConfiguration;

    [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(setfield(chcfg,SitePositions=[]),obj.SCRVs);
    ch = addDataFields(ch,data);

    if (obj.AbsoluteTOA)
        ch = absoluteTOA(obj,chcfg,ch,ch);
    end

    fastFading = chcfg.HasSmallScale && chcfg.FastFading;

    if (obj.LOSRayOnly)
        ch = keepLOSRayOnly(ch);
    end

    if (fastFading && ~isLocked(ch.SmallScale))
        ch.SmallScale.SampleDensity = getSampleDensity(obj);
    end

    if (~obj.BackgroundChannel)
        ch.PathDelays = zeros([1 0]);
    elseif (~chcfg.HasSmallScale)
        ch.PathDelays = 0;
    end

end

function setupSCRVs(obj,bcfg)

    % Call createChannelLink with HasSmallScale and FastFading to ensure
    % that SCRVs are all set up, in case target channel needs them even if
    % background channel doesn't
    bcfg.AbsoluteTOA = false;
    bcfg.HasSmallScale = true;
    bcfg.FastFading = true;
    SCRVs = [];
    [~,~,SCRVs] = obj.nr5g.createChannelLink(bcfg,SCRVs);

    % Set up SCRVs for absolute time of arrival
    obj.SCRVs = setupSCRVsForAbsoluteTOA(obj,bcfg,SCRVs);

end

function ch = keepLOSRayOnly(ch)

    chcfg = ch.ChannelConfiguration;
    fastFading = chcfg.HasSmallScale && chcfg.FastFading;
    if (fastFading && ~isLocked(ch.SmallScale))
        ss = ch.SmallScale;
        if (ss.HasLOSCluster)
            ss.PathDelays = ss.PathDelays(1);
            ss.AveragePathGains = 0;
            ss.AnglesAoD = ss.AnglesAoD(1);
            ss.AnglesAoA = ss.AnglesAoA(1);
            ss.AnglesZoD = ss.AnglesZoD(1);
            ss.AnglesZoA = ss.AnglesZoA(1);
            ss.KFactorFirstCluster = fix(10*log10(realmax));
            ss.NumStrongestClusters = 0;
            ss.XPR = ss.XPR(1,:);
            ss.RayCoupling = ss.RayCoupling(1,:,:);
            ss.InitialPhases = ss.InitialPhases(1,:,:);
            ch.SmallScale = ss;
            ssinfo = info(ss);
            ch.PathDelays = ssinfo.PathDelays;
            ch.PathFilters = getPathFilters(ss);
            if (~isempty(ch.Mobility.tau_prime))
                ch.Mobility.tau_prime = ch.Mobility.tau_prime(1);
                ch.Mobility.tau = ch.Mobility.tau(1);
            end
        end
    end

end

% Tables 7.9.3-1/4/5 and updates described below Table 7.9.3-3
function chcfg = getReferenceTR(obj,chcfg,tx,rx)

    combinationCase = chcfg.Case;
    cs = chcfg.CommunicationScenario;
    csNonAV = strrep(cs,"-AV","");
    chcfg.ReferenceTR = emptyReferenceTR();

    if (~obj.ReferenceTR)
        % If reference TRs are disabled, select an invalid combination case
        % so that the switch statement below will have no effect
        combinationCase = NaN;
    end

    % Table 7.9.3-1
    switch (combinationCase)

        case 1

            % "For sensing scenario UMi/UMi-AV, UMa/UMa-AV, RMa/RMa-AV,
            % InH, InF"

            if (~startsWith(cs,"RMa"))

                % "TRP-TRP link of scenario UMi, UMa, InH, and InF
                % following the option based on TR 38.901 defined in Clause
                % A.3 of TR 38.858"
                chcfg = setupTR38858(obj,chcfg);

            else % RMa/RMa-AV

                % "TRP-UE link of scenario RMa defined in Clause 7 of TR
                % 38.901 by setting h_UE=35m (see note 1)". % "NOTE 1: ASA
                % and ZSA statistics updated to be the same as ASD and ZSD;
                % ZoD offset = 0"

                chcfg = setupRMa_TRP_UE(obj,chcfg);

            end

        case 2

            % "For sensing scenario UMi/UMi-AV, UMa/UMa-AV, RMa/RMa-AV,
            % InH, InF ... TRP-UE link ... in Clause 7 of TR 38.901"
            % no update required

        case 4

            % "For sensing scenario UMa-AV, UMi-AV, and RMa-AV"

            % "TRP-aerial UE link ... in Clause Annex A and B of TR 36.777
            % for FR1 ... reuse ... FR1 for FR2"
            chcfg = setupTR36777(obj,chcfg);

        case 5

            % "For sensing scenario UMi/UMi-AV, UMa/UMa-AV, RMa/RMa-AV,
            % InH, InF"

            if (~startsWith(cs,"RMa"))

                % "UE-UE link of scenario UMi, UMa, InH, and InF following
                % the option based on TR 38.901 defined in Clause A.3 of TR
                % 38.858"
                chcfg = setupTR38858(obj,chcfg);

            else % RMa/RMa-AV

                % "TRP-UE link of scenario RMa defined in Clause 7 of TR
                % 38.901 by setting h_BS = 1.5m (see note 2)". "NOTE 2: ASD
                % and ZSD statistics updated to be the same as ASA and ZSA"
                chcfg = setupRMa_TRP_UE(obj,chcfg);

            end

        case 7

            % "For sensing scenario UMa-AV, UMi-AV, and RMa-AV"

            % "TRP-aerial UE link of UMi-AV in Annex A and B of TR 36.777
            % by setting h_BS=1.5m for FR1 ... reuse ... FR1 for FR2"
            chcfg = setupTR36777(obj,chcfg);

        case 9

            % "For sensing scenario UMa-AV, UMi-AV, and RMa-AV"

            % "TRP-aerial UE link of UMi-AV in Annex A and B of TR 36.777
            % by setting height of TRP equal to the height of the first
            % aerial UE for FR1 (see note 4) ... reuse ... FR1 for FR2".
            % "NOTE 4: "First aerial UE height is h_UT1, second aerial UE
            % height is h_UT2, where abs(h_UT1-h_BS) <= abs(h_UT2-h_BS)"
            chcfg = setupTR36777(obj,chcfg);

    end

    if (obj.ReferenceTR)

        % "For sensing scenario UMi, UMa, the height of a scattering point
        % of a target is used to calculate ... pathloss ... except that
        % h_UT = 1.5 m is assumed for breakpoint distance calculation"
        if (any(strcmpi(cs,["UMi" "UMa"])) && any(strcmpi("STs",[tx rx])))
            chcfg.ReferenceTR.PathLoss = makeCustomPathLossFn(@pathLossST);
        end

        isCellularAV = endsWith(cs,"-AV");
        if (isCellularAV)

            % TRP - TRP link, TRP - terrestrial UE, TRP - aerial UE
            if (any(combinationCase==[1 2 4]))
                % "the absolute delay model of scenarios UMi, UMa and RMa
                % are respectively used"
                chcfg.ReferenceTR.ScenarioAbsoluteToA = csNonAV;
            end

            % terrestrial UE - terrestrial UE, terrestrial UE - aerial UE,
            % aerial UE - aerial UE
            if (any(combinationCase==[5 7 9]))
                % "the absolute delay model of scenario UMi is used"
                chcfg.ReferenceTR.ScenarioAbsoluteToA = "UMi";
            end

        end

    end

    % Record scenario after "-AV" suffix (if present) has been removed,
    % unless case-specific setup above has already selected a scenario
    if (~isfield(chcfg,'Scenario'))
        chcfg.Scenario = csNonAV;
    end

end

function s = emptyReferenceTR()

    s = struct();
    s.LOSProbability = [];
    s.PathLoss = [];
    s.AngleSpread = [];
    s.ZeroZODOffset = [];
    s.NodeHeight = [];
    s.SF = [];
    s.K = [];
    s.O2I = [];
    s.ScenarioAbsoluteToA = [];

end

function chcfg = applyConfigReferenceTR(chcfg)

    refTR = chcfg.ReferenceTR;

    % Apply reference TR node height adjustments
    if (~isempty(refTR.NodeHeight))
        chcfg = refTR.NodeHeight(chcfg);
    end

    % Apply reference TR LOS probability
    if (isempty(chcfg.LOSProbability) && ~isempty(refTR.LOSProbability))
        chcfg.LOSProbability = refTR.LOSProbability(chcfg);
    end

    % ScenarioAbsoluteToA in handled inside steps9to15()

    % PathLoss is handled inside largeScale()

end

function ch = updateChannelReferenceTR(ch,isBackground)

    newPathLoss = false;

    chcfg = ch.ChannelConfiguration;
    refTR = chcfg.ReferenceTR;

    if (~isempty(refTR.K))
        ch = refTR.K(ch);
    end

    if (~isempty(refTR.SF))
        ch = refTR.SF(ch);
        newPathLoss = true;
    end

    if (~isempty(refTR.O2I))
        ch = refTR.O2I(ch);
        newPathLoss = true;
    end

    if (~isempty(refTR.AngleSpread))
        ch = refTR.AngleSpread(ch,isBackground);
    end

    if (~isempty(refTR.ZeroZODOffset))
        ch = refTR.ZeroZODOffset(ch);
    end

    % If a custom path loss function has not been specified
    if (isempty(refTR.PathLoss))
        if (newPathLoss || isBackground)
            % If SF and/or O2I have been updated, create a custom path loss
            % function to ensure that the updated SF and/or O2I are used
            % - or -
            % If configuring the background channel, create a custom path
            % loss function to fit with the function largeScale()
            ch.ChannelConfiguration.ReferenceTR.PathLoss = makeCustomPathLossFn(@nrPathLoss);
        end
    end

end

function out = makeCustomPathLossFn(fn)

    out = @(chdata)@(plc)@(txpos,rxpos,freq)(fn(setfield(plc,EnvironmentHeight=chdata.h_E),freq,chdata.LOS,txpos.',rxpos.') + chdata.O2I - chdata.SF);

end

% "The option based on TR 38.901 defined in Clause A.3 of TR 38.858"
function chcfg = setupTR38858(obj,chcfg)

    combinationCase = chcfg.Case;
    cs = chcfg.CommunicationScenario;
    cs = strrep(cs,"-AV","");

    switch (combinationCase)

        case 1

            % TRP-TRP link
            % Table A.3-2: gNB-gNB channel model

            % Large-scale channel parameters
            if (cs=="UMa")
                %  Macro-to-Macro: UMa in TR 38.901 (h_UE=25m)
                h_UE = 25;
            elseif (cs=="UMi")
                % Micro-to-Micro: UMi-Street canyon in TR 38.901 (h_UE=10m)
                h_UE = 10;
            elseif (cs=="InH" || startsWith(cs,"InF"))
                % TRP-to-TRP: InH-Office in TR 38.901 (h_UE=3m)
                % Indoor TRP to Indoor TRP: For Indoor factory layer: InF
                % in TR 38.901 (h_UE=3m)
                h_UE = 3;
                % Penetration loss is not modelled
                chcfg.ReferenceTR.O2I = @O2I_TR38858_gNB_gNB;
            end
            chcfg.Scenario = cs;
            chcfg.ReferenceTR.NodeHeight = @(chcfg)set_h_UE(chcfg,h_UE);
            % NOTE 2
            chcfg.ReferenceTR.LOSProbability = @(chcfg)losProbabilityTR38858_gNB_gNB(obj,chcfg);
            % NOTE 3
            % "Regarding gNB-gNB channel model with UMa, extend the
            % applicability range of hUT from 13m=<hUT<=23m to
            % 13m=<hUT<=25m in the formula to get C(d2D,hUT) in Table
            % 7.4.1-1 (Pathloss models) in TR 38.901"
            % no update required, nr5g.internal.channel38901 already
            % supports this

            % Fast fading parameters
            if (any(cs==["UMa" "UMi"]))
                % Macro-to-Macro or Micro-to-Micro: ASA and ZSA statistics
                % updated to be the same as ASD and ZSD; ZoD offset = 0
                zero_ZOD_offset = true;
            elseif (cs=="InH" || startsWith(cs,"InF"))
                % TRP-to-TRP: InH-Office ... ASA and ZSA statistics updated
                % to be the same as ASD and ZSD
                % Indoor TRP to Indoor TRP: For Indoor factory layer: ...
                % ASA and ZSA statistics updated to be the same as ASD and
                % ZSD
                zero_ZOD_offset = false;
            end
            chcfg.ReferenceTR.AngleSpread = @(ch,isBackground)matchXSDtoXSA(obj,ch,zero_ZOD_offset,isBackground);

            % TR 38.901 Table 7.9.3-1 Case 1
            % "For InF, h_UE is changed to the same height as the BS"
            if (startsWith(cs,"InF"))
                chcfg.ReferenceTR.NodeHeight = @match_h_UE_to_h_BS;
            end

        case 5

            % UE-UE link
            % Table A.3-3: UE-UE channel model

            % Large-scale channel parameters
            if (any(cs==["UMa" "UMi"]))
                % UE-to-UE: UMi-Street canyon in TR 38.901
                % (h_BS=1.5m~22.5m)
                chcfg.Scenario = "UMi";
                % "NOTE 7: For UE-UE path loss computation based on TR
                % 38.901 (Option 2), extend the applicability range of the
                % equations down to 1m (minimum distance between UEs)"
                % no update required, nrPathLoss already supports this
            elseif (cs=="InH" || startsWith(cs,"InF"))
                % UE-to-UE: InH-Office in TR 38.901 (h_BS=1.5m)
                % Indoor UE to Indoor UE: For Indoor factory layer: InF in
                % TR 38.901 (h_BS=1.5m)
                chcfg.Scenario = cs;
                chcfg.ReferenceTR.NodeHeight = @(chcfg)set_h_BS(chcfg,1.5);
            end
            % NOTE 2, NOTE 3, NOTE 4, NOTE 5
            % It is assumed here that all UEs are outdoor

            % Fast fading parameters UE-to-UE: UMi-Street canyon ... ASD
            % and ZSD statistics updated to be the same as ASA and ZSA
            % UE-to-UE: InH-Office ... ASD and ZSD statistics updated to be
            % the same as ASA and ZSA
            % Indoor UE to Indoor UE: For Indoor factory layer: ... ASD
            % and ZSD statistics updated to be the same as ASA and ZSA
            zero_ZOD_offset = false;
            chcfg.ReferenceTR.AngleSpread = @(ch,isBackground)matchXSDtoXSA(obj,ch,zero_ZOD_offset,isBackground);

    end

end

function chcfg = setupTR36777(obj,chcfg)

    % TR 36.777 Table B-1 "LOS probability" plus rules in TR 38.901 below
    % Table 7.9.3-3
    if (isempty(chcfg.LOSProbability))
        combinationCase = chcfg.Case;
        switch (combinationCase)
            case 4
                chcfg.ReferenceTR.LOSProbability = @(chcfg)losProbabilityTR36777_B1(obj,chcfg);
            case 7
                % Table 7.9.3-4
                chcfg.ReferenceTR.LOSProbability = @(chcfg)losProbabilityCase7(obj,chcfg);
            case 9
                % Table 7.9.3-5
                chcfg.ReferenceTR.LOSProbability = @(chcfg)losProbabilityCase9(obj,chcfg);
        end
    end

    % TR 36.777 Table B-2 "Pathloss models"
    chcfg.ReferenceTR.PathLoss = makeCustomPathLossFn(@pathLossTR36777_B2);

    % TR 36.777 Table B-3: "Shadow fading standard deviation"
    chcfg.ReferenceTR.SF = @SF_TR36777_B3;

    % Table B-4: Fast fading model
    chcfg.ReferenceTR.K = @K_TR36777_B4;

end

function chcfg = setupRMa_TRP_UE(obj,chcfg)

    combinationCase = chcfg.Case;

    switch (combinationCase)

        case 1

            % "TRP-UE link of scenario RMa defined in Clause 7 of TR 38.901
            % by setting h_UE=35m (see note 1)". "NOTE 1: ASA and ZSA
            % statistics updated to be the same as ASD and ZSD; ZoD offset
            % = 0"
            chcfg.ReferenceTR.NodeHeight = @(chcfg)set_h_UE(chcfg,35);
            zero_ZOD_offset = true;
            chcfg.ReferenceTR.AngleSpread = @(ch,isBackground)matchXSDtoXSA(obj,ch,zero_ZOD_offset,isBackground);

        case 5

            % "TRP-UE link of scenario RMa defined in Clause 7 of TR 38.901
            % by setting h_BS = 1.5m (see note 2)". "NOTE 2: ASD and ZSD
            % statistics updated to be the same as ASA and ZSA"
            chcfg.ReferenceTR.NodeHeight = @(chcfg)set_h_BS(chcfg,1.5);
            zero_ZOD_offset = false;
            chcfg.ReferenceTR.AngleSpread = @(ch,isBackground)matchXSDtoXSA(obj,ch,zero_ZOD_offset,isBackground);

    end

end

function chcfg = match_h_UE_to_h_BS(chcfg)
    chcfg.UEPosition(3) = chcfg.BSPosition(3);
end

function chcfg = set_h_UE(chcfg,h)
    chcfg.UEPosition(3) = h;
end

function chcfg = set_h_BS(chcfg,h)
    chcfg.BSPosition(3) = h;
end

function ch = matchXSDtoXSA(obj,ch,zero_ZOD_offset,isBackground)

    chcfg = ch.ChannelConfiguration;

    if (~chcfg.HasSmallScale)
        return;
    end

    fastFading = chcfg.FastFading;

    if (fastFading)
        AS = ch.SmallScale.AngleSpreads;
    else
        if (~isBackground)
            AS = ch.angleSpreads;
        end
    end

    if (fastFading || ~isBackground)
        if (chcfg.swapTransmitAndReceive)
            % AS = [C_ASA C_ASD C_ZSA C_ZSD];
            AS(2) = AS(1);
            AS(4) = AS(3);
        else
            % AS = [C_ASD C_ASA C_ZSD C_ZSA];
            AS(1) = AS(2);
            AS(3) = AS(4);
        end
    end

    if (fastFading)
        ch.SmallScale.AngleSpreads = AS;
    end
    if (zero_ZOD_offset)
        ch = zeroZODOffset(obj,ch);        
    end

    if (~isBackground)
        % For target channel, get updated angle spreads and updated ZoD
        % angles for use in steps9to15()
        ch.angleSpreads = AS;
        ch.anglesZoD = ch.SmallScale.AnglesZoD;
    end

end

function ch = zeroZODOffset(obj,ch)

    % NOTE: mu_offsetZOD is zero for LOS case
    chcfg = ch.ChannelConfiguration;
    if (chcfg.HasSmallScale)
        [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(chcfg,obj.SCRVs);
        ch.SmallScale.AnglesZoD = ch.SmallScale.AnglesZoD - data.params.mu_offsetZOD;
    end

end

% Tables 7.9.3-4
function pLOS = losProbabilityCase7(obj,chcfg)

    h_UT = chcfg.UEPosition(3);
    inrange = @(b,v)(b(1)<v & v<=b(2));
    csAV = chcfg.Scenario + "-AV";
    b = getHeightBreakpointsAV(csAV);

    if (h_UT <= b(1))
        % UMi in Table 7.4.2-1 in TR 38.901
        [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(setfield(chcfg,Scenario="UMi"),obj.SCRVs);
        pLOS = data.pLOS;
    elseif (inrange(b([1 3]),h_UT))
        % Table B-1 in TR 36.777
        s = scenarioTR36777_B1(csAV,"UMi-AV");
        pLOS = losProbabilityTR36777_B1(obj,setfield(chcfg,Scenario=s));
    end

end

% Table 7.9.3-5
function pLOS = losProbabilityCase9(obj,chcfg)

    % Table 7.9.3-1 Case 9: "... Annex ... B of TR 36.777 by setting height
    % of TRP equal to the height of the first aerial UE for FR1". "NOTE 4:
    % "First aerial UE height is h_UT1, second aerial UE height is h_UT2,
    % where abs(h_UT1-h_BS) <= abs(h_UT2-h_BS)". Therefore if the first
    % aerial UE is being used as the TRP, use the second aerial UE's height
    % as h_UT in TR 36.777 Table B-1

    % TR 36.777 Table A.1-1
    csAV = chcfg.Scenario + "-AV";
    switch (csAV)
        case "UMi-AV"
            h_BS = 10;
        case "UMa-AV"
            h_BS = 25;
        case "RMa-AV"
            h_BS = 35;
    end

    h_UTa = chcfg.UEPosition(3);
    h_UTb = chcfg.BSPosition(3);

    if (abs(h_UTa-h_BS) < abs(h_UTb-h_BS))
        h_UT1 = h_UTa;
        h_UT2 = h_UTb;
    else
        h_UT1 = h_UTb;
        h_UT2 = h_UTa;
    end

    inrange = @(b,v)(b(1)<v & v<=b(2));    
    b = getHeightBreakpointsAV(csAV);

    mx = max(h_UT1,h_UT2);
    mi = min(h_UT1,h_UT2);

    if ((h_UT1 <= b(1)) && (h_UT2 <= b(1)))
        % UMi in Table 7.4.2-1 in TR 38.901
        [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(setfield(chcfg,Scenario="UMi"),obj.SCRVs);
        pLOS = data.pLOS;
    elseif (inrange(b([1 3]),mx) && (mi <= b(1)))
        % Table B-1 in TR 36.777
        s = scenarioTR36777_B1(csAV,"UMi-AV");
        pLOS = losProbabilityTR36777_B1(obj,updateConfig(chcfg,s,h_UT2));
    elseif (inrange(b([1 2]),h_UT1) && inrange(b([1 2]),h_UT2))
        % Table B-1 in TR 36.777 for aerial UE height in range
        % (b(1),b(2)]
        s = scenarioTR36777_B1(csAV,"UMa-AV");
        pLOS = losProbabilityTR36777_B1(obj,updateConfig(chcfg,s,h_UT2));
    elseif (inrange(b([2 3]),mx) && inrange(b([1 2]),mi))
        % LOS probability is 100%
        pLOS = 1;
    end

end

function chcfg = updateConfig(chcfg,s,h_UT2)

    chcfg.Scenario = s;
    chcfg.UEPosition(3) = h_UT2;

end

function s = scenarioTR36777_B1(csAV,s0)

    if (any(strcmpi(csAV,["UMi-AV" "UMa-AV"])))
        s = s0;
    else % RMa-AV
        s = "RMa-AV";
    end

    % Reconfigure back to non-AV scenario because losProbabilityTR36777_B1
    % will introduce the -AV suffix
    s = strrep(s,"-AV","");

end

function b = getHeightBreakpointsAV(csAV)

    if (any(strcmpi(csAV,["UMi-AV" "UMa-AV"])))
        b = [22.5 100 300];
    else % RMa-AV
        b = [10 40 300];
    end

end

% TR 36.777 Table B.1
function pLOS = losProbabilityTR36777_B1(obj,chcfg)

    d_2D = vecnorm(chcfg.UEPosition(1:2) - chcfg.BSPosition(1:2));
    csAV = chcfg.Scenario + "-AV";
    h_UT = chcfg.UEPosition(3);

    inrange = @(b,v)(b(1)<v & v<=b(2));
    b = getHeightBreakpointsAV(csAV);

    if (h_UT <= b(1))
        % Table 7.4.2-1 of TR 38.901
        [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(chcfg,obj.SCRVs);
        pLOS = data.pLOS;
    elseif (inrange(b([1 2]),h_UT))
        switch (csAV)
            case "RMa-AV"
                p_1 = max(15021*log10(h_UT) - 16053,1000);
                d_1 = max(1350.8*log10(h_UT) - 1602,18);
            case "UMa-AV"
                p_1 = 4300*log10(h_UT) - 3800;
                d_1 = max(460*log10(h_UT) - 700,18);
            case "UMi-AV"
                p_1 = 233.98*log10(h_UT) - 0.95;
                d_1 = max(294.05*log10(h_UT) - 432.94,18);
        end
        if (d_2D <= d_1)
            pLOS = 1;
        else % d_2D > d_1
            pLOS = (d_1/d_2D) + exp(-d_2D/p_1)*(1-(d_1/d_2D));
        end
    elseif (inrange(b([2 3]),h_UT))
        % 100%
        pLOS = 1;
    end

end

% TR 38.858 Table A.3-2 NOTE 2
function pLOS = losProbabilityTR38858_gNB_gNB(obj,chcfg)

    if (chcfg.Scenario=="UMa")
        % For Macro-to-Macro, if the 2D distance between two Macro gNBs are
        % less than or equal to the ISD
        d_2D = vecnorm(chcfg.UEPosition(1:2) - chcfg.BSPosition(1:2));
        ISD = chcfg.InterSiteDistance;
        if (d_2D < ISD)
            % set the LOS probability to 75%
            pLOS = 0.75;
        else
            % Otherwise, reuse gNB-to-UE LOS probability equation in TR
            % 38.901
            [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(chcfg,obj.SCRVs);
            pLOS = data.pLOS;
        end
    else
        % For other cases, reuse gNB-to-UE LOS probability equation in TR
        % 38.901
        [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(chcfg,obj.SCRVs);
        pLOS = data.pLOS;
    end

end

% TR 36.777 Table B.2
function PL = pathLossTR36777_B2(pathLossConfig,freq,LOS,posBS,posUE)

    persistent c0;
    if isempty(c0)
        c0 = physconst('lightspeed');
    end

    inrange = @(b,v)(b(1)<v & v<=b(2));
    csAV = pathLossConfig.Scenario + "-AV";
    b = getHeightBreakpointsAV(csAV);

    h_UT = posUE(3);
    d2D = norm(posUE(1:2)-posBS(1:2));
    if (any(strcmpi(csAV,["UMi-AV" "UMa-AV"])))
        d2D_max = 4000;
    else
        d2D_max = 10000;
    end

    if (h_UT <= b(1))

        PL = nrPathLoss(pathLossConfig,freq,LOS,posBS,posUE);

    elseif (inrange(b([1 3]),h_UT) && d2D < d2D_max)

        d3D = norm(posUE-posBS);
        fc = freq/1e9;
        lg_h_UT = log10(h_UT);
        lg_d3D = log10(d3D);
        switch (csAV)
            case "RMa-AV"
                PL_LOS = max(23.9 - 1.8*lg_h_UT,20)*lg_d3D + ...
                    20*log10(40*pi*fc/3);
                if (LOS)
                    PL = PL_LOS;
                else
                    PL = max(PL_LOS, ...
                        -12 + (35-5.3*lg_h_UT))*lg_d3D + ...
                        20*log10(40*pi*fc/3);
                end
            case "UMa-AV"
                if (LOS)
                    PL = 28.0 + 22*lg_d3D + 20*log10(fc);
                else
                    PL = -17.5 + (46-7*lg_h_UT)*lg_d3D + ...
                        20*log10(40*pi*fc/3);
                end
            case "UMi-AV"
                lambda = c0 / freq;
                PLp = fspl(d3D,lambda);
                PL_LOS = max(PLp, ...
                    30.9 + (22.25-0.5*lg_h_UT)*lg_d3D + 20*log10(fc));
                if (LOS)
                    PL = PL_LOS;
                else
                    PL = max(PL_LOS, ...
                        32.4 + (43.2-7.6*lg_h_UT)*lg_d3D + 20*log10(fc));
                end
        end

    end

end

function PL = pathLossST(pathLossConfig,freq,LOS,posBS,posUE)

    persistent c0;
    if isempty(c0)
        c0 = physconst('lightspeed');
    end

    scenario = pathLossConfig.Scenario;
    hE = pathLossConfig.EnvironmentHeight;
    fc = freq/1e9;
    hBS = posBS(3);
    hUT = posUE(3);
    d3D  = norm(posUE-posBS);

    hBSp = hBS - hE;

    % h_UT = 1.5 m is assumed for breakpoint distance calculation
    hUTp = 1.5 - hE;

    dBP = 4*hBSp.*hUTp*freq/c0;
    d2D = sqrt(d3D.^2-(hBS-hUT).^2);

    switch scenario

        case 'UMa'

            if (d2D <= dBP)
                PL = 28.0 + 22*log10(d3D) + 20*log10(fc);
            else
                PL = 28.0 + 40*log10(d3D) + 20*log10(fc) ...
                    - 9*log10(dBP.^2 + (hBS-hUT).^2);
            end

            if (~LOS)
                PLp = 13.54 + 39.08*log10(d3D) ...
                    + 20*log10(fc) - 0.6*(hUT-1.5);
                PL = max(PL,PLp);
            end

        case 'UMi'

            if (d2D <= dBP)
                PL = 32.4 + 21*log10(d3D) + 20*log10(fc);
            else
                PL = 32.4 + 40*log10(d3D) + 20*log10(fc) ...
                    - 9.5*log10(dBP.^2 + (hBS-hUT).^2);
            end

            if (~LOS)
                PLp = 35.3*log10(d3D) + 22.4 ...
                    + 21.3*log10(fc) - 0.3*(hUT-1.5);
                PL = max(PL,PLp);
            end

    end

end

% TR 36.777 Table B-3
function ch = SF_TR36777_B3(ch)

    chcfg = ch.ChannelConfiguration;
    h_UT = chcfg.UEPosition(3);
    csAV = chcfg.Scenario + "-AV";
    b = getHeightBreakpointsAV(csAV);

    if (h_UT <= b(1))
        % According to Table 7.4.1-1 of TR 38.901 - no update required
    else

        LOS = ch.LOS;
        switch (csAV)
            case "RMa-AV"
                if (LOS)
                    sigma_SF = 4.2*exp(-0.0046*h_UT);
                else
                    sigma_SF = 6;
                end
            case "UMa-AV"
                if (LOS)
                    sigma_SF = 4.64*exp(-0.0066*h_UT);
                else
                    sigma_SF = 6;
                end
            case "UMi-AV"
                if (LOS)
                    sigma_SF = max(5*exp(-0.01*h_UT),2);
                else
                    sigma_SF = 8;
                end
        end

        % Scale current SF value according to the sigma_SF used to generate
        % it, and the desired sigma_SF here
        ch.SF = ch.SF / ch.params.sigma_SF * sigma_SF;

    end

end

% TR 36.777 Table B-4
function ch = K_TR36777_B4(ch)

    chcfg = ch.ChannelConfiguration;
    h_UT = chcfg.UEPosition(3);
    csAV = chcfg.Scenario + "-AV";
    b = getHeightBreakpointsAV(csAV);

    if (h_UT <= b(1))
        % According to Section 7.5 of TR 38.901 - no update required
    else
        % According to Annex B.1
        % This implementation uses B.1.3 "Alternative 3" - "In this
        % alternative ... the fast fading model in Section 7.5 of [TR
        % 38.901] is used with K=15 dB"
        ch.K = 15;
    end

end

% TR 38.858 Table A.3-2: gNB-gNB channel model
% "Penetration loss is not modelled"
function ch = O2I_TR38858_gNB_gNB(ch)

    ch.O2I = 0;

end

function [pathGains,sampleTimes] = backgroundStep11(obj,idx,T)

    ch = obj.channels{idx};
    S = ch.NumTransmitAntennas;
    U = ch.NumReceiveAntennas;

    if (obj.BackgroundChannel)

        if (ch.bcfg.HasSmallScale)

            ss = ch.SmallScale;
    
            if (~isstruct(ss)) % fast fading
            
                ss.NumTimeSamples = T;
                [pathGains,sampleTimes] = ss();
                los = ss.HasLOSCluster;
    
            else % LOS ray only
    
                pathGains = single(obj.nr5g.noFastFadingPathGains(ch));
                ss.TransmitAndReceiveSwapped = ch.LargeScale.TransmitAndReceiveSwapped();
                if (ss.TransmitAndReceiveSwapped)
                    pathGains = permute(pathGains,[1 2 4 3]);
                end
                sampleTimes = obj.theTime;
                los = true;
    
            end
    
            % Apply d_3D-related term of Eq 7.5-29
            pathGains = obj.nr5g.applyPhaseLOS_d_3D(ch,pathGains,los);
    
            % Apply beamforming to the channel output, this allows for
            % TXRU virtualization
            pathGains = obj.nr5g.applyBeamforming(ss,pathGains,ch.TXRUVirtualization);

        else

            % Section 7.9.6.1 "For the purposes of large scale calibration
            % without fast fading modelling"
            outputproto = single(1i);
            [pathGains,sampleTimes] = getPathGainsNoSmallScale(obj,S,U,outputproto);

        end

    else

        if (strcmpi(obj.PathGainSampleRate,'auto'))
            Ncs = 0;
        else
            Ncs = T;
        end
        pathGains = zeros([Ncs 0 S U],"like",single(1i));
        sampleTimes = zeros([Ncs 1]);

    end

end

function [pathGains,sampleTimes] = getPathGainsNoSmallScale(obj,S,U,outputproto)

    pathGains = comm.internal.channel.getPathGainsNoFading(S,U,outputproto);
    pathGains = pathGains / sqrt(U);
    sampleTimes = obj.theTime;

end

function PLdB = backgroundStep12(obj,idx)

    persistent c0;
    if isempty(c0)
        c0 = physconst('lightspeed');
    end

    if (obj.LOSRayOnly)
        d_ray = norm(obj.SRX.Position - obj.STX.Position);
        fc = obj.CenterFrequency;
        lambda = c0 / fc;
        PLdB = fspl(d_ray,lambda);
    else
        lsfn = obj.channels{idx}.LargeScale;

        if contains(obj.SensingMode,"Bistatic")
            % Path loss between STX and SRX
            PLdB = lsfn.execute(obj.STX.Position,obj.SRX.Position,obj.CenterFrequency);
        else 
            % Path loss between STX and monostatic reference point
            if strcmp(obj.SensingMode,"TRP Monostatic")
                referencePointPosition = obj.channels{idx}.bcfg.UEPosition;
            else % UE Monostatic
                referencePointPosition = obj.channels{idx}.bcfg.BSPosition;
            end
            PLdB = lsfn.execute(obj.STX.Position,referencePointPosition,obj.CenterFrequency);
        end

    end

    % Power offset for Section 7.9.5.3 "Power normalization across target
    % channel and background channel"
    PLdB = PLdB - obj.BackgroundPowerOffset;

end

function ch = fastFadingChannelModelISAC(obj,isaccfg,tx2stcfg,st2rxcfg,nodeinfo,S,U)

    % Implement the fast fading model from Section 7.9.4
   
    % ---------------------------------------------------------------------
    % Steps 1-8: Perform existing Section 7.5 Steps 2-8 for both STX-ST and
    % ST-SRX links

    % The outputs of steps 1 to 8 are intended to be used as configuration
    % properties for nrCDLChannel, which implements Section 7.5 Step 11
    % "Generate channel coefficients". The properties of nrCDLChannel are
    % defined in terms of the cluster delays, powers and angles described
    % by Steps 5, 6 and 7. In Step 5, the cluster index 'n' ranges from
    % 1...N, as described below Eq. (7.5-1)

    ch = struct();

    % STX-ST link
    ch.tx2st = steps1to8(obj,isaccfg,tx2stcfg);

    % ST-SRX link
    ch.st2rx = steps1to8(obj,isaccfg,st2rxcfg);

    % ---------------------------------------------------------------------
    % Steps 9-15

    ch = steps9to15(obj,ch,isaccfg,tx2stcfg,st2rxcfg,nodeinfo,S,U);

end

function chdata = steps1to8(obj,isaccfg,cfg)

    % Execute Section 7.5 Steps 1 to 12, which includes setup for
    % spatially-consistent mobility
    cfg = applyConfigReferenceTR(cfg);
    [chdata,~,obj.SCRVs] = obj.nr5g.createChannelLink(cfg,obj.SCRVs);

    % Deal with any adjustments required to the new small-scale channel, or
    % any setup dependent on it
    chdata = respondToSmallScaleTargetUpdate(obj,isaccfg,cfg,chdata);
    chdata = updateChannelReferenceTR(chdata,false);

end

function chdata = respondToSmallScaleTargetUpdate(obj,isaccfg,cfg,chdata)

    % Execute Section 7.5 Steps 1 to 8, to get low-level data fields
    [~,data] = obj.nr5g.fastFadingChannelModelSteps1to8(cfg,obj.SCRVs);    

    % Remove fields produced by createChannelLink but not used later
    chdata = removeUnusedChannelLinkFields(chdata);

    % Adjust small-scale channel properties to match the outputs of Section
    % 7.5 Steps 1 to 8 that are used in steps9to15(), which implements
    % Section 7.9.4 Steps 9 to 15. In some cases these deviate from the
    % outputs of Section 7.5 Steps 1 to 8 that are used in Section 7.5
    % Steps 9 to 12. The properties used in steps9to15() are stored in
    % 'chdata'. This step also takes care of calling
    % swapTransmitAndReceive, so that properties retrieved from
    % chdata.SmallScale have the correct transmit versus receive role. Note
    % that steps9to15() does not use chdata.SmallScale, but updates for
    % spatially-consistent mobility do
    chdata = adjustSmallScale(isaccfg,cfg,chdata,data);

    % Add fields of 'data' required by steps9to15()
    chdata = addDataFields(chdata,data);

end

function chdata = adjustSmallScale(isaccfg,cfg,chdata,data)

    if (cfg.HasSmallScale)

        fastFading = cfg.FastFading;
    
        % Extract small-scale channel
        ss = chdata.SmallScale;
    
        % Section 7.5 Step 5 produces tau^LOS_n, Section 7.9.4 Step 5
        % requires tau_n
        if (fastFading)
            ss.PathDelays = data.pathDelays;
            if (isaccfg.FastFading)
                chdata.pathDelays = data.pathDelays;
            end
        end
    
        % Section 7.5 Step 6 produces P_n as defined in Eq. (7.5-8),
        % Section 7.9.4 Step 6 requires P_n as defined in Eq. (7.5-6)
        if (fastFading)
            ss.AveragePathGains = 10*log10(data.pathPowers);
            chdata.pathPowers = data.pathPowers;
        end
    
        % Switch to a reciprocal channel if configured, this is required
        % for links configured as UE -> TRP rather than TRP -> UE
        if (fastFading && xor(cfg.swapTransmitAndReceive,ss.TransmitAndReceiveSwapped))
            swapTransmitAndReceive(ss);
        end
    
        % Get other small-scale properties required by steps9to15() that
        % might have been updated due to spatially-consistent mobility.
        % Note that when swapTransmitAndReceive=true, some transmitter and
        % receiver related properties will have been flipped inside 'ss'
        chdata.anglesAoA = ss.AnglesAoA;
        chdata.anglesAoD = ss.AnglesAoD;
        chdata.anglesZoA = ss.AnglesZoA;
        chdata.anglesZoD = ss.AnglesZoD;
        chdata.angleSpreads = ss.AngleSpreads;
        chdata.txarray = ss.TransmitAntennaArray;
        chdata.rxarray = ss.ReceiveAntennaArray;
        chdata.txorientation = ss.TransmitArrayOrientation;
        chdata.rxorientation = ss.ReceiveArrayOrientation;
        chdata.rayCoupling = ss.RayCoupling;
        if (cfg.FastFading)
            chdata.maximumDopplerShift = ss.MaximumDopplerShift;
            chdata.maximumScattererSpeed = ss.MaximumScattererSpeed;
            chdata.movingScattererProportion = ss.MovingScattererProportion;
            chdata.utDirectionOfTravel = ss.UTDirectionOfTravel;
        end
    
        % Store update small-scale channel
        chdata.SmallScale = ss;

    end

end

function chdata = removeUnusedChannelLinkFields(chdata)

    toremove = [ ...
        "CenterFrequency" "ChannelFilter" ...
        "ChannelFilterReciprocal" "LargeScale" ...
        "NumReceiveAntennas" "NumTransmitAntennas" ...
        "PathDelays" "PathFilters" ...
        ];

    for f = toremove
        if (isfield(chdata,f))
            chdata = rmfield(chdata,f);
        end
    end

    % Also convert ChannelConfiguration fields from char to string
    chdata = channelConfigurationStrings(chdata);

end

function chdata = channelConfigurationStrings(chdata)

    chcfg = chdata.ChannelConfiguration;
    for f = "Scenario"
        chcfg.(f) = string(chcfg.(f));
    end
    chdata.ChannelConfiguration = chcfg;

end

function chdata = addDataFields(chdata,data)

    chdata.params = data.params;
    chdata.LOS = data.LOS;
    chdata.indoor = data.indoor;
    chdata.K = data.K;
    chdata.d_3D = data.d_3D;
    chdata.siteuers = data.siteuers;
    chdata.uers = data.uers;
    chdata.plfn = data.plfn;
    chdata.SF = data.SF;
    chdata.O2I = data.O2I;
    chdata.h_E = data.h_E;

end

function ch = steps9to15(obj,ch,isaccfg,tx2stcfg,st2rxcfg,nodeinfo,S,U)

    persistent c0;
    if isempty(c0)
        c0 = physconst('LightSpeed');
    end

    % If all inputs are provided, assign the configuration inputs into the 
    % channel structure, to make them part of the channel state
    if (nargin>3)
        ch.isaccfg = isaccfg;
        ch.tx2stcfg = tx2stcfg;
        ch.st2rxcfg = st2rxcfg;
        ch.nodeinfo = nodeinfo;
        ch.S = S;
        ch.U = U;
    end

    hasSmallScale = ch.isaccfg.HasSmallScale;
    fastFading = hasSmallScale && ch.isaccfg.FastFading;

    % Random stream for the sensing target used to generate link ray
    % coupling, 4-D XPRs, initial phases, radar cross section (RCS) and
    % mobile scatterer parameters
    stRS = RandStream('mt19937ar','Seed',ch.isaccfg.Seed);

    % Get LOS angles before clusters are sorted by cluster power (the first
    % cluster will currently be the LOS cluster)
    if (hasSmallScale)
        ch.tx2st = getLOSAngles(ch.tx2st);
        ch.st2rx = getLOSAngles(ch.st2rx);
    end

    if (fastFading)
        % In order to prepare for applying sub-cluster delays in Step 11,
        % the cluster information produced by steps1to8() is sorted in
        % order of descending cluster power
        ch.tx2st = sortByClusterPower(ch.tx2st);
        ch.st2rx = sortByClusterPower(ch.st2rx);
    end

    if (hasSmallScale)
        % As noted above, the properties of nrCDLChannel are defined in
        % terms of clusters. This means that the implementation of Step 7
        % in steps1to8() does not include the application of ray offset
        % angles, so this step is performed here. From this point forward,
        % the arrival angles and departure angles for both azimuth and
        % elevation are defined with separate values for each cluster and
        % ray. In Step 7, the ray number 'm' ranges from 1...M as shown in
        % Table 7.5-3
        ch.tx2st = applyRayOffsetAngles(ch.tx2st);
        ch.st2rx = applyRayOffsetAngles(ch.st2rx);
    end

    if (hasSmallScale)
        % As noted above, the properties of nrCDLChannel are defined in
        % terms of clusters. This means that the implementation of Step 8
        % in steps1to8() does not include the application of the angle ray
        % coupling, so this step is performed here
        ch.tx2st = angleRayCoupling(ch.tx2stcfg,ch.tx2st);
        ch.st2rx = angleRayCoupling(ch.st2rxcfg,ch.st2rx);
    end

    % ---------------------------------------------------------------------
    % Steps 9 to 14

    % Steps 9 to 14 in Section 7.9.4 involve 4 subscripts (n', m', n, m) 
    % with the following definitions:
    %   n': cluster in an SPST-SRX link (n' = 0...N')
    %   m': ray in a cluster in an SPST-SRX link (m' = 0...M')
    %   n: cluster in an STX-SPST link (n = 0...N)
    %   m: ray in a cluster in an STX-SPST link (m = 0...M)
    %
    % Step 9 introduces subscripts n = 0 and m = 0 for the LOS ray of an
    % STX-SPST link and subscripts n' = 0 and m' = 0 for the LOS ray of an
    % SPST-SRX link. Therefore these subscripts have a range one larger
    % than those described by Section 7.5. The output of steps 9 to 13
    % ('R_0', 'pathPowers', 'pathDelays', 'XPRs' and 'initialPhases') are
    % therefore all of size (N'+1)-by-(M'+1)-by-(N+1)-by-(M+1)

    % ---------------------------------------------------------------------
    % Step 9: Coupling of rays for a STX-SPST link and the corresponding
    % SPST-SRX link of the same SPST

    if (hasSmallScale)
        R_0 = linkRayCoupling(ch.isaccfg,ch.tx2st,ch.st2rx,stRS);
        if (ch.isaccfg.LOSRayOnly)
            R_0(:) = false;
            R_0(1,1,1,1) = true;
        end
    end

    % ---------------------------------------------------------------------
    % Step 10: obtain the power for all generated paths

    % Get departure angles from the STX-ST link, get arrival angles from
    % the ST-SRX link, set up LOS ray angles if required, and get the set
    % of target angles used to determine Doppler shift
    if (hasSmallScale)
        [anglesAoA,anglesAoD,anglesZoA,anglesZoD,targetAngles] = prepareAngles(ch.tx2st,ch.st2rx);
    end

    if (hasSmallScale)
        [pathPowers,rcsInfo,R] = obtainPowers(ch.isaccfg,ch.tx2st,ch.st2rx,anglesAoA,anglesAoD,anglesZoA,anglesZoD,stRS,R_0);
    else
        rcsInfo.sigma_M = rcsModelLargeScale(ch.isaccfg);
    end

    % ---------------------------------------------------------------------
    % Step 11: obtain the absolute delay for each path

    if (fastFading)
        [pathDelays,ch.tx2st,ch.st2rx] = obtainDelays(obj,ch.tx2stcfg,ch.st2rxcfg,ch.tx2st,ch.st2rx);
    end

    % ---------------------------------------------------------------------
    % Step 12: generate the cross polarization power ratios

    if (hasSmallScale)
        [kappaTx,kappaRx,kappa] = generateXPRs(ch.isaccfg,ch.tx2st,ch.st2rx,stRS,R);
    end

    % ---------------------------------------------------------------------
    % Step 13: draw initial random phases for paths in set R

    if (hasSmallScale)
        [PhiTx,PhiRx,Phi] = generateInitialPhases(ch.isaccfg,ch.tx2st,ch.st2rx,stRS,R);
    end
    
    % ---------------------------------------------------------------------
    % Prepare for Step 14: Generate channel coefficients 
    % NOTE: Step 14 is not performed here, it is performed when the small
    % scale channel returned by this function is executed in stepImpl()

    % Create small-scale structure with the information obtained from Steps
    % 9 to 13
    
    if (hasSmallScale)
    
        ss = struct();
        ss.pathPowers = pathPowers;
        if (fastFading)
            ss.pathDelays = pathDelays;
        end
        ss.anglesAoA = anglesAoA;
        ss.anglesAoD = anglesAoD;
        ss.anglesZoA = anglesZoA;
        ss.anglesZoD = anglesZoD;
        ss.R_0 = R_0;
        ss.RCSInfo = rcsInfo;
        ss.R = R;
        ss.kappaTx = kappaTx;
        ss.kappaRx = kappaRx;
        ss.kappa = kappa;
        ss.PhiTx = PhiTx;
        ss.PhiRx = PhiRx;
        ss.Phi = Phi;
        ss.targetAngles = targetAngles;
    
        % Add fields from Step 1 required for the static (i.e. non
        % time-varying) terms of Step 14, and construct the static terms
        ss.txarray = ch.tx2st.txarray;
        ss.txorientation = ch.tx2st.txorientation;
        ss.rxarray = ch.st2rx.rxarray;
        ss.rxorientation = ch.st2rx.rxorientation;
        ss.CarrierFrequency = obj.CenterFrequency;
        ss.FastFading = ch.isaccfg.FastFading;
        ss = staticCDLChannelISAC(ss,R,ch.S,ch.U);
    
        if (fastFading)
            % Add fields for target mobility. For v_bar of the target,
            % derive the maximum doppler shift inputs to getDopplerTerm
            % (n.b. two identical inputs used since the same velocity
            % applies to both the ST to SRX and ST to STX components).
            % Similarly defined utDirectionOfTravelST using the same target
            % velocity
            lambda = c0 / ss.CarrierFrequency;
            vST = ch.isaccfg.TargetVelocity;
            vSTnorm = norm(vST);
            ss.maximumDopplerShiftST = [vSTnorm vSTnorm] / lambda;
            ss.utDirectionOfTravelST = [azimuthElevation(vST) azimuthElevation(vST)];

            % FIX (target Doppler): keep the target velocity vector itself
            % for the explicit Eq. (7.9.5-14) Doppler computation in
            % timeVaryingCDLChannelISAC (see the detailed note there).
            % This field is refreshed by the same spatially-consistent
            % mobility updates that refresh maximumDopplerShiftST /
            % utDirectionOfTravelST (setupPerST runs before steps9to15 in
            % spatiallyConsistentMobilityISAC), so all three stay mutually
            % consistent.
            ss.vST = vST;

            ss.MaximumScattererSpeed = ...
                ch.tx2st.maximumScattererSpeed + ch.st2rx.maximumScattererSpeed;
       
            % Add fields from Step 1 (potentially updated by
            % spatially-consistent mobility procedures) required for the
            % Doppler frequency component f_D defined in Eq. (7.9.5-14),
            % and create the alpha and D terms for scatterer mobility
            tx2st_swap = ch.tx2stcfg.swapTransmitAndReceive;
            ss.maximumDopplerShiftTx = ch.tx2st.maximumDopplerShift(2-tx2st_swap);
            ss.maximumScattererSpeedTx = ch.tx2st.maximumScattererSpeed;
            ss.movingScattererProportionTx = ch.tx2st.movingScattererProportion;
            st2rx_swap = ch.st2rxcfg.swapTransmitAndReceive;
            ss.maximumDopplerShiftRx = ch.st2rx.maximumDopplerShift(1+st2rx_swap);
            ss.maximumScattererSpeedRx = ch.st2rx.maximumScattererSpeed;
            ss.movingScattererProportionRx = ch.st2rx.movingScattererProportion;
            ss.UTDirectionOfTravel = [ch.st2rx.utDirectionOfTravel(:,1+st2rx_swap) ch.tx2st.utDirectionOfTravel(:,2-tx2st_swap)];
            ss = setupMobileScatterers(ss,stRS);

        end

        % Prepare small-scale channel output
        if (fastFading)
            [ch.PathDelays,ss.pathDelayMapping] = makeUniquePathDelays(obj,pathDelays(R(:)).'); % row vector
            ss.SampleRate = obj.SampleRate;
            ss.SampleDensity = getSampleDensity(obj);
        else
            ch.PathDelays = 0;
        end
        ch.TXRUVirtualization = ch.tx2st.TXRUVirtualization;

    else

        ss = [];
        ch.PathDelays = 0;

    end

    ch.SmallScale = ss;
    ch.SmallScaleStep = @(idx,T)targetStep14(obj,idx,T);    

    % ---------------------------------------------------------------------
    % Prepare for Step 15: Apply pathloss and shadowing
    % NOTE: Step 15 is not performed here, it is performed when the large
    % scale channel returned by this function is executed in stepImpl()

    % Create large-scale structure with required fields for the execution
    % of step 15, using information from Steps 1 to 4
    tx2st_lsfn = largeScale(obj,ch.nodeinfo.STXtoSTs,ch.tx2stcfg,ch.tx2st);
    st2rx_lsfn = largeScale(obj,ch.nodeinfo.STstoSRX,ch.st2rxcfg,ch.st2rx);
    ls = struct();
    ls.tx2st = tx2st_lsfn;
    ls.st2rx = st2rx_lsfn;
    ls.sigma_M = rcsInfo.sigma_M;

    % Prepare large-scale channel aspects of the output
    ch.LargeScale = ls;
    ch.LargeScaleStep = @(idx)targetStep15(obj,idx);

end

function ss = setupMobileScatterers(ss,stRS)

    [ss.alphTx,ss.DTx] = getDualMobilityScattererVariablesISAC(ss.maximumScattererSpeedRx,ss.movingScattererProportionRx,stRS,size(ss.R,[3 4]));
    [ss.alphRx,ss.DRx] = getDualMobilityScattererVariablesISAC(ss.maximumScattererSpeedTx,ss.movingScattererProportionTx,stRS,size(ss.R,[1 2]));

end

function [alph,D] = getDualMobilityScattererVariablesISAC(v_scatt,p,rs,siz)
   
    randAlph = rs.rand(siz);
    randD = rs.rand(siz);

    % Bernoulli distribution of probability p. This is a matrix that
    % specifies whether the scatters are moving (true) or not (false), 
    % for each ray in each cluster. For all n = 0, Eq. (7.9.5-14) treats
    % alph as 0. 
    alph = double(randAlph <= p);
    alph(1,:) = 0; 
    
    % Random speed from -v_scatt to v_scatt for each ray in each cluster
    D = -v_scatt + (2*v_scatt)*randD;
    
end

function chdata = getLOSAngles(chdata)

    chdata.phiLOS_AoA = chdata.anglesAoA(1);
    chdata.phiLOS_AoD = chdata.anglesAoD(1);
    chdata.thetaLOS_ZoA = chdata.anglesZoA(1);
    chdata.thetaLOS_ZoD = chdata.anglesZoD(1);

end

function chdata = sortByClusterPower(chdata)

    [~,idx]= sort(chdata.pathPowers,'descend');
    chdata.pathPowers = chdata.pathPowers(idx);
    chdata.pathDelays = chdata.pathDelays(idx);
    chdata.anglesAoA = chdata.anglesAoA(idx);
    chdata.anglesAoD = chdata.anglesAoD(idx);
    chdata.anglesZoA = chdata.anglesZoA(idx);
    chdata.anglesZoD = chdata.anglesZoD(idx);

end

function [pathGains,sampleTimes] = targetStep14(obj,idx,T)

    ch = obj.channels{idx};

    outputproto = single(1i);

    if (ch.isaccfg.HasSmallScale)

        ss = ch.SmallScale;
        fastFading = ch.isaccfg.FastFading;
    
        if (fastFading)
    
            % Calculate the time-varying aspect and combine it with the
            % static path gains
            S = size(ss.staticPathGains,3);
            insize = [T S];
            U = obj.theInfo.NumOutputSignals;
            [pathGains,sampleTimes,obj.theDopplerStruct{idx}] = timeVaryingCDLChannelISAC(ss,obj.theTime,insize,outputproto,obj.theDopplerStruct{idx},U);
    
        else % coupling loss
    
            pathGains = noFastFadingPathGainsISAC(ch,outputproto);
            % Reciprocal link operation is not supported for the target
            % channel
            ss.TransmitAndReceiveSwapped = false;
            sampleTimes = 0;
    
        end

        % Apply d_3D-related term of Eq 7.5-29
        pathGains = applyPhaseLOS_d_3D(obj,ch,pathGains);
    
        % Apply beamforming to the channel output, this allows for TXRU
        % virtualization
        pathGains = obj.nr5g.applyBeamforming(ss,pathGains,ch.TXRUVirtualization);
    
        % Combine path gains which have equal path delays
        if (fastFading)
            pathGains = combineSameDelayPathGains(ss.pathDelayMapping,pathGains);
        else
            pathGains = sum(pathGains,2);
        end

    else

        % Section 7.9.6.1 "For the purposes of large scale calibration
        % without fast fading modelling"
        [pathGains,sampleTimes] = getPathGainsNoSmallScale(obj,ch.S,ch.U,outputproto);

    end

end

function PLdB = targetStep15(obj,idx)

    persistent c0;
    if isempty(c0)
        c0 = physconst('lightspeed');
    end

    posSPST = updateSPSTPosition(obj,idx);

    if (obj.LOSRayOnly)
        d_ray = norm(posSPST - obj.STX.Position) + norm(obj.SRX.Position - posSPST);
        fc = obj.CenterFrequency;
        lambda = c0 / fc;
        PLdB = fspl(d_ray,lambda);
    else
        ls = obj.channels{idx}.LargeScale;
        PLdB = [
            ls.tx2st.execute(obj.STX.Position,posSPST,obj.CenterFrequency)
            ls.st2rx.execute(posSPST,obj.SRX.Position,obj.CenterFrequency)
            rcsPathLoss_dB(ls.sigma_M,obj.CenterFrequency)];
        PLdB = sum(PLdB);
    end

    % Power offset for Section 7.9.5.3 "Power normalization across target
    % channel and background channel"
    PLdB = PLdB - obj.TargetPowerOffset;

end

function pos = updateSPSTPosition(obj,idx)

    ST = obj.STs(getSTIndex(obj,idx));
    ch = obj.channels{idx};
    f = getSPSTPositionField(ch.tx2stcfg,"tx2st");
    chcfg = setfield(ch.tx2stcfg,f,ST.Position);
    chcfg = getSPSTPosition(ch.isaccfg,chcfg,"tx2st");
    pos = chcfg.(f);

end

function k = getSTIndex(obj,idx)

    Nbc = getNumBackgroundChannels(obj.SensingMode);
    Nc = numel(obj.channels);
    KP = Nc - Nbc;
    K = numel(obj.STs);
    P = KP / K;

    tidx = idx - Nbc; % target channel index, skip background channel(s)
    [k,~] = ind2sub([K P],tidx);

end

function pl = rcsPathLoss_dB(sigma_M,fc)

    persistent c; 
    if (isempty(c))
        c = physconst('LightSpeed');
    end

    lambda_0 = c / fc;
    pl = -20*log10(sqrt((4*pi*sigma_M) / lambda_0^2));

end

function lsfn = largeScale(obj,linkinfo,cfg,chdata)

    if (~isempty(cfg.ReferenceTR.PathLoss))
        plfn = cfg.ReferenceTR.PathLoss(chdata);
    else
        plfn = chdata.plfn(chdata.SF);
    end
    plfn = plfn(nrPathLossConfig(Scenario=cfg.Scenario));

    wrapping = obj.Wrapping;
    ISD = obj.InterSiteDistance;
    numCellSites = linkinfo.NodeSiz(1);
    numSectors = linkinfo.NodeSiz(2);
    lsfn = obj.nr5g.largeScaleWrapper(wrapping,ISD,numCellSites,numSectors,plfn);

    if (cfg.swapTransmitAndReceive)
        lsfn.swapTransmitAndReceive();
    end

end

function chdata = applyRayOffsetAngles(chdata)

    ray_offset_alpha = kron([0.0447 0.1413 0.2492 0.3715 0.5129 0.6797 0.8844 1.1481 1.5195 2.1551],[1 -1]); % size 1-by-M
    N = numel(chdata.anglesAoA);
    ray_offset_alpha = repmat(ray_offset_alpha,N,1); % size N-by-M
    C = num2cell(chdata.angleSpreads);
    [C_ASD,C_ASA,C_ZSD,C_ZSA] = deal(C{:});

    % apply ray offset angles to AOA and AOD angles according to Section
    % 7.5 Equation 7.5-13
    chdata.anglesAoA = chdata.anglesAoA.' + C_ASA * ray_offset_alpha; % size N-by-M
    chdata.anglesAoD = chdata.anglesAoD.' + C_ASD * ray_offset_alpha; % size N-by-M

    % apply ray offset angles to ZOA and ZOD angles according to Section
    % 7.5 Equation 7.5-18
    chdata.anglesZoA = chdata.anglesZoA.' + C_ZSA * ray_offset_alpha; % size N-by-M
    chdata.anglesZoD = chdata.anglesZoD.' + C_ZSD * ray_offset_alpha; % size N-by-M

    % wrap azimuth angles to [-180,180]
    chdata.anglesAoA = wrapAzimuthAngles(chdata.anglesAoA);
    chdata.anglesAoD = wrapAzimuthAngles(chdata.anglesAoD);
    
    % wrap zenith angles to [0,360] and map [180,360] to [180,0]
    chdata.anglesZoA = wrapZenithAngles(chdata.anglesZoA);
    chdata.anglesZoD = wrapZenithAngles(chdata.anglesZoD);

end

function theta = wrapZenithAngles(theta)

    theta = mod(theta,360);
    theta = wrap(theta); 
    
    function theta = wrap(theta)
        theta(theta>180) = 360 - theta(theta>180);
    end

end

function phi = wrapAzimuthAngles(phi)
    phi =  (mod(phi + 180,360) - 180);
end

function [sigma_M,sigma_D,sigma_S,mu_S_dB,std_S_dB] = rcsModel(isaccfg,anglesAoA,anglesAoD,anglesZoA,anglesZoD,rs,R_0)
% Section 7.9.2.1: Calculate the radar cross section (RCS) of a sensing target

% This function calculates the 3 RCS related coefficient components (M, D,
% and S) of the RCS of a SPST, where sigma_RCS = sigma_M*sigma_D*sigma_S,
% along with the mean and standard deviation of the S component

% There are two RCS model options. Model 1 characterizes the ST as 1 SPST
% and locks sigma_D equal to 1, removing the angular dependence. Model 2
% permits more than one SPST depending on target type and determines
% sigma_D from incident/scattered angles. 

% N.B. sigma_M is constant for all paths and is returned as a scalar (see
% 7.9.4 Step 15). The other coefficients are path-wise (see 7.9.4 Step 10).

    [sigma_M,sigma_M_dB] = rcsModelLargeScale(isaccfg);    

    % the effect of forward scattering
    sigma_FS = -Inf;

    % define incident/scattered angles in local coordinate system (LCS)
    [thetaI,phiI,thetaS,phiS] = getLocalAngles(isaccfg,anglesAoA,anglesAoD,anglesZoA,anglesZoD);

    % bistatic angle within plane incident/scattered zenith & azimuth
    beta = getBistaticAngle(thetaI,phiI,thetaS,phiS); 
    
    switch isaccfg.RCSModel 

        case "Model 1" 

            % Table 7.9.2.1-1
            std_S_dB = isaccfg.RCSParameters(2);

            % Eq. (7.9.2-2)
            sigma_MD_dB = max(sigma_M_dB - 3*sin(beta/2),sigma_FS);

        case "Model 2"

            % Eq. (7.9.2-3)
            [thetaB,phiB] = getBisectorAngles(thetaI,thetaS,phiI,phiS); % midway angles between incident/scattered zenith & azimuth

            % Tables 7.9.2.1-(2-7)
            [std_S_dB,phiC,phi3dB,thetaC,theta3dB,G_max,sigma_max] = configureRCSParametersForModel2(isaccfg.SensingTarget,isaccfg.MultipleSPSTs,isaccfg.RCSParameters,thetaB,phiB);

            [k1,k2] = getkValues(isaccfg.SensingTarget);
            sigma_V_dB = -min( 12.*((thetaB-thetaC)./theta3dB).^2 , sigma_max);
            sigma_H_dB = -min( 12.*((phiB-phiC)./phi3dB).^2 , sigma_max);
    
            A = G_max - min(-(sigma_V_dB + sigma_H_dB),sigma_max) - k1*sind(k2*beta/2) + 5*log10(cosd(beta/2));
            B = G_max - sigma_max;
            C = sigma_FS;
    
            sigma_MD_dB = max(A,max(B,C));

    end

    % Eq. (7.9.2-1)
    mu_S_dB = (-log(10)/20).*(std_S_dB.^2);

    sigma_MD = 10.^(sigma_MD_dB/10);

    % sigma_D is a set of size(R_0) linear coefficients for Step 10. Can be
    % "fixed to 1 or can be angular dependent". Derive angular dependent
    % value or set as user-chosen value if supplied.
    if ~isempty(isaccfg.SigmaD)
        sigma_D = isaccfg.SigmaD * ones(size(R_0));
    else
        sigma_D = sigma_MD/sigma_M;
    end

    % sigma_S is a set of size(R_0) log-normal variates for Step 10 
    rv = rs.randn(size(R_0)); % random values 
    X = mu_S_dB + std_S_dB*rv;
    if (isaccfg.LOSRayOnly)
        X(1,1) = 0;
    end
    sigma_S = 10.^(X/10);

end

function [sigma_M,sigma_M_dB] = rcsModelLargeScale(isaccfg)

    switch isaccfg.RCSModel

        case "Model 1"

            % Table 7.9.2.1-1
            sigma_M_dB = isaccfg.RCSParameters(1);

        case "Model 2"

            % Tables 7.9.2.1-(2-7)
            sigma_M_dB = isaccfg.RCSParameters(1,7);

    end

    sigma_M = 10^(sigma_M_dB/10); % scalar linear coefficient for Step 15

end

function [std_S_dB,phiC,phi3dB,thetaC,theta3dB,G_max,sigma_max] = configureRCSParametersForModel2(sensingTarget,multipleSPSTs,rcsParams,theta,phi)

% Define the applicable RCS parameters to be used for this scattering point
% for RCS Model 2 according to both the target type and either SPST number
% or angular dependence

% "theta and phi are the zenith angle and azimuth angle of the bisector the
% incidence and scattered rays". It is the bisector angles that are applied
% to these tables.

    switch sensingTarget

        % there are several conditions across Tables 7.9.2.1-(2-7) that
        % require setting sigma_H to 0. To ensure that sigma_H in Eq.
        % (7.9.2-3) evaluates to 0, where the phiC and phi3dB parameters
        % are undefined, phiC is set equal to phi and phi3dB is set equal
        % to 1

        case "UAV"

            % Table 7.9.2.1-2
            phiC = getRCSParameterForUAV(rcsParams(:,1),phi,theta);   
            phi3dB = getRCSParameterForUAV(rcsParams(:,2),phi,theta);
            thetaC = getRCSParameterForUAV(rcsParams(:,3),phi,theta);
            theta3dB = getRCSParameterForUAV(rcsParams(:,4),phi,theta);
            G_max = getRCSParameterForUAV(rcsParams(:,5),phi,theta);
            sigma_max = getRCSParameterForUAV(rcsParams(:,6),phi,theta);

            % When theta is in the range [0,45] or [135,180], sigma_H is 0
            phiC(theta >= 135 & theta < 180) = phi(theta >= 135 & theta < 180);
            phiC(theta >=   0 & theta <  45) = phi(theta >=   0 & theta <  45);
            phi3dB(theta >= 135 & theta < 180) = 1;
            phi3dB(theta >=   0 & theta <  45) = 1;            

        case "human"

            % Table 7.9.2.1-3: human parameters are only angular dependent
            % upon the azimuth
            phiC = getRCSParameterForHuman(rcsParams(:,1),phi);
            phi3dB = getRCSParameterForHuman(rcsParams(:,2),phi);
            thetaC = getRCSParameterForHuman(rcsParams(:,3),phi);
            theta3dB = getRCSParameterForHuman(rcsParams(:,4),phi);
            G_max = getRCSParameterForHuman(rcsParams(:,5),phi);
            sigma_max = getRCSParameterForHuman(rcsParams(:,6),phi);

        case "vehicle"

            if multipleSPSTs

                % Table 7.9.2.1-5: vehicle with multiple scattering points
                % parameters are independent of both azimuth and elevation.
                % Therefore parameters have the same values for all
                % theta/phi, and only vary based on scattering point index
                % P. the rcsParams input for multi-SPST targets are already
                % configured here for the appropriate SPST. 
                phiC = rcsParams(1)*ones(size(theta));
                phi3dB = rcsParams(2)*ones(size(theta));
                thetaC = rcsParams(3)*ones(size(theta));
                theta3dB = rcsParams(4)*ones(size(theta));
                G_max = rcsParams(5)*ones(size(theta));
                sigma_max = rcsParams(6)*ones(size(theta));

                % For the scattering points associated with roof of the
                % vehicle, sigma_H is 0
                if isnan(rcsParams(1)) % roof
                    phiC = phi;
                end

            else

                % Table 7.9.2.1-4
                phiC = getRCSParameterForVehicle(rcsParams(:,1),phi,theta);
                phi3dB = getRCSParameterForVehicle(rcsParams(:,2),phi,theta);
                thetaC = getRCSParameterForVehicle(rcsParams(:,3),phi,theta);
                theta3dB = getRCSParameterForVehicle(rcsParams(:,4),phi,theta);
                G_max = getRCSParameterForVehicle(rcsParams(:,5),phi,theta);
                sigma_max = getRCSParameterForVehicle(rcsParams(:,6),phi,theta);

                % When theta is in the range [0,30), sigma_H is 0
                phiC(theta >= 0 & theta < 30) = phi(theta >= 0 & theta < 30);
                phi3dB(theta >= 0 & theta < 30) = 1;


            end

        case "AGV"

            if multipleSPSTs

                % Table 7.9.2.1-7: AGV with multiple scattering points
                % parameters are independent of both azimuth and elevation.
                % Therefore parameters have the same values for all
                % theta/phi, and only vary based on scattering point index
                % P. the rcsParams input for multi-SPST targets are already
                % configured here for the appropriate SPST. 
                phiC = rcsParams(1)*ones(size(theta));
                phi3dB = rcsParams(2)*ones(size(theta));
                thetaC = rcsParams(3)*ones(size(theta));
                theta3dB = rcsParams(4)*ones(size(theta));
                G_max = rcsParams(5)*ones(size(theta));
                sigma_max = rcsParams(6)*ones(size(theta));

                % For the scattering points associated with roof of the
                % AGV, sigma_H is 0
                if isnan(rcsParams(1)) % roof
                    phiC = phi;
                end

            else

                % Table 7.9.2.1-6
                phiC = getRCSParameterForAGV(rcsParams(:,1),phi,theta);
                phi3dB = getRCSParameterForAGV(rcsParams(:,2),phi,theta);
                thetaC = getRCSParameterForAGV(rcsParams(:,3),phi,theta);
                theta3dB = getRCSParameterForAGV(rcsParams(:,4),phi,theta);
                G_max = getRCSParameterForAGV(rcsParams(:,5),phi,theta);
                sigma_max = getRCSParameterForAGV(rcsParams(:,6),phi,theta);

                % When theta is in the range [0,30), sigma_H is 0
                phiC(theta >= 0 & theta < 30) = phi(theta >= 0 & theta < 30);
                phi3dB(theta >= 0 & theta < 30) = 1;

            end

    end

    std_S_dB = rcsParams(1,8);

end

function v = getRCSParameterForUAV(rcsParam,phi,theta)

    v = zeros(size(phi));

    v(theta >=  45 & theta < 135  &  phi >=  45 & phi < 135) = rcsParam(1); % left
    v(theta >=  45 & theta < 135  &  phi >= 135 & phi < 225) = rcsParam(2); % back
    v(theta >=  45 & theta < 135  &  phi >= 225 & phi < 315) = rcsParam(3); % right
    v(theta >=  45 & theta < 135  &  phi >= -45 & phi <  45) = rcsParam(4); % front
    v(theta >= 135 & theta < 180  &  phi >=   0 & phi < 360) = rcsParam(5); % bottom
    v(theta >=   0 & theta <  45  &  phi >=   0 & phi < 360) = rcsParam(6); % roof

end

function v = getRCSParameterForHuman(rcsParam,phi)

    v = zeros(size(phi));

    v(phi >= -90 & phi <  90) = rcsParam(1); % front
    v(phi >=  90 & phi < 270) = rcsParam(2); % back

end

function v = getRCSParameterForVehicle(rcsParam,phi,theta)

    v = zeros(size(phi));
    
    v(theta >=  30 & theta <= 180 & phi >=  45 & phi < 135) = rcsParam(1); % left
    v(theta >=  30 & theta <= 180 & phi >= 135 & phi < 225) = rcsParam(2); % back
    v(theta >=  30 & theta <= 180 & phi >= 225 & phi < 315) = rcsParam(3); % right
    v(theta >=  30 & theta <= 180 & phi >= -45 & phi <  45) = rcsParam(4); % front
    v(theta >=  0  & theta <   30 & phi >=   0 & phi < 360) = rcsParam(5); % roof

end

function v = getRCSParameterForAGV(rcsParam,phi,theta)

    v = zeros(size(phi));
    
    v(theta >=  30 & theta <= 180 & phi >= -45 & phi <  45) = rcsParam(1); % front
    v(theta >=  30 & theta <= 180 & phi >=  45 & phi < 135) = rcsParam(2); % left
    v(theta >=  30 & theta <= 180 & phi >= 135 & phi < 225) = rcsParam(3); % back
    v(theta >=  30 & theta <= 180 & phi >= 225 & phi < 315) = rcsParam(4); % right
    v(theta >=  0  & theta <   30 & phi >=   0 & phi < 360) = rcsParam(5); % roof

end

function [k1,k2] = getkValues(sensingTarget)
% Get the coefficients k1 and k2 as defined in Eq. (7.9.2-3) for
% calculating sigma_MD_dB for RCS model 2 

    switch sensingTarget
        case "UAV"
            k1 = 6.05;
            k2 = 1.33;
        case "human"
            k1 = 0.5714;
            k2 = 0.1;
        case "vehicle"
            k1 = 6;
            k2 = 1.65;
        case "AGV"
            k1 = 12;
            k2 = 1.45;
    end

end

function [thetaI,phiI,thetaS,phiS] = getLocalAngles(isaccfg,anglesAoA,anglesAoD,anglesZoA,anglesZoD)
% obtain the incident/scattered angles in local coordinate system (LCS) for
% RCS calculations. The input azimuth/zenith angles to this function are in
% the global coordinate system (GCS).

    % incident/scattered zenith/azimuth angles in GCS
    thetaI = anglesZoA;  % incident zenith
    phiI = anglesAoA;    % incident azimuth
    thetaS = anglesZoD;  % scattered zenith
    phiS = anglesAoD;    % scattered azimuth

    % target orientation in GCS
    targetOrientationG = isaccfg.TargetOrientation;
    alpha = targetOrientationG(1); % only supports one target 
    beta = targetOrientationG(2); 
    gamma = targetOrientationG(3); 

    % incident/scattered angles in LCS 
    [thetaI,phiI] = gcs2lcs(thetaI,phiI,alpha,beta,gamma);
    [thetaS,phiS] = gcs2lcs(thetaS,phiS,alpha,beta,gamma);

end

function [thetaL,phiL] = gcs2lcs(thetaG,phiG,alpha,beta,gamma)
% this function converts the angles thetaG and phiG from the GCS to the LCS
% using the target's orientation in the GCS, which enables definition of the
% rotation matrix from GCS to LCS, from the coordinate frame
% transformations detailed in Section 7.1.3. The inverse (transpose)
% rotation matrix is used to obtain the angles in the LCS. 

    % rotation matrix from LCS to GCS
    R = wireless.internal.channelmodels.rotationMatrix([alpha;beta;gamma]); 
        
    % Eq. (7.1-6) - get Cartesian unit vector of the angle
    rhoHat = getUnitVector(thetaG,phiG);

    % Eq. (7.1-7)
    thetaL = squeeze(acosd(pagemtimes([0 0 1]*R.',rhoHat)));

    % Eq. (7.1-8)
    phiL = squeeze(rad2deg(angle(pagemtimes([1 1i 0]*R.',rhoHat))));

end

function beta = getBistaticAngle(thetaI,phiI,thetaS,phiS)
% Get the bistatic angle (beta) between the incident ray and scattered ray
% within the plane defined by the incident angle and scattering angle for
% Eq. (7.9.2-2) & Eq. (7.9.2-3)

    % Eq. (7.1-6) - get Cartesian unit vectors
    rhoHatI = getUnitVector(thetaI,phiI);
    rhoHatS = getUnitVector(thetaS,phiS);

    % Reshape rhoHatS to obtain 4-D dot product for beta 
    rhoHatS = reshape(rhoHatS, [3 1 1 size(thetaS,1) size(thetaS,2)]); 

    % bistatic angle beta is the inverse cosine of the dot product 
    dotProduct = squeeze(sum(rhoHatS.*rhoHatI,1)); % N'-by-M'-by-N-by-M
    dotProduct = max(min(dotProduct,1),-1); % enforce beta 0 to 180 degrees (Eq. (7.9.2-3))
    beta = acosd(dotProduct);

end

function [thetaB,phiB] = getBisectorAngles(thetaI,thetaS,phiI,phiS)
% Get the zenith (theta) and azimuth (phi) bisector angles for Eq. 7.9.2-3.
% The bisector angle is the angle midway between the two angles. This
% function returns a 4-D thetaB and phiB. 

    % Eq. (7.1-6) - get Cartesian unit vectors
    rhoHatI = getUnitVector(thetaI,phiI);
    rhoHatS = getUnitVector(thetaS,phiS);

    rhoHatS = reshape(rhoHatS, [3 1 1 size(thetaS,1) size(thetaS,2)]); 

    % bisector vector
    vB = rhoHatI + rhoHatS;

    normvB = sqrt(sum(vB.^2,1));
    uvB = vB./normvB; % unitary 

    x = squeeze(uvB(1,:,:,:,:));
    y = squeeze(uvB(2,:,:,:,:));
    z = squeeze(uvB(3,:,:,:,:));

    % bisector angles
    thetaB = acosd(z);
    phiB = atan2d(y,x);

end

function rhoHat = getUnitVector(theta,phi)
% Note: this function produces sets of Cartesian unit vectors according to
% the sizes of theta and phi input arrays i.e. rhoHat is sized
% 3-by-size(theta,1)-by-size(theta,2)
    
    % Eq. (7.1-6) - get Cartesian unit vectors
    rhoHat = [sind(theta).*cosd(phi);sind(theta).*sind(phi);cosd(theta)];
    rhoHat = reshape(rhoHat,3,size(theta,1),[]);

end

%% ISAC-specific fast fading model functionality

function R_0 = linkRayCoupling(isaccfg,tx2st,st2rx,rs)
% Section 7.9.4.1 Step 9

    [Nprime,Mprime] = size(st2rx.rayCoupling,[1 2]);
    [N,M] = size(tx2st.rayCoupling,[1 2]);

    R_0 = false([Nprime+1 Mprime+1 N+1 M+1]);

    % Step 9 says "In the STX-SPST link, a LOS ray is represented by n = 0,
    % m = 0, while a NLOS ray m of a stochastic cluster n is represented by
    % n > 0, m > 0"

    % LOS STX-SPST coupling with LOS SPST-SRX
    R_0(1,1,1,1) = true; 

    % LOS STX-SPST coupling with NLOS SPST-SRX
    R_0(2:end,2:end,1,1) = true;

    % NLOS STX-SPST coupling with LOS SPST-SRX
    R_0(1,1,2:end,2:end) = true;

    % NLOS STX-SPST coupling with NLOS SPST-SRX
    if (strcmpi(isaccfg.LinkRayCoupling,'Option 1'))

        R_0(2:end,2:end,2:end,2:end) = true; % Option 1: couple all rays

    else % Option 2: randomly couple the rays
               
        % SPST-SRX NLOS rays 
        [idxNprime, idxMprime] = ndgrid(2:Nprime+1,2:Mprime+1);
        M1 = [idxNprime(:), idxMprime(:)];
        
        % STX-SPST NLOS rays
        [idxN, idxM] = ndgrid(2:N+1,2:M+1);
        M2 = [idxN(:), idxM(:)];
               
        % get random indices
        minM1M2 = min(size(M1,1),size(M2,1));
        idx1 = rs.randperm(size(M1,1),minM1M2);
        idx2 = rs.randperm(size(M2,1),minM1M2);
        
        % randomly couple
        for i = 1:minM1M2
            R_0(M1(idx1(i),1),M1(idx1(i),2),M2(idx2(i),1),M2(idx2(i),2)) = true;
        end
  
    end

end

function [pathPowers,rcsInfo,R] = obtainPowers(isaccfg,tx2st,st2rx,anglesAoA,anglesAoD,anglesZoA,anglesZoD,stRS,R_0)
% Section 7.9.4.1 Step 10

% Cluster powers already generated in Section 7.9.5 Step 6, here obtain the
% powers for all generated paths 

    % Get RCS coefficient components
    [sigma_M,sigma_D,sigma_S,mu_S_dB,std_S_dB] = rcsModel(isaccfg,anglesAoA,anglesAoD,anglesZoA,anglesZoD,stRS,R_0); % first output, sigma_M, is only applied in Step 15
    rcsInfo.sigma_M = sigma_M;
    rcsInfo.sigma_D = sigma_D;
    rcsInfo.sigma_S = sigma_S;
    rcsInfo.mu_S_dB = mu_S_dB;
    rcsInfo.std_S_dB = std_S_dB;
    
    Ptx = rayPowers(isaccfg,tx2st);
    Prx = rayPowers(isaccfg,st2rx);

    % Eq. (7.9.4-1)
    rcsFactor = sigma_D .* min(sigma_S,10^((mu_S_dB+3*std_S_dB)/10));
    pathPowers = rcsFactor .* Prx .* permute(Ptx,[3 4 1 2]); % n' m' n m
    rcsInfo.rcsFactor = rcsFactor;

    % pathPowers is the power of the paths in Set R_0, and set R is given
    % by the non NaN locations stored in pathPowers. The entire
    % (N'+1)-by-(M'+1)-(N+1)-by-(M+1) structure is kept for sanity

    % Select paths to remove, those with less than X dB power compared to
    % the maximum power among all paths
    pathPowers_dB = 10*log10(pathPowers);
    X = isaccfg.ThresholdPower;
    threshold = max(pathPowers_dB(:)) + X;
    toRemove = (pathPowers_dB < threshold);

    % "The path that couples the LOS ray in the STX-SPST link and the LOS
    % ray in the SPST-SRX link, if present, is included in set R"
    toRemove(1,1,1,1) = false;

    % Remove paths from set R_0 to create set R
    R = R_0;
    R(toRemove) = 0;

end

function P = rayPowers(isaccfg,chdata)

    M = size(chdata.rayCoupling,2);
    P = repmat((chdata.pathPowers/M).',1,M);
    P = addZeroSubscripts(P); % (N+1)-by-(M+1)

    if chdata.LOS && ~chdata.indoor
        % Ricean K-factor in linear scale
        if (isaccfg.LOSRayOnly)
            Kr = realmax;
        else
            Kr = 10^(chdata.K/10);
        end

        P = P / (Kr+1);
        P(1,1) = Kr / (Kr+1); % LOS
    end

end

% Add a row and column of zeros at the top and left of 'in' to produce
% 'out'. This converts an N-by-M matrix allowing for 1-based cluster and
% ray subscripts n=1...N and m=1...M into a (N+1)-by-(M+1) matrix allowing
% for additional subscript n=0, m=0 for the LOS ray as described in Section
% 7.9.4 Step 9. Of course, the matrix subscripting in MATLAB remains
% 1-based, so care needs to be taken when using the output
function out = addZeroSubscripts(in)

    [N,M] = size(in);
    out = zeros(N+1,M+1);
    out(2:end,2:end) = in;

end

function [pathDelays,tx2st,st2rx] = obtainDelays(obj,tx2stcfg,st2rxcfg,tx2st,st2rx)
% Step 11 Section 7.9.5

% Cluster delays already generated in Step 5, here obtain the absolute
% delay for each path in set R 

    persistent c; 
    if (isempty(c))
        c = physconst('LightSpeed');
    end

    % Eq. (7.9.4-2)
    [tx2st,tauTx,deltaTauTx] = getTauTerms(obj,tx2stcfg,tx2st);
    [st2rx,tauRx,deltaTauRx] = getTauTerms(obj,st2rxcfg,st2rx);
      
    pathDelays = tauRx + st2rx.d_3D/c +  deltaTauRx + permute(tauTx,[3 4 1 2]) + tx2st.d_3D/c + permute(deltaTauTx,[3 4 1 2]); % n' m' n m

end

function [chdata,tau,deltaTau] = getTauTerms(obj,cfg,chdata)

    [N,M] = size(chdata.rayCoupling,[1 2]);
    tau = repmat(chdata.pathDelays.',1,M);

    % For the two strongest clusters, revise sub-cluster delays according
    % to Eq. (7.5-26)
    NSC = min(N,2);
    [R_1,R_2,R_3] = wireless.internal.channelmodels.getRayMapping(M);
    R = {R_1 R_2 R_3};
    C_DS = chdata.params.C_DS * 1e-9;
    subClusterDelays = zeros([1 M]);
    for i = 1:numel(R)
        subClusterDelays(R{i}) = (i-1) * 1.28 * C_DS;
    end
    tau(1:NSC,:) = tau(1:NSC,:) + subClusterDelays;

    deltaTau = getDeltaTau(obj,cfg);

    % Record Delta tau in channel outputs (used to detect if absolute ToA
    % needs considered when applying Section 7.6.3.2 "Spatially-consistent
    % UT/BS mobility modelling")
    chdata.Mobility.Deltatau = deltaTau;

    deltaTau = repmat(deltaTau,size(tau));

    % Step 11 says "where, for the LOS ray ... tau_...,0,0=0", which is
    % taken care of by the effect of 'addZeroSubscripts'
    tau = addZeroSubscripts(tau); % (N+1)-by-(M+1)

    % Below Eq. (7.9.4-2) it is stated that the deltaTau values are
    % generated separately for NLOS rays according to Section 7.6.9
    deltaTau = addZeroSubscripts(deltaTau); % (N+1)-by-(M+1)

end

function deltaTau = getDeltaTau(obj,chCfg)

    % Update node positions and subscripts in structure containing
    % variables related to spatial consistency
    sc = obj.SCRVs;
    sc.BSPosition = chCfg.BSPosition;
    sc.UEPosition = chCfg.UEPosition;
    sc.NodeSubs = chCfg.NodeSubs;

    % Get applicable scenario
    if (~isempty(chCfg.ReferenceTR.ScenarioAbsoluteToA))
        s = chCfg.ReferenceTR.ScenarioAbsoluteToA;
    else
        s = chCfg.Scenario;
    end

    % Table 7.6.9-1
    mu_lgDeltatau = obj.nr5g.scenarioSwitch(s,-7.5,-7.4,-8.33,-8.6,-7.5);
    sigma_lgDeltatau = obj.nr5g.scenarioSwitch(s,0.5,0.2,0.26,0.1,0.4);

    % Section 7.6.9 "Delta tau is generated from a log-normal distribution"
    nSites = size(sc.ATOA.AutoCorrMatrices,3);
    ai = mod(sc.NodeSubs(1) - 1,nSites) + 1;
    uepos = chCfg.UEPosition;
    rv = normalAutoCorrRVs(obj,sc.ATOA.AutoCorrMatrices(:,:,ai),sc.ATOA.FirstCoord,uepos(1:2));

    deltaTau = 10^(mu_lgDeltatau + sigma_lgDeltatau*rv);

end

function rvs = normalAutoCorrRVs(obj,autoCorrMatrix,firstCoord,pos)

    % Get uniform distributed spatially correlated RVs
    rvs = obj.nr5g.uniformAutoCorrRVs(autoCorrMatrix,firstCoord,pos);

    % Transform to normal distribution using the inverse probability
    % integral transform
    rvs = inverseProbabilityIntegralTransform(rvs);

end

function rvs = inverseProbabilityIntegralTransform(rvs)

    rvs = sqrt(2) * erfinv(2*rvs - 1);

end

function [xprTx,xprRx,xpr] = generateXPRs(isaccfg,tx2st,st2rx,rs,R)
% Step 12: Generate cross polarization power ratios for paths in set R

    % Note Table 7.5-6 already incorporated in params for xprTx and xprRx  
    xprTx = getXPRs(tx2st.params.mu_XPR,tx2st.params.sigma_XPR,tx2st.siteuers,size(R,[3 4]));
    xprRx = getXPRs(st2rx.params.mu_XPR,st2rx.params.sigma_XPR,st2rx.siteuers,size(R,[1 2]));

    % for CPM construction in Step 14
    xprTx(1,1) = Inf;
    xprRx(1,1) = Inf; 
    
    % Table 7.9.2.2-1 for xpr 
    [muXPR,sigmaXPR] = getTargetParametersXPRs(isaccfg);
    xpr = getXPRs(muXPR,sigmaXPR,rs,size(R));
    if (isaccfg.LOSRayOnly)
        xpr(1,1) = Inf;
    end

end

function xpr = getXPRs(mu,sigma,rs,siz)

    xpr = mu + sigma*rs.randn(siz); 

    % Draw XPR values (kappa) in linear scale Eq. (7.9.4-3)
    xpr = 10.^(xpr/10);

end

function [mu,sigma] = getTargetParametersXPRs(isaccfg)
    % Table 7.9.2.2-1: Get parameters on XPR (dB) for the targets

    switch isaccfg.SensingTarget
        case "UAV"
            mu = 13.75; sigma = 7.07; 
        case "human"
            mu = 19.81; sigma = 4.25;
        case "vehicle"
            mu = 21.12; sigma = 6.88;
        case "AGV"
            mu =  9.60; sigma = 6.85;
    end

end

function [initialPhasesTx,initialPhasesRx,initialPhases] = generateInitialPhases(isaccfg,tx2st,st2rx,rs,R)

    initialPhasesTx = getPhi(tx2st.uers,size(R,[3 4]));
    initialPhasesRx = getPhi(st2rx.uers,size(R,[1 2]));
    initialPhases = getPhi(rs,size(R));

    % For LOS ([1 0 ; 0 -1]) CPM construction in Step 14
    initialPhasesTx(1,1,1) = 0; 
    initialPhasesTx(1,1,4) = pi;
    initialPhasesRx(1,1,1) = 0;
    initialPhasesRx(1,1,4) = pi;
    if (isaccfg.LOSRayOnly)
        initialPhases(1,1,1,1,1) = 0;
        initialPhases(1,1,1,1,4) = pi;
    end

end

function initPhase = getPhi(rs,siz)

    initPhase = (rs.rand([siz 4])*2*pi) - pi; % radians

end

function [anglesAoA,anglesAoD,anglesZoA,anglesZoD,targetAngles] = prepareAngles(tx2st,st2rx)

    % Allow for additional subscript n=0, m=0 for the LOS ray
    anglesAoA = addZeroSubscripts(st2rx.anglesAoA); % size (N'+1)-by-(M'+1)
    anglesAoD = addZeroSubscripts(tx2st.anglesAoD); % size (N+1)-by-(M+1)
    anglesZoA = addZeroSubscripts(st2rx.anglesZoA); % size (N'+1)-by-(M'+1)
    anglesZoD = addZeroSubscripts(tx2st.anglesZoD); % size (N+1)-by-(M+1)

    % Set LOS ray angles if LOS ray is present
    if st2rx.LOS && ~st2rx.indoor
        anglesAoA(1,1) = st2rx.phiLOS_AoA;
        anglesZoA(1,1) = st2rx.thetaLOS_ZoA;
    end
    if tx2st.LOS && ~tx2st.indoor
        anglesAoD(1,1) = tx2st.phiLOS_AoD;
        anglesZoD(1,1) = tx2st.thetaLOS_ZoD;
    end

    % Relative to the target:
    targetAngles = struct();
    targetAngles.anglesAoA = addZeroSubscripts(tx2st.anglesAoA); 
    targetAngles.anglesAoD = addZeroSubscripts(st2rx.anglesAoD); 
    targetAngles.anglesZoA = addZeroSubscripts(tx2st.anglesZoA); 
    targetAngles.anglesZoD = addZeroSubscripts(st2rx.anglesZoD);
    if tx2st.LOS && ~tx2st.indoor
        targetAngles.anglesAoA(1,1) = tx2st.phiLOS_AoA;
        targetAngles.anglesZoA(1,1) = tx2st.thetaLOS_ZoA;
    end
    if st2rx.LOS && ~st2rx.indoor
        targetAngles.anglesAoD(1,1) = st2rx.phiLOS_AoD;
        targetAngles.anglesZoD(1,1) = st2rx.thetaLOS_ZoD;
    end

end

function s = getNodeInfo(obj)

    % 'stx' and 'srx' are strings "TRP" or "UE"
    mode = strsplit(obj.SensingMode," ");
    if mode(2) == "Monostatic"
        stx = mode(1);
        srx = mode(1);
    elseif mode(2) == "Bistatic"
        txrx = strsplit(mode(1),"-");
        stx = txrx(1);
        srx = txrx(2);
    end
    s.STX = stx;
    s.STs = "UE";
    s.SRX = srx;

    % Get TRPs and UEs and the node subscripts and size vectors of STX, ST
    % and SRX
    TRPs = {};
    UEs = {};
    if (s.STX=="TRP")
        [TRPs,stxNodeSubs,stxNodeSiz] = addTRP(TRPs,obj.STX);
    else
        [UEs,stxNodeSubs,stxNodeSiz] = addUE(UEs,obj.STX);
    end
    K = numel(obj.STs);
    stNodeSubs = zeros(K,3);
    stNodeSiz = zeros(K,3);
    for k = 1:K
        [UEs,stNodeSubs(k,:),stNodeSiz(k,:)] = addUE(UEs,obj.STs(k)); % ST is always a UE
    end
    if (s.SRX=="TRP")
        [TRPs,srxNodeSubs,srxNodeSiz] = addTRP(TRPs,obj.SRX);
    else
        [UEs,srxNodeSubs,srxNodeSiz] = addUE(UEs,obj.SRX);
    end

    % For monostatic sensing, the SRX is the STX so re-use its node
    % subscripts and size vector
    isMonostatic = contains(obj.SensingMode,"Monostatic");
    if (obj.ReferenceTR && isMonostatic)
        srxNodeSubs = stxNodeSubs;
        srxNodeSiz = stxNodeSiz;
    end

    % Store TRPs and UEs in output structure
    s.TRPs = TRPs;
    s.UEs = UEs;

    % Get overall node size vector before accounting for links with the
    % same node type at each link end
    nodeSiz = max([stxNodeSubs; stNodeSubs; srxNodeSubs],[],1);
    customNodeSiz = max([stxNodeSiz; stNodeSiz; srxNodeSiz],[],1);
    nodeSiz = max([nodeSiz; customNodeSiz],[],1);

    % Create structure fields with information on each link
    s.STXtoSRX = getLinkInfo(stxNodeSubs,srxNodeSubs,nodeSiz);
    s.STXtoSTs = getLinkInfo(stxNodeSubs,stNodeSubs,nodeSiz);
    if (obj.ReferenceTR && isMonostatic)
        % For monostatic sensing, configure the ST to SRX link as the
        % reciprocal of the STX to ST link
        s.STstoSRX = s.STXtoSTs;
        s.STXtoSTs.isUplink = false;
        s.STstoSRX.isUplink = true;
    else
        s.STstoSRX = getLinkInfo(stNodeSubs,srxNodeSubs,nodeSiz);
    end

end

function [TRPs,nodeSubs,nodeSiz] = addTRP(TRPs,TRP)

    TRPs = [TRPs TRP];

    if (~isempty(TRP.NodeSubs))
        site = TRP.NodeSubs(1);
        sector = TRP.NodeSubs(2);
    else
        site = numel(TRPs);
        sector = 1;
    end
    nodeSubs = [site sector 0];

    if (~isempty(TRP.NodeSiz))
        nodeSiz = [TRP.NodeSiz 0];
    else
        nodeSiz = [0 0 0];
    end

end

function [UEs,nodeSubs,nodeSiz] = addUE(UEs,UE)

    UEs = [UEs UE];

    if (~isempty(UE.NodeSubs))
        nodeSubs = UE.NodeSubs;
    else
        nodeSubs = [0 1 numel(UEs)];
    end

    if (~isempty(UE.NodeSiz))
        nodeSiz = UE.NodeSiz;
    else
        nodeSiz = [0 0 0];
    end

end

function s = getLinkInfo(txSubs,rxSubs,nodeSiz)

    if (isUE(txSubs)==isUE(rxSubs))
        s.isUplink = NaN;
    else
        s.isUplink = isUE(txSubs);
    end

    if (isnan(s.isUplink))
        nodeSubs = sameTypeNodeSubs(nodeSiz,txSubs,rxSubs);
    else
        if (s.isUplink)
            trpSubs = rxSubs;
            ueSubs = txSubs;
        else
            trpSubs = txSubs;
            ueSubs = rxSubs;
        end
        N = size(ueSubs,1);
        nodeSubs = [repmat(trpSubs(1:2),N,1) ueSubs(:,3)];
    end
    
    % Update overall node size vector to account for links with the same
    % node type at each link end
    if (isnan(s.isUplink))
        nodeSiz = sameTypeNodeSiz(nodeSiz);
    end

    s.NodeSiz = nodeSiz;
    s.NodeSubs = nodeSubs;

end

function y = isUE(subs)

    % Subscripts are for a UE if the third element (UE index) is non-zero.
    % Empty subscripts are also a UE, because they come from the case of
    % zero STs, and STs are always UEs
    y = (isempty(subs) || all(subs(:,3)~=0));

end

function nodeSiz = sameTypeNodeSiz(nodeSiz)

    % 'nUEasSite' is the number of extra sites needed to account for all
    % UEs treated as sites
    nUEasSite = nodeSiz(3);

    % 'nTRPasUE' is the number of extra UEs needed to account for all TRP
    % sites and sectors treated as UEs
    nTRPasUE = prod(nodeSiz(1:2));

    % Update site and UE entries in 'nodeSiz'
    nodeSiz([1 3]) = nodeSiz([1 3]) + [nUEasSite nTRPasUE];

end

function nodeSubs = sameTypeNodeSubs(nodeSiz,txSubs,rxSubs)

    % Create 'nodeSubs'
    if (~isUE(txSubs))

        % TRP-to-TRP link

        % 'thisTRPasUE' combines rx TRP site and sector indices into a UE
        % index
        i = rxSubs(1);
        j = rxSubs(2);
        thisTRPasUE = (i-1)*nodeSiz(2) + j;

        % 'nodeSubs' consists of site and sector index of the tx TRP, and
        % index of the rx TRP treated as a UE
        nodeSubs = [txSubs(1:2) nodeSiz(3)+thisTRPasUE];

    else

        % UE-to-UE link

        % 'thisUEasSite' uses tx UE index as a site index
        thisUEasSite = txSubs(:,3);

        % 'nodeSubs' consists of index of the tx UE treated as a site,
        % sector set to 1, and the index of the rx UE
        N = size(txSubs,1);
        if (N~=1)
            nodeSubs = [nodeSiz(1)+thisUEasSite ones(N,1) repmat(rxSubs(3),N,1)];
        else
            N = size(rxSubs,1);
            nodeSubs = [nodeSiz(1)+repmat(thisUEasSite,N,1) ones(N,1) rxSubs(:,3)];
        end

    end

end

function [extents,extentsZ] = getScenarioExtents(obj,chcfg,nodeinfo)

    sitePositions = getNodePositions(nodeinfo.TRPs);
    uePositions = getNodePositions(nodeinfo.UEs);
    allnodepos = [sitePositions; uePositions];

    if (~isempty(obj.ScenarioExtents))
        extents = obj.ScenarioExtents;
    else
        if (startsWith(chcfg.Scenario,"InF"))
            xy = chcfg.HallSize([1 2]);
            extents = [-xy/2 xy];
        else
            if (isCellular(chcfg.Scenario) && ~isempty(sitePositions))
                % Get polygons that are the boundaries for each site
                ISD = chcfg.InterSiteDistance;
                [sitex,sitey] = obj.nr5g.sitePolygon(ISD);
                % Get bounding box of the union of the site polygons
                sysx = sitePositions(:,1) + sitex;
                sysy = sitePositions(:,2) + sitey;
                minpos = [min(sysx, [], 'all'), min(sysy, [], 'all')];
                maxpos = [max(sysx, [], 'all'), max(sysy, [], 'all')];
            else % InH or no TRPs
                % Note: the bounding box around the node positions is
                % extended by 1 meter on all sides here to avoid precision
                % issues when determining if nodes lie inside the scenario
                % extents
                maxpos = max(allnodepos(:,1:2),[],1) + 1;
                minpos = min(allnodepos(:,1:2),[],1) - 1;
            end
            extents = [minpos maxpos-minpos];
        end
    end

    % Get extents in the z-plane (i.e. height). Note that the extents
    % around the node positions is extended by 1 meter, consistent with how
    % 'extents' above is created for the case of InH or when there are no
    % TRPs
    maxZ = max(allnodepos(:,3),[],1) + 1;
    minZ = min(allnodepos(:,3),[],1) - 1;
    extentsZ = [minZ maxZ-minZ];

end

function chcfg = fieldprecedence(chcfg,opts,f1,f2)

    if ~isempty(opts.(f1))
        chcfg.(f1) = opts.(f1);
    else
        chcfg.(f2) = opts.(f2);
    end

end

function v = getFieldOrDefault(s,f,d)

    if ~isempty(s.(f))
        v = s.(f);
    else
        v = d;
    end

end

function pos = getNodePositions(nodes)
    
    pos = cell2mat(cellfun(@(y)y.Position,nodes(:),UniformOutput=false));

end

function sc = setupSCRVsForAbsoluteTOA(obj,chCfg,sc)

    % A system-wide RNG is used here: for absolute time of arrival, an
    % autocorrelation matrix per site is created as Section 7.6.9 states
    % that "delta tau is generated independently for links between the same
    % UT and different BS sites"
    seed = prod(chCfg.NodeSiz) + chCfg.Seed;
    systemrs = RandStream('mt19937ar','Seed',seed);

    % The system-wide RNG is used to create site-specific spatially
    % consistent parameters by creating one autocorrelation matrix per site
    minpos = chCfg.ScenarioExtents(1:2);
    maxpos = minpos + chCfg.ScenarioExtents(3:4);
    nSites = size(chCfg.SitePositions,1);
    atoaDelta = atoaDelta_(obj,chCfg);
    distances = repmat(atoaDelta,1,nSites);
    [sc.ATOA.AutoCorrMatrices,sc.ATOA.FirstCoord] = obj.nr5g.createAutoCorrMatrices(systemrs,minpos,maxpos,distances);

end

% Absolute time of arrival Table 7.6.9-1 "Correlation distance in the
% horizontal plane". The table does not provide a correlation distance for
% InF-HH, 11 m is assumed here
function d = atoaDelta_(obj,chCfg)
    s = chCfg.Scenario;

    % For InH, augment the scenario name with the office scenario type
    s = augmentInHscenario(s,chCfg.OfficeType);

    d = obj.nr5g.scenarioSwitch(s,15,50,50,{10 10},{6 6 11 11 11});
end

% Section 7.6.9 "Absolute time of arrival"
function channel = absoluteTOA(obj,chCfg,channel,chinfo)

    persistent c0;
    if isempty(c0)
        c0 = physconst('LightSpeed');
    end

    if (chCfg.HasSmallScale)

        % Eq. (7.6-44a) is interpreted as saying that for an LOS link in
        % terms of "Step 2: Assign propagation condition (NLOS/LOS)", Δτ
        % should be zero. That is, "excess delay in NLOS, Δτ" only applies
        % to NLOS
        if (chinfo.LOS)
            Deltatau = 0;
        else
            Deltatau = getDeltaTau(obj,chCfg);
        end

        % Section 7.6.9 "Delta tau should further be upper bounded by 2L/c,
        % where L is the is the largest dimension of the factory hall and
        % office room"
        s = chCfg.Scenario;
        if (startsWith(s,"InF") || startsWith(s,"InH"))
            if (startsWith(s,"InF"))
                L = max(chCfg.HallSize);
            else % "InH"
                l = chCfg.ScenarioExtents(3);
                w = chCfg.ScenarioExtents(4);
                h = chCfg.ScenarioExtentsZ(2);
                L = max([l w h]);
            end
            Deltatau = min(Deltatau,2*L/c0);
        end

        % Eq. (7.6-43) and Eq. (7.6-44)
        ss = channel.SmallScale;
        pathDelays = ss.PathDelays;

        if contains(obj.SensingMode,"Monostatic")
            % Step 4 of Section 7.9.4.2: replace d_3D/c term with the
            % following:
            if obj.SensingMode == "UE Monostatic"
                h_TX = chCfg.UEPosition(3);
            else
                h_TX = chCfg.BSPosition(3);
            end
            [~,~,c_d,~,~,c_h] = getMonostaticReferencePointParameters(obj.SensingMode,obj.CommunicationScenario,chCfg.UEPosition(3));
            a = (chinfo.d_3D - sqrt(c_d^2+(c_h-h_TX)^2))/c0;

            timeDelay = max(a,0);

        else
            timeDelay = (chinfo.d_3D / c0);
        end

        pathDelays = pathDelays + timeDelay;
        
        if (chCfg.FastFading)
            LOS = ss.HasLOSCluster;
            pathDelays((1+LOS):end) = pathDelays((1+LOS):end) + Deltatau;
        end

        % Update small scale channel path delays
        channel.SmallScale.PathDelays = pathDelays;

        % Update path delays
        isCDLChannel = ~isstruct(channel.SmallScale);
        if (isCDLChannel)
            ssinfo = info(channel.SmallScale);
            channel.PathDelays = ssinfo.PathDelays;
        else
            channel.PathDelays = channel.SmallScale.PathDelays;
        end

        % Record Delta tau in channel output (used to detect if absolute
        % ToA needs considered when applying Section 7.6.3.2
        % "Spatially-consistent UT/BS mobility modelling")
        channel.Mobility.Deltatau = Deltatau;

    end

end

function [f,d] = makeChannelFilter(varargin)

    if (nargin==1)
        obj = varargin{1};
        [f,d] = makeChannelFilter(obj.SampleRate,obj.pathDelays);
    else % nargin==2
        sampleRate = varargin{1};
        pathDelays = varargin{2};
        f = comm.ChannelFilter();
        f.SampleRate = sampleRate;
        f.PathDelays = pathDelays;
        f.FilterDelaySource = 'Custom';
        f.FilterDelay = 7;
        f.NormalizeChannelOutputs = false;
        d = f.FilterDelay;
    end

end

function [sampleTimes,cidx] = getHighestRateSampleTimes(st)

    % 'cidx' is the index of the channel with the most sample times, those
    % sample times will be used as the output
    [~,cidx] = max(cellfun(@numel,st));
    sampleTimes = st{cidx};

end

function pathGains = assembleOverallPathGains(sampleRate,pg,st,cidx)

    % 'Nsc_in_max' is the maximum number of channel snapshots across all
    % the channel outputs, given by the maximum number of sample times
    Nsc_in_max = numel(st{cidx});

    % 'Nc' is the number of channels
    Nc = numel(st);

    % Get a matrix of the input sample indices of the path gains for each
    % channel. There is a column for each of the channels, with the rows
    % containing the input sample index of the start of each section. For
    % channels with fewer sections than 'Nsc_in_max', the unused rows are
    % filled with NaN
    startpoints = NaN([Nsc_in_max Nc]);
    for i = 1:Nc        
        startpoints(1:numel(st{i}),i) = round(st{i}.' * sampleRate);
    end

    % 'u' is the vector of input sample indices in 'startpoints' for
    % channel 'cidx' used to define the output sample times
    u = startpoints(:,cidx);

    % For each element u(i), a channel snapshot is created which consists
    % of the path gains for each channel that belong to the section of the
    % waveform which includes input sample index u(i)

    % 'Nsc' is the number of channel snapshots in the output, equal to
    % 'Nsc_in_max'
    Nsc = Nsc_in_max;

    % 'Np' is a vector containing the number of paths in the path gains for
    % each channel
    Np = cellfun(@(x)size(x,2),pg);

    % 'Nt' is the number of transmit antennas
    Nt = size(pg{end},3);

    % 'Nr' is the number of receive antennas
    Nr = size(pg{end},4);

    % Create empty output path gains array
    pathGains = zeros([Nsc sum(Np) Nt Nr],"like",pg{end});

    % For each output channel snapshot
    for i = 1:Nsc

        % For each channel
        for j = 1:Nc

            % For the current channel, find the index of the snapshot in
            % the path gains that belongs to the section of the waveform
            % which includes input sample index u(i)
            pgidx = find(startpoints(:,j)<=u(i),1,'last');

            % Assign that path gains snapshot into the appropriate location
            % in the path gains output - the row for the current snapshot,
            % the columns which result in the paths across the channels
            % being concatenated along the second dimension, and all
            % transmit and receive antennas
            pathGains(i,sum(Np(1:j-1))+(1:Np(j)),:,:) = pg{j}(pgidx,:,:,:);

        end

    end

end

function sampleDensity = getSampleDensity(obj)

    if (strcmpi(obj.PathGainSampleRate,'auto'))
        sampleDensity = 64;
    else % 'signal'
        sampleDensity = Inf;
    end

end

function cs = augmentInHscenario(cs,officeType)
    if (cs=="InH")
        if (officeType=="Mixed")
            cs = cs + "-M";
        else % Open
            cs = cs + "-O";
        end
    end
end

function y = isCellular(s)

    y = any(s==["UMi","UMa","RMa"]);

end

function performSetup(obj,scupdate)

    unlocked = ~isLocked(obj);
    if (nargin==1)
        scupdate = false;
    end

    % Cross-validate object properties
    if (unlocked)
        validate(obj);
    end

    % Set the time to the InitialTime property value
    if (unlocked)
        obj.theTime = obj.InitialTime;
    end

    % Create individual channel links (background and target)
    if (unlocked)
        obj.SCRVs = [];
        obj.channels = createISACChannelLink(obj);
    end

    % Create channel information
    if (unlocked)
        s = struct();
        backgroundChannel = obj.channels{1};
        s.NumInputSignals = backgroundChannel.NumTransmitAntennas;
        s.NumOutputSignals = backgroundChannel.NumReceiveAntennas;
        Nc = numel(obj.channels);
        s.PathGains = cell(1,Nc);
        s.SampleTimes = cell(1,Nc);
        s.PathDelays = [];
        obj.theInfo = s;
    end

    if (unlocked || scupdate)

        pd0 = obj.theInfo.PathDelays;
        obj.theInfo.PathDelays = cellfun(@(c)c.PathDelays,obj.channels,UniformOutput=false);
        changedPathDelays = ~isequal(obj.theInfo.PathDelays,pd0);

        % Respond to changed path delays
        if (changedPathDelays)
            pathDelays = [obj.theInfo.PathDelays{:}];
            Nc = numel(obj.channels);
            if (Nc > 1)
                [obj.pathDelays,obj.pathDelayMapping] = makeUniquePathDelays(obj,pathDelays);
            else
                obj.pathDelays = pathDelays;
            end
            if (obj.ChannelFiltering)
                [obj.channelFilter,obj.theInfo.ChannelFilterDelay] = makeChannelFilter(obj);
            end
        end

        % Create Doppler phase continuity information. Set the previous
        % sample time to zero and Doppler phase of all paths to zero. Reset
        % the Doppler structure when the object is unlocked or when the
        % expected dimensions of the Doppler phase changed. This ensures
        % the phase is reset only when necessary, like when the number of
        % paths changed
        Nbc = getNumBackgroundChannels(obj.SensingMode);
        Nc = numel(obj.channels);
        if (Nc > Nbc && obj.HasSmallScale)
            if (isempty(obj.theDopplerStruct))
                obj.theDopplerStruct = cell(1,Nc);
            end

            for i = (Nbc+1):Nc % target channels, skip background channel(s)
                nR = size(obj.channels{i}.SmallScale.staticPathGains,2);
                if (isempty(obj.theDopplerStruct{i}))
                    changedDopplerStateSize = true;
                else
                    nR0 = size(obj.theDopplerStruct{i}(1).CumulativeDopplerPhase,1);
                    changedDopplerStateSize = (nR~=nR0);
                end
                if (changedDopplerStateSize)
                    obj.theDopplerStruct{i} = repmat(setDopplerStruct([nR 1]),1,3);
                end
            end

        end

    end

end

function pathFilters = makePathFilters(obj)

    if (isempty(obj.channelFilter))
        obj.channelFilter = makeChannelFilter(obj);
    end
    pathFilters = info(obj.channelFilter).ChannelFilterCoefficients.';

end

% Apply spatially consistent mobility
function spatiallyConsistentMobility(obj)

    bcfg = obj.channels{1}.ChannelConfiguration;
    cfg.SpatialConsistency = bcfg.SpatialConsistency;
    cfg.UpdateDistance = obj.UpdateDistance;

    t = obj.theTime;

    % Apply to background channel: 
    % N.b. spatial consistency is not modeled in the background channel for
    % monostatic sensing modes (Section 7.9.5.1)
    if contains(obj.SensingMode,"Bistatic")
        [obj.channels{1},updated] = obj.nr5g.spatiallyConsistentMobility(obj.SCRVs,obj.channels{1},cfg,t,obj.STX,obj.SRX);
        if (updated)
            obj.channels{1} = respondToSmallScaleBackgroundUpdate(obj,obj.channels{1});
        end
    else
        updated = false;
    end

    % Apply to target channel, if present
    Nc = numel(obj.channels);
    Nbc = getNumBackgroundChannels(obj.SensingMode);
    if (Nc > Nbc)
        for i = (Nbc+1):Nc % target channels, skip background channel
            c = obj.channels{i};
            k = getSTIndex(obj,i);
            [obj.channels{i},u] = spatiallyConsistentMobilityISAC(obj,c,cfg,t,obj.STX,obj.STs(k),obj.SRX);
            updated = updated || u;
        end
    end

    % If either channel has been updated, respond to changes in path delays
    % or number of clusters in state variables
    performSetup(obj,updated);

end

function y = isSpatiallyConsistentMobility(s)

    if (isempty(s.SpatialConsistency))
        y = true;
    else
        y = any(strcmpi(s.SpatialConsistency,["ProcedureA" "ProcedureB"]));
    end

end

function [ch,updated] = spatiallyConsistentMobilityISAC(obj,ch,mobcfg,t,STX,ST,SRX)

    % update target position, velocity and orientation
    ch.isaccfg = setupPerST(ch.isaccfg,ST);

    mobilityfn = @(chcfg,chdata,link,tx,rx)applyMobility(obj,ch.isaccfg,chcfg,chdata,mobcfg,t,link,tx,rx);
    [ch.tx2st,tx2st_updated] = mobilityfn(ch.tx2stcfg,ch.tx2st,"tx2st",STX,ST);
    [ch.st2rx,st2rx_updated] = mobilityfn(ch.st2rxcfg,ch.st2rx,"st2rx",ST,SRX);

    updated = (tx2st_updated || st2rx_updated);
    if (updated)
        ch = steps9to15(obj,ch);
    end

end

function [ch,updated] = applyMobility(obj,isaccfg,chcfg,ch,mobcfg,t,link,tx,rx)

    [chcfg,tx,rx] = updateSPSTPositionForMobility(isaccfg,chcfg,link,tx,rx);

    if (chcfg.swapTransmitAndReceive)
        temp = rx;
        rx = tx;
        tx = temp;
    end
    [ch,updated] = obj.nr5g.spatiallyConsistentMobility(obj.SCRVs,ch,mobcfg,t,tx,rx);

    if (updated)
        % Deal with any adjustments required to updated small-scale
        % channel, or any setup dependent on it
        chcfg = ch.ChannelConfiguration;
        chcfg.BSPosition = tx.Position;
        chcfg.UEPosition = rx.Position;
        ch = respondToSmallScaleTargetUpdate(obj,isaccfg,chcfg,ch);
    end

end

function [chcfg,tx,rx] = updateSPSTPositionForMobility(isaccfg,chcfg,link,tx,rx)

    % Get ST position and apply it to the channel configuration
    if (link=="tx2st")
        otherlink = "st2rx";
        ST = rx;
    else % "st2rx"
        otherlink = "tx2st";
        ST = tx;
    end
    f = getSPSTPositionField(chcfg,link);
    chcfg.(f) = ST.Position;

    % Apply SPST position offset
    chcfg = getSPSTPosition(isaccfg,chcfg,link);

    % Apply reference TR node height adjustments if applicable (this might
    % override the SPST position)
    refTR = chcfg.ReferenceTR;
    if (~isempty(refTR.NodeHeight))
        chcfg = refTR.NodeHeight(chcfg);
    end

    % Store SPST position in mobility inputs
    pos = chcfg.(f);
    if (link=="tx2st")
        rx.Position = pos;
    else
        tx.Position = pos;
    end

    % Store the position of other link end in mobility inputs (in case
    % reference TR node height adjustment has been applied to this link
    % end)
    o = getSPSTPositionField(chcfg,otherlink);
    otherpos = chcfg.(o);
    if (link=="tx2st")
        tx.Position = otherpos;
    else
        rx.Position = otherpos;
    end

end

function out = newDopplerStructs(obj)

    Nc = numel(obj.channels);
    Nbc = getNumBackgroundChannels(obj.SensingMode);
    out = cell(1,Nc);

    for i = (Nbc+1):Nc % target channels, skip background channel
        nR = size(obj.channels{i}.SmallScale.staticPathGains,2);
        out{i} = repmat(setDopplerStruct([nR 1]),1,3);
    end

end

function out = setDopplerStruct(dims)
    out = struct("PreviousSampleTime",0, ...
    "CumulativeDopplerPhase",zeros(dims));
end

function [H,t,theDopplerStruct] = timeVaryingCDLChannelISAC(ss,theTime,insize,outputProto,theDopplerStruct,U)

    persistent c0;
    if isempty(c0)
        c0 = physconst('LightSpeed');
    end

    % Define target unit vectors from Eqs. (7.9.4-11 & 7.9.4-12) (n.b. the
    % unit vectors for STX and SRX were already computed in
    % staticCDLChannelISAC and output as properties of ss)
    pathInd = find(ss.R(:));
    [nPrime,mPrime,n,m] = ind2sub(size(ss.R),pathInd);
    nPrime = nPrime - 1;
    mPrime = mPrime - 1;
    n = n - 1;
    m = m - 1;
    rxInd = sub2ind(size(ss.R,[1 2]),nPrime+1,mPrime+1);
    txInd = sub2ind(size(ss.R,[3 4]),n+1,m+1);

    phi_AOD = ss.targetAngles.anglesAoD(rxInd); % nR-by-1
    theta_ZOD = ss.targetAngles.anglesZoD(rxInd);
    phi_AOA = ss.targetAngles.anglesAoA(txInd);
    theta_ZOA = ss.targetAngles.anglesZoA(txInd);

    % unit vector of each path from ST to SRX, Eq. (7.9.4-11)
    rhat_st2rx = wireless.internal.channelmodels.getRhoHat(phi_AOD,theta_ZOD); % 3-by-nR

    % unit vector of each path from ST to STX, Eq. (7.9.4-12)
    rhat_st2tx = wireless.internal.channelmodels.getRhoHat(phi_AOA,theta_ZOA);

    % moving scatterer states and maximum scatterer speeds (alph & D)
    alph_tx2st = ss.alphTx(txInd); % nR-by-1
    alph_rx2st = ss.alphRx(rxInd);
    D_tx2st = ss.DTx(txInd);
    D_rx2st = ss.DRx(rxInd);

    % Add fields required for determining the largest possible
    % value of the Doppler frequency component f_D in Eq.
    % (7.9.5-14), used to determine the sample rate of channel
    % coefficient generation in the time-varying aspect of Step 14
    ss.totalMaximumDopplerShift = ss.maximumDopplerShiftTx + ss.maximumDopplerShiftRx + ss.maximumDopplerShiftST;

    % define model structure to get CDL sample times from ss
    model = struct(SampleDensity=ss.SampleDensity, ...
        SampleRate=ss.SampleRate, ...
        CarrierFrequency=ss.CarrierFrequency, ...
        MaximumDopplerShift=ss.totalMaximumDopplerShift, ...
        MaximumScattererSpeed=ss.MaximumScattererSpeed);

    t = wireless.internal.channelmodels.getCDLSampleTimes(model,insize,outputProto,theTime); % sample times

    Ncs = numel(t); % number of time-domain channel samples
    S = insize(2);  % number of input signals
    
    staticPathGains = cast(ss.staticPathGains,"like",outputProto);
    nR = size(staticPathGains,2);

    %----------------------------------------------------------------------
    % Get time-varying (Doppler) term of path gains according to Step 14
    % Eq. (7.9.4-5)
 
    % Obtain the time varying component of Eq. (7.9.4-4), where the f_D
    % term is defined by Eq. (7.9.4-15) rather than Eq. (7.9.4-5) to
    % support scatterer mobility.
 
    % Implementation note: the f_D term is split into three components
    % (Tx/Rx/ST-related terms) to call wireless.internal.channelmodels.getDopplerTerm. 
    % The MaximumDopplerShift property of the "model" input to this
    % function is used to control how the rhat unit vector input terms get
    % treated, i.e., to implement the above equation, one side is set to 0,
    % which effectively removes it from the equation. 

    % v_rx is the velocity of SRX, 'mdsRx' consists of the maximum Doppler
    % shift of the SRX and a zero for the maximum Doppler shift of the ST
    % (because the target Doppler is handled in 3) below)
    mdsRx = [ss.maximumDopplerShiftRx 0];
    
    % v_tx is the velocity of STX, 'mdsTx' consists of a zero for the
    % maximum Doppler shift of the ST (because the target Doppler is
    % handled in 3) below) and the maximum Doppler shift of the STX
    mdsTx = [0 ss.maximumDopplerShiftTx];

    % 1) Rx component setup
    model1 = struct(CarrierFrequency=ss.CarrierFrequency, ...
                    MaximumDopplerShift=mdsRx, ...
                    UTDirectionOfTravel=ss.UTDirectionOfTravel);

    % 2) Tx component setup
    model2 = struct(CarrierFrequency=ss.CarrierFrequency, ...
                    MaximumDopplerShift=mdsTx, ...
                    UTDirectionOfTravel=ss.UTDirectionOfTravel);

    % Calculate the STX and SRX components with the internal Doppler
    % helper (both are identically 1 for a static monostatic BS, but the
    % general bistatic/mobile cases are preserved)
    [dopplerTerm1,theDopplerStruct(1)] = getDopplerTerm(model1,ss.rhat_rx2st,           [],alph_rx2st,D_rx2st,t,theDopplerStruct(1));
    [dopplerTerm2,theDopplerStruct(2)] = getDopplerTerm(model2,           [],ss.rhat_tx2st,alph_tx2st,D_tx2st,t,theDopplerStruct(2));

    % 3) Target component, computed EXPLICITLY per TR 38.901 Rel-19
    % Eq. (7.9.5-14): the Doppler frequency of ray (n',m',n,m) due to the
    % sensing-target motion is
    %
    %     f_D = ( rhat_st2rx + rhat_st2tx ).' * v_bar_ST / lambda
    %
    % i.e. BOTH the ST->SRX and the ST->STX branch contribute. For the
    % monostatic LOS ray the two unit vectors coincide, giving the
    % round-trip Doppler f_D = 2*(rhat.'*v_bar_ST)/lambda.
    %
    % FIX: this explicit form replaces the previous dual-branch call into
    % wireless.internal.channelmodels.getDopplerTerm
    % (model3 with MaximumDopplerShift = [|v|/lambda |v|/lambda] and
    % rhat_st2rx / rhat_st2tx passed simultaneously), which was measured
    % at runtime (phase-slope of the emitted target path gains, see
    % diag_channel_doppler.m) to emit only the ONE-WAY Doppler
    % rhat.'*v_bar/lambda for the target term, halving every estimated
    % radial velocity in the monostatic sensing chain. If the internal
    % helper already implements Eq. (7.9.5-14) exactly, this explicit
    % computation produces numerically identical path gains, so the
    % replacement is safe in either case.
    %
    % Phase continuity across calls is preserved through
    % theDopplerStruct(3), using the same contract as the internal helper
    % (per-ray CumulativeDopplerPhase, scalar PreviousSampleTime), so
    % mobility updates that refresh the ray angles do not introduce phase
    % discontinuities.
    %
    % Sign convention: the slow-time factor is exp(+1i*2*pi*f_D*t) with
    % the unit vectors pointing FROM the target TOWARDS the BS, matching
    % the convention of the two internal calls above (verified end to end
    % against the sensing chain: an approaching target, v_r < 0, yields
    % f_D > 0 and maps to a negative estimated radial velocity through
    % v_r = -f_D*lambda/2).
    %
    % Note on coefficient sampling: the channel gain sample times t are
    % derived from ss.totalMaximumDopplerShift with SampleDensity = 64 by
    % default, which comfortably exceeds Nyquist for the round-trip
    % target Doppler magnitude (bounded by the SUM of the two entries of
    % ss.maximumDopplerShiftST already included in the total).
    lambdaST = c0 / ss.CarrierFrequency;
    fD3 = ((rhat_st2rx + rhat_st2tx).' * ss.vST(:)) / lambdaST;    % nR-by-1
    tRow = t(:).';                                                 % 1-by-Ncs
    tPrev = theDopplerStruct(3).PreviousSampleTime;
    phi0  = theDopplerStruct(3).CumulativeDopplerPhase;            % nR-by-1
    phase3 = phi0 + (2*pi)*fD3.*(tRow - tPrev);                    % nR-by-Ncs
    dopplerTerm3 = exp(1i*phase3).';                               % Ncs-by-nR
    theDopplerStruct(3).CumulativeDopplerPhase = phi0 + (2*pi)*fD3*(tRow(end) - tPrev);
    theDopplerStruct(3).PreviousSampleTime = tRow(end);

    % Combined Doppler Term 
    dopplerTerm = dopplerTerm1.*dopplerTerm2.*dopplerTerm3; % Ncs-by-nR
   
    %----------------------------------------------------------------------
    % Apply time-varying component to static path gains 
    H = zeros([Ncs nR S U],'like',complex(outputProto));
    for s = 1:S % for each transmit antenna
        for u = 1:U % for each receive antenna
            H(:,:,s,u) = dopplerTerm .* staticPathGains(:,:,s,u);
        end
    end
    
end

function [dopplerTerm,dopplerStruct] = getDopplerTerm(model,rhat_rx,rhat_tx,alph,D,t,dopplerStruct)

    if (isempty(rhat_rx))
        rhat_rx = zeros(size(rhat_tx));
    end
    if (isempty(rhat_tx))
        rhat_tx = zeros(size(rhat_rx));
    end
    if (isempty(alph))
        nR = size(rhat_rx,2);
        alph = zeros([1 nR]);
        D = zeros([1 nR]);
    end
    [dopplerTerm,dopplerStruct] = wireless.internal.channelmodels.getDopplerTerm(model,rhat_rx,rhat_tx,alph,D,t,dopplerStruct);

end

function [ss,txInd,rxInd] = staticCDLChannelISAC(ss,R,S,U)
    % ss: small scale channel structure being updated 
    % R:  Matrix representing the set of paths 
    % S:  number of transmit antennas
    % U:  number of receive antennas 

    %----------------------------------------------------------------------
    % prepare the dimensionality info for the loops and getting data 

    % (4-D) 1-based index corresponding to "a 0-based array" with (n',m',n,m) subscripts
    pathInd = find(R(:));

    % create the 0-based subscripts
    [nPrime,mPrime,n,m] = ind2sub(size(R),pathInd);
    nPrime = nPrime - 1;
    mPrime = mPrime - 1;
    n = n - 1;
    m = m - 1;

    % (2-D) 1-based index corresponding to "a 0-based array" with (n',m') subscripts
    rxInd = sub2ind(size(R,[1 2]),nPrime+1,mPrime+1);

    % (2-D) 1-based index corresponding to "a 0-based array" with (n,m) subscripts
    txInd = sub2ind(size(R,[3 4]),n+1,m+1);

    %----------------------------------------------------------------------
    % prepare the terms indexed into across all transmit and receive antennas
    paths = struct();

    paths.phi_AOD = ss.anglesAoD(txInd); % nR by 1
    paths.theta_ZOD = ss.anglesZoD(txInd);
    paths.phi_AOA = ss.anglesAoA(rxInd);
    paths.theta_ZOA = ss.anglesZoA(rxInd);

    % power term 
    paths.P = ss.pathPowers(pathInd); 

    % XPRs 
    paths.kappaTx = ss.kappaTx(txInd);
    paths.kappaRx = ss.kappaRx(rxInd);
    paths.kappa = ss.kappa(pathInd);

    % initial phases 
    paths.PhiTx = ss.PhiTx(txInd + (0:3)*prod(size(R,[3 4])));
    paths.PhiRx = ss.PhiRx(rxInd + (0:3)*prod(size(R,[1 2])));
    paths.Phi = ss.Phi(pathInd + (0:3)*prod(size(R,[1 2 3 4]))); % Phi matrix is an nR-by-4

    %----------------------------------------------------------------------
    % generate the static path gains and unit vectors 
    [ss.staticPathGains,ss.rhat_rx2st,ss.rhat_tx2st] = generatePathGainsISAC(ss,paths,S,U);

end

function [Hstatic,rhat_rx2st,rhat_tx2st] = generatePathGainsISAC(ss,paths,S,U)
% Generate the static component of the path gains in Section 7.9.4 Step 14.
% This does not include the Doppler component, which is added to the
% channel coefficients in timeVaryingCDLChannelISAC. This function
% determines the static channel. This function also returns the SRX-ST and
% STX-ST spherical unit vectors

    persistent c0;
    if isempty(c0)
        c0 = physconst('LightSpeed');
    end

    lambda_0 = c0 / ss.CarrierFrequency;  % carrier wavelength, m
    model = nr5g.internal.nrCDLChannel.makeCDLChannelAntennaArrayStructure(ss.txarray,ss.rxarray,ss.txorientation,ss.rxorientation,ss.CarrierFrequency);
    nR = numel(paths.P);
    Hstatic = zeros([1 nR S U],"like",1i);

    % get field terms, location terms, and spherical unit vectors

    % 'rhat_rx2st' is per Eq. (7.9.4.-9)
    [receiveFieldTerm,receiveLocationTerm,rhat_rx2st] = getfieldAndLocationHterms(model.ReceiveAntennaArray,paths.phi_AOA,paths.theta_ZOA,lambda_0,nR,U,ss.CarrierFrequency);
    % 'rhat_tx2st' is per Eq. (7.9.4-10)
    [transmitFieldTerm,transmitLocationTerm,rhat_tx2st] = getfieldAndLocationHterms(model.TransmitAntennaArray,paths.phi_AOD,paths.theta_ZOD,lambda_0,nR,S,ss.CarrierFrequency);
    
    % get polarization term (i.e. the product of the three CPMs divided by
    % their main diagonal component terms), size 4-by-nR
    polarizationTerm = getPolarizationMatrix(paths);
   
    % for each transmit antenna:
    for s = 1:S

        % for each receive antenna:
        for u = 1:U

            % calculate the term of the coefficients combining the transmit
            % and receive antenna fields and the polarization term;
            % output is of size nR-by-1

            % 2 by 2 matrix multiplication: 
            fieldTerms = ((receiveFieldTerm(1,:,u).*polarizationTerm(1,:) + receiveFieldTerm(2,:,u).*polarizationTerm(2,:)) .* transmitFieldTerm(1,:,s) + ...
                          (receiveFieldTerm(1,:,u).*polarizationTerm(3,:) + receiveFieldTerm(2,:,u).*polarizationTerm(4,:)) .* transmitFieldTerm(2,:,s)).';

            % combine the field terms with the location terms for the
            % current transmit and receive antenna; output is of size
            % nR-by-1. This does not account for Doppler shifts, added
            % in timeVaryingCDLChannelISAC.
            if (ss.FastFading)
                allTerms = fieldTerms .* receiveLocationTerm(:,u) .* transmitLocationTerm(:,s);
            else
                % Table 7.9.6.2-1 "Coupling loss for target channel" does
                % not include location terms
                allTerms = fieldTerms;
            end

            % define channel coefficient (without power terms applied yet)
            Hstatic(1,:,s,u) = allTerms;

        end
    end

    % apply power term to Hstatic
    Hstatic = Hstatic .* sqrt(paths.P).';

end

function [fieldTerm,locationTerm,rhat] = getfieldAndLocationHterms(antennaArray,phi,theta,lambda_0,nR,numAnts,fc)
% obtain the rx/tx field and location terms for H in Eq. (7.9.4-4) and
% corresponding spherical unit vector 

    rhat = wireless.internal.channelmodels.getRhoHat(phi,theta);

    if ~isempty(antennaArray.SubarrayPositions) % Partitioned/Replicated subarrays
        radiatorPositions = antennaArray.SubarrayPositions;
    else
        radiatorPositions = antennaArray.ElementPositions;
    end
    dbar = reshape(radiatorPositions,3,[]) * lambda_0 + antennaArray.Position; % size 3-by-numAnts
    
    fieldTerm = zeros([2 nR numAnts],"like",1i); % F_tx / F_rx
    locationTerm = zeros([nR numAnts],"like",1i);
    for n = 1:numAnts % for each antenna
        % get field term
        fieldTerm(:,:,n) = wireless.internal.channelmodels.getFieldTerm(antennaArray,theta,phi,n);
        
        % get location term
        locationTerm(:,n) = getLocationTerm(rhat,dbar,n,fc);
    end

end

% Equation 7.5-22/7.5-28/7.5-29, exponential term which is a function of
% the spherical unit vector 'rhat' for arrival (receive) or departure
% (transmit) azimuth and zenith angles and the location of the receive or
% transmit antenna element 'dbar'
function locationTerm_ant = getLocationTerm(rhat,dbar,ant,freq)

    persistent c0;
    if isempty(c0)
        c0 = physconst('LightSpeed');
    end
    
    % reshape rhat to combine cluster and ray dimensions into a single row
    rhat = reshape(rhat,[3 numel(rhat)/3]);
    
    lambda_0 = c0 / freq;  % carrier wavelength, m
    locationTerm_ant = exp(1i*2*pi*rhat.'*dbar(:,ant)/lambda_0);

end

% Section 7.9.4 Step 14
% combined product polarization matrix term in Equation (7.9.4-4)
function polarizationMatrix = getPolarizationMatrix(paths) % was XPR, Phi

    % Get the cross polarization matrix term in Eq. (7.9.4-4) that is the
    % product of the three CPMs divided by a term derived from the main
    % diagonal of that product.

    % XPRs 
    kappaTx = paths.kappaTx;
    kappaRx = paths.kappaRx;
    kappa = paths.kappa; % (nR-by-1)

    % initial phases 
    PhiTx = paths.PhiTx;
    PhiRx = paths.PhiRx;
    Phi = paths.Phi; % initial phases (nR-by-4)

    % polarization term will be a 4-by-nR matrix out of here to apply in
    % the main S/U loops with the other H terms. 
    kappaTx = kappaTx.'; % 1-by-nR
    kappaRx = kappaRx.'; 
    kappa = kappa.'; 
    PhiTx = PhiTx.'; % 4-by-nR
    PhiRx = PhiRx.'; 
    Phi = Phi.'; 

    % CPM of ST (Section 7.9.2.2 & Eq. (7.9.4-6) / (7.9.2-5))
    % getTargetParametersXPRs() in Step 12 handles 7.9.2.2 target-wise
    % amplitude factors - i.e. these are incorporated into XPRs already
    CPM_st = cpmConstructor(kappa,Phi);

    % CPM STX-ST (Eq. 7.9.4-7)
    CPM_tx = cpmConstructor(kappaTx,PhiTx);

    % CPM ST-SRX (Eq. 7.9.4-8)
    CPM_rx = cpmConstructor(kappaRx,PhiRx);

    % get polarization matrix term
    combinedMatrix = matrixMultiplier(matrixMultiplier(CPM_rx,CPM_st),CPM_tx);

    % the **two** elements in the main diagonal of the combined matrix
    d_theta_theta = combinedMatrix(1,:);
    d_phi_phi = combinedMatrix(4,:);

    diagonalTerm = sqrt((abs(d_theta_theta).^2 + abs(d_phi_phi).^2)/2);
    polarizationMatrix = combinedMatrix./diagonalTerm; % 4-by-nR

end

function CPM = cpmConstructor(kappa,Phi)
    % Create CPMs for Eq. (7.9.4-4)
    CPM = [ones(size(kappa)); sqrt(1./kappa); sqrt(1./kappa); ones(size(kappa))] .* exp(1i*Phi([1;3;2;4],:));

end

function matrix = matrixMultiplier(a,b)
% "2-by-2 matrix multiplication" but let's put output in a row vector
% instead of matrix. N.B. that when you do this, the 2nd term and 3rd
% terms are swapped, because it's read row-wise. 

    matrix = [a(1,:).*b(1,:) + a(3,:).*b(2,:); 
              a(2,:).*b(1,:) + a(4,:).*b(2,:);
              a(1,:).*b(3,:) + a(3,:).*b(4,:);
              a(2,:).*b(3,:) + a(4,:).*b(4,:)];

end

function chdata = angleRayCoupling(chcfg,chdata)

    % Initialize coupling array
    coupling = chdata.rayCoupling;

    % Ray coupling for clusters with sub-clustering should only couple
    % rays within the same sub-cluster
    [N,M] = size(coupling,[1 2]);
    NSC = min(N,2);
    model = struct(RayCoupling=coupling(1:NSC,:,:));
    sc = NSC*3;
    clusterTypes = repmat("SubclusteredNLOS",1,sc);
    c = wireless.internal.channelmodels.getCDLRayCoupling(model,[],clusterTypes);
    c = ((c - repmat((1:sc).',[1 M 3])) / sc) + 1;
    coupling(1:NSC,:,:) = c(1:3:end,:,:);

    % Adjust coupling indices to refer to the correct elements of the angle
    % matrices which they will index (the input 'rayCoupling' has indices
    % 1...M in each row and each 3rd dimension element, the indices in the
    % rows need updated to address different clusters)
    coupling = (coupling-1)*N + repmat((1:N).',[1 M 3]);

    % In the case of a reciprocal link, swap arrival and departure angles
    if (chcfg.swapTransmitAndReceive)
        chdata = swapAngles(chdata);
    end

    % perform coupling of rays (step 8)
    % * AoD remains in the original order
    % * AoA rearranged w.r.t. AoD by page 1
    % * ZoD rearranged w.r.t. AoD by page 3
    % * ZoA rearranged w.r.t. ZoD by page 2. Therefore, ZoA is rearranged 
    %   w.r.t. AoD firstly by page 2 and then by page 3
    %
    %           1
    %        .-----> AoA
    %       /
    %     AoD
    %       \   3          2
    %        '-----> ZoD -----> ZoA
    %
    % AoD to AoA coupling
    chdata.anglesAoA = chdata.anglesAoA(coupling(:,:,1));
    % AoD to ZoD coupling
    chdata.anglesZoD = chdata.anglesZoD(coupling(:,:,3));
    % ZoD to ZoA coupling
    chdata.anglesZoA = chdata.anglesZoA(coupling(:,:,2));
    % rearrange ZoA in AoD order
    chdata.anglesZoA = chdata.anglesZoA(coupling(:,:,3));

    % In the case of a reciprocal link, swap angles back
    if (chcfg.swapTransmitAndReceive)
        chdata = swapAngles(chdata);
    end

end

function chdata = swapAngles(chdata)

    anglesAoA = chdata.anglesAoA;
    chdata.anglesAoA = chdata.anglesAoD;
    chdata.anglesAoD = anglesAoA;

    anglesZoA = chdata.anglesZoA;
    chdata.anglesZoA = chdata.anglesZoD;
    chdata.anglesZoD = anglesZoA;

end

function [upd,ic] = makeUniquePathDelays(obj,pd)

    fracdelay = round(pd * obj.SampleRate / (2 * obj.maxFractionalDelayError));
    [~,ia,ic] = unique(fracdelay,"stable");
    upd = pd(ia);

end

function pathGains = applyPhaseLOS_d_3D(obj,ch,pathGains)

    ch2.CenterFrequency = ch.tx2stcfg.CenterFrequency;
    ch2.ChannelConfiguration.BSPosition = [0 0 0];
    d_3D = vecnorm(ch.tx2stcfg.UEPosition - ch.tx2stcfg.BSPosition) + vecnorm(ch.st2rxcfg.BSPosition - ch.st2rxcfg.UEPosition);
    ch2.ChannelConfiguration.UEPosition = [d_3D 0 0];
    % LOS STX-SPST link is always coupled with LOS SPST-SRX links, so LOS
    % is always true here
    LOS = true;
    pathGains = obj.nr5g.applyPhaseLOS_d_3D(ch2,pathGains,LOS);

end

function pgout = combineSameDelayPathGains(pdm,pgin)

    [Nsc,~,S,U] = size(pgin);
    Np = max(pdm);
    pgout = zeros([Nsc Np S U],"like",pgin);
    for p = 1:Np
        pgout(:,p,:,:) = sum(pgin(:,pdm==p,:,:),2);
    end

end

function azel = azimuthElevation(v_bar)

    v = norm(v_bar);
    if (v~=0)
        v_bar = v_bar / v;
    end
    phi = azimuthAngle(v_bar);
    theta = zenithAngle(v_bar);

    azel = [phi; theta];

end

function theta = zenithAngle(rho_hat)

    theta = real(acosd(rho_hat(3)));

end

function phi = azimuthAngle(rho_hat)

    theta = zenithAngle(rho_hat);
    phi = atan2d(rho_hat(2),rho_hat(1));
    phi(theta==0) = 0; % Set ambiguous phi to 0

end

function pathGains = noFastFadingPathGainsISAC(ch,outputProto)

    % Table 7.9.6.2-1 "Coupling loss for target channel". Note that terms
    % of Step 14 not required for coupling loss will already have been
    % skipped when FastFading = false in staticCDLChannelISAC()
    ss = ch.SmallScale;
    pathGains = cast(ss.staticPathGains,"like",outputProto);

end

function n = getNumBackgroundChannels(mode)

    if contains(mode,"Monostatic")
        n = 3; % monostatic sensing modes have 3 background channels 
    else
        n = 1; % bistatic sensing modes have 1 background channel
    end

end