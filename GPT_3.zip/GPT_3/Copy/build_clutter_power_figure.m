function build_clutter_power_figure(seed,rangeLabel,K,E,resultDir)
%BUILD_CLUTTER_POWER_FIGURE Clutter power versus range bin and Doppler bin.
%   Minimal two-panel figure, one curve per panel, no titles or annotations.
%
%     left  : max over Doppler of the clutter map, per range bin
%     right : max over range of the clutter map, per Doppler bin
%
%   Both reductions run over the CUT support, the cells the detector tests.
%   The background map is common to every run at one seed, so the choice of
%   run only fixes which (K,E) support the range axis covers.
%
%   build_clutter_power_figure(41,750,64,28,'results/Data')

if nargin<1 || isempty(seed), seed=41; end
if nargin<2 || isempty(rangeLabel), rangeLabel=750; end
if nargin<3 || isempty(K), K=64; end
if nargin<4 || isempty(E), E=28; end
if nargin<5 || isempty(resultDir), resultDir='results/Data'; end

f=helperResolveResultFile(resultDir,rangeLabel,seed,K,E);
o=load(f).output;
C=o.Results.ClutterPowerMap;
cut=o.SpatialCutIdxNative(:).';
dB=@(x)10*log10(max(x,realmin));

pRange=dB(max(C(cut,:),[],2)).';
pDop=dB(max(C(cut,:),[],1));

fh=figure('Color','w','Position',[80 80 1200 440]);
tl=tiledlayout(fh,1,2,'TileSpacing','compact','Padding','compact');

ax=nexttile(tl);
plot(ax,cut,pRange,'-','LineWidth',1.4,'Color',[0.10 0.45 0.95]);
grid(ax,'on'); xlim(ax,[cut(1) cut(end)]);
xlabel(ax,'Range bin'); ylabel(ax,'Clutter power (dB)');

% The grid is (-N/2:N/2-1)*df = -1000 ... +975 Hz, so it has no +1000 Hz
% point: -1000 Hz is the Nyquist bin and is the same frequency as +1000 Hz.
% The axis is drawn symmetric about 0 Hz; the curve simply ends at +975 Hz.
fHz=o.DopplerGridHz(:).';
fMax=max(abs(fHz));
ax=nexttile(tl);
plot(ax,fHz,pDop,'-','LineWidth',1.4,'Color',[0.10 0.45 0.95]);
grid(ax,'on'); xlim(ax,[-fMax fMax]); xticks(ax,-fMax:200:fMax);
xlabel(ax,'Doppler (Hz)'); ylabel(ax,'Clutter power (dB)');

figDir=fullfile('results',sprintf('figures_clutterpower_seed%d_%s',seed, ...
    datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
b=fullfile(figDir,sprintf('figClutterPower_R%d_K%d_E%d',rangeLabel,K,E));
exportgraphics(fh,[b '.png'],'Resolution',150); savefig(fh,[b '.fig']);
fprintf('saved %s\n',b);
end
