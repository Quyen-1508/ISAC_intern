function build_tradeoff_figures(seed,rangesM,Kwant,Ewant)
%BUILD_TRADEOFF_FIGURES Study figures from saved per-range results.
%   Reads the per-range MAT-files the benchmark already wrote and renders the
%   three study figures. Nothing is recomputed. This exists because a range run
%   on its own, by calling the benchmark directly rather than through
%   run_two_ranges, saves its result but produces no figures, and because the
%   trade-off figure is only drawn once both ranges exist.
%
%   1. Pd versus target power at 250 m, one curve per method.
%   2. Pd versus target power at 750 m, one curve per method.
%   3. Complexity/performance trade-off at 250 m: measured detector runtime per
%      map against PdAssociated at the nominal 0 dB operating point.

if nargin<1 || isempty(seed), seed=41; end
if nargin<2 || isempty(rangesM), rangesM=[250 750]; end
% Kwant/Ewant pick one (K,E) run when several are saved for a range; leave
% them empty when only one exists. helperResolveResultFile refuses to guess.
if nargin<3, Kwant=[]; end
if nargin<4, Ewant=[]; end
resultDir='results';

out=cell(1,numel(rangesM));
for k=1:numel(rangesM)
    f=helperResolveResultFile(resultDir,rangesM(k),seed,Kwant,Ewant);
    S=load(f);
    assert(isfield(S,'output'),'Case2:figuresBadResult','%s has no ''output''.',f);
    out{k}=S.output;
    fprintf('Loaded %s\n',f);
end

methodNames=string({out{1}.Results.Method.Name});
off=out{1}.Results.TargetPowerOffsetDB;
for k=2:numel(out)
    assert(isequal(out{k}.Results.TargetPowerOffsetDB,off), ...
        'Case2:figuresPowerGrid','Ranges use different target-power grids.');
    assert(isequal(string({out{k}.Results.Method.Name}),methodNames), ...
        'Case2:figuresMethodSet','Ranges use different method sets.');
    assert(isequal(out{k}.SpatialCutIdxNative,out{1}.SpatialCutIdxNative), ...
        'Case2:figuresCutSupport', ...
        ['Ranges use different CUT support, so their results are not a paired ' ...
         'comparison and must not be drawn on one study figure.']);
end

close all;
styles={'--o','-s','-^','-d'};

for k=1:numel(rangesM)
    figure('Name',sprintf('Pd vs target power - %d m',rangesM(k)),'NumberTitle','off');
    hold on; grid on;
    for m=1:numel(methodNames)
        plot(off,out{k}.Results.Method(m).PdPowerSweep, ...
            styles{min(m,numel(styles))},'LineWidth',1.4,'MarkerSize',6);
    end
    xlabel('Target power offset (dB)'); ylabel('P_d associated');
    ylim([0 1]); xticks(off); legend(methodNames,'Location','best');
    title(sprintf('%d m, channel seed %d, P_{FA,map} target %.2f', ...
        rangesM(k),out{k}.ChannelSeed,out{k}.MapPfaTarget));
end

idx250=find(rangesM==250,1);
assert(~isempty(idx250),'Case2:figuresNo250','The trade-off figure needs the 250 m result.');
c=out{idx250}.Results.Complexity;
x=zeros(1,numel(methodNames)); y=zeros(size(x));
for m=1:numel(methodNames)
    x(m)=c.Method(m).SecondsPerMap;
    y(m)=out{idx250}.Results.Method(m).PdAssociated;
end
figure('Name','Detector runtime vs Pd - 250 m','NumberTitle','off');
plot(x,y,'-o','LineWidth',1.4,'MarkerSize',7); grid on; hold on;
for m=1:numel(methodNames)
    text(x(m),y(m),sprintf('  %s',char(methodNames(m))), ...
        'VerticalAlignment','bottom','Interpreter','none');
end
xlabel('Detector runtime per map (s)'); ylabel('P_d associated at 0 dB');
ylim([0 1]); xlim([0 max(x)*1.25]);
title(sprintf('Complexity-performance trade-off at 250 m, seed %d', ...
    out{idx250}.ChannelSeed));

figDir=fullfile(resultDir,sprintf('figures_study_seed%d_%s',out{1}.ChannelSeed, ...
    datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
fh=findall(groot,'Type','figure'); [~,ord]=sort([fh.Number]); fh=fh(ord);
for i=1:numel(fh)
    b=fullfile(figDir,sprintf('fig%02d_%s',fh(i).Number, ...
        matlab.lang.makeValidName(strtrim(fh(i).Name))));
    exportgraphics(fh(i),[b '.png'],'Resolution',150);
    savefig(fh(i),[b '.fig']);
    fprintf('  saved %s\n',b);
end
fprintf('Saved %d figure(s) to %s\n',numel(fh),figDir);
end
