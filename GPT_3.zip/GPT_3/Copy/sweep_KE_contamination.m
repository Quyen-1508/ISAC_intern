function T = sweep_KE_contamination(cubeFile,outFile)
%SWEEP_KE_CONTAMINATION Training-contamination, covariance and cost sweep over (B,K,E).
%   Drives the production detectors and the production contamination
%   diagnostic over a (B,K,E) grid from post-Doppler cubes exported by
%   Detection_Case2_SpatialACE_Benchmark (validationOverride.dumpCubesTo).
%   No Monte Carlo is run here, so Pd, Pfa and RMSE are NOT produced; every
%   quantity below is either deterministic geometry, a single deterministic
%   covariance comparison, or a timing measurement.
%
%   THE BLIND EDGE IS TAKEN FROM EACH (B,K,E)'s OWN NATIVE SUPPORT, not from
%   the common support the benchmark uses. Reading the executable asserts:
%   helperFullSlidingNSCMACE requires cutIdx-E-K/2 >= 1 and cutIdx+E+K/2 <=
%   nRange; helperBlockSharedNSCMACE binds only on the first block (lo =
%   cutIdx(1)) and the last block (hi = cutIdx(end)) and imposes the same two
%   inequalities. The native support is therefore [1+E+K/2, nRange-E-K/2] for
%   every B, and B drops out. The benchmark's extra (maxB-1) term is margin
%   for a support shared between methods, not a requirement of any detector.
%
%   Timing uses that same native support so the three B values are measured
%   on an identical CUT set at each (K,E).

if nargin<1 || isempty(cubeFile), error('A cube file is required.'); end
if nargin<2, outFile=''; end

S=load(cubeFile);
ZB=S.ZB; ZT=S.ZT; steering=S.steering; truthQ=S.truthQ;
truthBin=S.dumpTruthNativeIdx; rangeGrid=S.rangeGridNative(:).';
[nRange,~,nChain]=size(ZB);
dr=median(diff(rangeGrid));
rangeOf=@(b)(b-1)*dr;

Ks=[32 48 64 96];
Es=[6 12 18 24 28 32];
Bs=[1 4 8];
gains=[0 6 12];
Zc=ZB+ZT;                       % composite cube used only for timing

fprintf('cube %d range x %d chain | truth native bin %d (%.2f m) | truthQ %d\n', ...
    nRange,nChain,truthBin,rangeOf(truthBin),truthQ);
fprintf('steering hypotheses: %d\n',size(steering,2));

rows=cell(0,1);
for K=Ks
    for E=Es
        half=E+K/2;
        lo=1+half; hi=nRange-half;
        supportEmpty = hi<lo;
        cutIdx = lo:hi;
        truthInside = ~supportEmpty && truthBin>=lo && truthBin<=hi;

        % ---- contamination and covariance, a function of (K,E) only -------
        diagOK=false; diagErr=''; D=[];
        lamB=NaN; lamBT=NaN;
        if truthInside
            cfg=struct('NumTrainingCells',K,'ExclusionBins',E, ...
                'TargetGainDB',gains,'RangeGateBins',-1:1,'DopplerGateBins',-1:1);
            try
                D=helperTrainingContaminationDiagnostics(ZB,ZT,truthBin,truthQ,steering,cfg);
                diagOK=true;
                [lamB,lamBT]=localLoadingFactors_(ZB,ZT,truthBin,truthQ,K,E,nChain);
            catch ME
                diagErr=ME.identifier;
            end
        else
            diagErr='truth outside its own native support';
        end

        for B=Bs
            r=struct();
            r.B=B; r.K=K; r.E=E;
            r.NativeCutLo=lo; r.NativeCutHi=hi;
            r.NumCUT=max(0,hi-lo+1);
            r.BlindNearM=rangeOf(lo);                 % 0 .. this, blind
            r.BlindFarM=rangeOf(hi);                  % this .. end, blind
            r.BlindTotalM=rangeOf(lo)+(rangeOf(nRange)-rangeOf(hi));
            r.TruthInsideOwnSupport=truthInside;
            r.SecondsPerMap=NaN; r.NumCovPerMap=NaN; r.CovReuseFactor=NaN;
            r.RuntimeNote='';
            if supportEmpty
                r.RuntimeNote='empty support';
            else
                try
                    if B==1
                        cfgD=struct('NumTrainingCells',K,'ExclusionBins',E);
                        t0=tic; [~,info]=helperFullSlidingNSCMACE(Zc,cutIdx,steering,cfgD);
                        r.SecondsPerMap=toc(t0);
                    else
                        cfgD=struct('BlockSizeRangeBins',B,'NumTrainingCells',K,'ExclusionBins',E);
                        t0=tic; [~,info]=helperBlockSharedNSCMACE(Zc,cutIdx,steering,cfgD);
                        r.SecondsPerMap=toc(t0);
                    end
                    r.NumCovPerMap=info.NumCovarianceEstimatesPerMap;
                    r.CovReuseFactor=info.CovarianceReuseFactor;
                catch ME
                    r.RuntimeNote=ME.identifier;
                end
            end

            r.DiagnosticOK=diagOK; r.DiagnosticNote=diagErr;
            r.LoadingLambdaBackground=lamB;
            r.LoadingLambdaContaminated=lamBT;
            for ig=1:numel(gains)
                sfx=sprintf('G%d',gains(ig));
                if diagOK
                    e=D.Entry(1,ig);
                    r.(['RACE_' sfx])=e.ACEContaminatedToBackgroundRatio;
                    r.(['ACEChangeDB_' sfx])=e.ACEChangeDB;
                    r.(['SINRLossDB_' sfx])=e.AdaptiveSINRLossAtBackgroundBestAngleDB;
                    r.(['MaxSINRLossDB_' sfx])=e.MaxAdaptiveSINRLossDB;
                    r.(['CM_' sfx])=e.RelativeFrobeniusPerturbation;
                    r.(['CInv_' sfx])=e.RelativeInversePerturbation;
                    r.(['CondB_' sfx])=e.ConditionNumberBackground;
                    r.(['CondBT_' sfx])=e.ConditionNumberContaminated;
                    r.(['TgtToBgDB_' sfx])=e.TrainingTargetToBackgroundDB;
                else
                    r.(['RACE_' sfx])=NaN; r.(['ACEChangeDB_' sfx])=NaN;
                    r.(['SINRLossDB_' sfx])=NaN; r.(['MaxSINRLossDB_' sfx])=NaN;
                    r.(['CM_' sfx])=NaN; r.(['CInv_' sfx])=NaN;
                    r.(['CondB_' sfx])=NaN; r.(['CondBT_' sfx])=NaN;
                    r.(['TgtToBgDB_' sfx])=NaN;
                end
            end
            rows{end+1,1}=r; %#ok<AGROW>
        end
        fprintf('  K=%-3d E=%-3d nCUT=%-4d diag=%-5s %s\n',K,E,max(0,hi-lo+1), ...
            string(diagOK),diagErr);
    end
end

T=struct2table([rows{:}]);
if ~isempty(outFile)
    save(outFile,'T','-v7.3');
    fprintf('saved %s\n',outFile);
end
end

% =========================================================================
function [lamB,lamBT] = localLoadingFactors_(ZB,ZT,cutNativeIdx,truthQ,K,E,nChain)
%localLoadingFactors_ Shrinkage weight actually applied, at g = 0 dB.
%   helperShrinkageLoading returns M + lambda*tau*I and does not report
%   lambda, so it is recomputed here from the same NSCM with the same formula
%   the helper uses. tau = trace(M)/N is 1 for an NSCM by construction.
halfK=K/2;
idx=[(cutNativeIdx-E-halfK):(cutNativeIdx-E-1), ...
     (cutNativeIdx+E+1):(cutNativeIdx+E+halfK)];
YB=reshape(ZB(idx,truthQ,:),K,nChain).';
YT=reshape(ZT(idx,truthQ,:),K,nChain).';
lamB=localLambda_(helperNSCM(YB),K);
lamBT=localLambda_(helperNSCM(YB+YT),K);
end

function lambda = localLambda_(M,K)
N=size(M,1);
tau=real(trace(M))/N;
denom=norm(M-tau*eye(N,'like',M),'fro')^2;
if denom>0, lambda=min((tau^2/K)/denom,1); else, lambda=0; end
end
