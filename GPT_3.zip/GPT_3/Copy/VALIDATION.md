# Validation procedure

## Prerequisite

Run the validation from the project environment that supplies the original
processing helpers used by the benchmark. At minimum these functions must be
on the MATLAB path:

```text
helperNSCM
helperShrinkageLoading
helperRangeCubeFromPRS
helperRangeDopplerPowerMap
```

The full channel replay also requires the original 5G/ISAC project helpers and
MathWorks products used by `Detection_Case2_SpatialACE_Benchmark.m`.

## Run the deterministic checks

From the delivered folder:

```matlab
addpath(genpath(pwd));
report = tests.run_validation();
```

Do not use a final printed message as the evidence of correctness. Read the
returned `report` table. Each row contains the measured numerical quantity,
its tolerance or target value, and the metric being checked.

The validation covers numerical invariance, range-Doppler processing,
association, Full/Block geometry, covariance-reuse counts, independent Full
reference calculation, threshold generalization, deterministic random streams
and the training-contamination diagnostic.

## Run the benchmark

After validation, run:

```matlab
Detection_Case2_SpatialACE_Benchmark
```

The saved result now contains these additional diagnostics:

```text
Results.SCNRTruthCellDB
Results.SCNRPeakCellDB
Results.SCNRGateDB
Results.FractionalRangeBinOffset
Results.TargetRangeGateCaptureFraction
Results.TrainingContaminationDiagnostics
```

For the contamination study, compare `E=6` and production `E=28` in
`TrainingContaminationDiagnostics.Entry`. In particular inspect:

```text
RelativeFrobeniusPerturbation
RelativeInversePerturbation
MaxAbsDirectionalPerturbation
ACEContaminatedToBackgroundRatio
ACEChangeDB
AdaptiveSINRLossAtBackgroundBestAngleDB
ConditionNumberBackground
ConditionNumberContaminated
```

`GeometryComparison` compares ACE after changing only the background training
geometry from E=6 to E=28, separately for `M_B` and `M_BT`. This is the direct
check that separates a background-locality effect from signal-in-training.
