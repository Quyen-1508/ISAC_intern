function [statMap, info] = helperFullSlidingNSCMACE(Z, cutIdx, steering, cfg)
%helperFullSlidingNSCMACE Full sliding NSCM-ACE with fixed symmetric exclusion.
%   Z is Nrange-by-Ndoppler-by-Nchain post-Doppler data, CUTIDX lists the
%   native range bins to test, STEERING is Nchain-by-Nangle and CFG carries
%   NumTrainingCells and ExclusionBins.
%
%   One covariance estimate is formed independently for every (CUT,Doppler)
%   pair. For a CUT at range bin c, ExclusionBins bins on each side are kept
%   out of the training data, then NumTrainingCells/2 samples are taken from
%   each side:
%
%       training | exclusion | CUT | exclusion | training
%
%   This is the B=1 reference for helperBlockSharedNSCMACE. With the same
%   NumTrainingCells and ExclusionBins, Block-1 must give the same ACE map
%   apart from floating-point roundoff. The primary study therefore changes
%   covariance reuse while keeping K and E fixed.

validateattributes(Z,{'single','double'},{'nonempty'});
assert(ndims(Z)==3,'Case2:fullSlidingDims','Z must be Nrange-by-Ndoppler-by-Nchain.');
validateattributes(cutIdx,{'numeric'},{'vector','integer','positive'});
assert(isfield(cfg,'NumTrainingCells') && isfield(cfg,'ExclusionBins'), ...
    'Case2:fullSlidingCfg','cfg needs NumTrainingCells and ExclusionBins.');

[nRange,nDop,nChain] = size(Z);
cutIdx = cutIdx(:);
nCut = numel(cutIdx);
assert(nCut>=1,'Case2:fullSlidingNoCut','At least one CUT is required.');

S = steering;
if isvector(S), S = S(:); end
assert(size(S,1)==nChain,'Case2:fullSlidingSteering', ...
    'Steering has %d rows; data have %d chains.',size(S,1),nChain);
for ia = 1:size(S,2)
    S(:,ia) = S(:,ia)/max(norm(S(:,ia)),realmin(class(real(S))));
end
nAng = size(S,2);

K = round(cfg.NumTrainingCells);
E = round(cfg.ExclusionBins);
% K > Nchain was a statistical rule of thumb, not an implementation
% requirement. helperNSCM normalises every snapshot to norm sqrt(N), so
% trace(M)=N and tau=1 for every K, and helperShrinkageLoading then adds
% lambda*tau*I with lambda>0. The loaded covariance is therefore positive
% definite at any K, which the Cholesky assert below still verifies. Small K
% costs conditioning, not validity, so it is reported through the condition
% number and loading diagnostics rather than forbidden here.
assert(mod(K,2)==0 && K>=2,'Case2:fullSlidingK', ...
    'Need an even K >= 2. K=%d.',K);
assert(E>=0 && isfinite(E),'Case2:fullSlidingExclusion', ...
    'ExclusionBins must be a finite nonnegative integer.');
assert(E==round(E),'Case2:fullSlidingExclusionInteger', ...
    'ExclusionBins must be an integer.');
halfK = K/2;
assert(all(cutIdx-E-halfK>=1) && all(cutIdx+E+halfK<=nRange), ...
    'Case2:fullSlidingSupport', ...
    ['A CUT cannot support the symmetric fixed-exclusion training window. ' ...
     'Restrict the common CUT support instead of shortening edge windows.']);

statMap = nan(nCut,nDop,nAng,'like',real(Z));
trainingIdx = cell(nCut,1);
nCov = 0;
for ic = 1:nCut
    c = cutIdx(ic);
    left = (c-E-halfK):(c-E-1);
    right = (c+E+1):(c+E+halfK);
    idx = [left right];
    assert(numel(idx)==K && numel(unique(idx))==K, ...
        'Case2:fullSlidingTrainingCount','Training set is not %d distinct cells.',K);
    assert(~any(idx>=c-E & idx<=c+E),'Case2:fullSlidingExclusionViolated', ...
        'A training cell falls inside the CUT exclusion zone.');
    trainingIdx{ic}=idx;
    for iq = 1:nDop
        Ytr = reshape(Z(idx,iq,:),K,nChain).';
        L = localFactor_(helperShrinkageLoading(helperNSCM(Ytr),K));
        nCov = nCov+1;
        y = reshape(Z(c,iq,:),nChain,1);
        statMap(ic,iq,:) = reshape(helperACEStatistic(y,S,L),1,1,[]);
    end
end

assert(all(isfinite(statMap(:))),'Case2:fullSlidingNonFinite', ...
    'The full sliding ACE map contains non-finite entries.');

info = struct();
info.Method = "Full sliding NSCM-ACE";
info.BlockSizeRangeBins = 1;
info.ExclusionBins = E;
info.NumTrainingCells = K;
info.NumBlocks = nCut;
info.NumCUT = nCut;
info.NumDoppler = nDop;
info.NumChains = nChain;
info.NumAngleHypotheses = nAng;
info.NumCovarianceEstimatesPerMap = nCov;
info.NumCholeskyFactorizationsPerMap = nCov;
info.CovarianceReuseFactor = 1;
info.TrainingIdxPerCUT = trainingIdx;
end

function L = localFactor_(M)
[L,p] = chol((M+M')/2,'lower');
assert(p==0,'Case2:fullSlidingNotPD', ...
    'Shrinkage-loaded covariance is not positive definite.');
end
