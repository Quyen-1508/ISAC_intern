function cv = helperCrossValidateMapThreshold(h0MapMax,targetPfaMap,numFolds,ciLevel)
%helperCrossValidateMapThreshold Out-of-sample map false-alarm rate.
%   H0MAPMAX holds one maximum detector statistic per target-free map. The maps
%   are split into NUMFOLDS contiguous folds. Each fold is held out in turn, the
%   threshold is calibrated on the remaining folds with helperCalibrateMapThreshold,
%   and the held-out maps are counted against it. Every map is therefore scored
%   exactly once by a threshold that never saw it.
%
%   This helper is a calibration-stability diagnostic. Production reporting
%   uses a separate H0 validation set after the final threshold is fitted to
%   all calibration maps. Cross-fitting remains useful for detecting unstable
%   threshold placement without consuming the independent validation set.

validateattributes(h0MapMax,{'single','double'},{'real','finite','vector','nonempty'});
validateattributes(targetPfaMap,{'numeric'},{'real','finite','scalar','>',0,'<',1});
validateattributes(numFolds,{'numeric'},{'real','finite','scalar','integer','>=',2});
if nargin<4 || isempty(ciLevel), ciLevel=0.95; end
validateattributes(ciLevel,{'numeric'},{'real','finite','scalar','>',0,'<',1});

v=double(h0MapMax(:));
n=numel(v);
assert(n>=numFolds,'Case2:crossValidateTooFewMaps', ...
    'Need at least %d maps for %d folds; got %d.',numFolds,numFolds,n);

edges=round(linspace(0,n,numFolds+1));
foldGamma=nan(1,numFolds);
foldExceed=zeros(1,numFolds);
foldSize=zeros(1,numFolds);
for f=1:numFolds
    testIdx=(edges(f)+1):edges(f+1);
    trainIdx=setdiff(1:n,testIdx);
    assert(~isempty(testIdx) && ~isempty(trainIdx),'Case2:crossValidateEmptyFold', ...
        'Fold %d is empty; reduce numFolds.',f);
    foldGamma(f)=helperCalibrateMapThreshold(v(trainIdx),targetPfaMap);
    foldExceed(f)=nnz(v(testIdx)>foldGamma(f));
    foldSize(f)=numel(testIdx);
end

totalExceed=sum(foldExceed);
totalMaps=sum(foldSize);
assert(totalMaps==n,'Case2:crossValidateFoldCoverage', ...
    'Folds scored %d maps but %d were supplied.',totalMaps,n);
pHat=totalExceed/totalMaps;

z=-sqrt(2)*erfcinv(2*(1-(1-ciLevel)/2));
den=1+z^2/totalMaps;
centre=(pHat+z^2/(2*totalMaps))/den;
halfWidth=z*sqrt(pHat*(1-pHat)/totalMaps+z^2/(4*totalMaps^2))/den;
ci=[max(0,centre-halfWidth) min(1,centre+halfWidth)];

cv=struct();
cv.TargetPfaMap=double(targetPfaMap);
cv.NumFolds=numFolds;
cv.NumMaps=n;
cv.NumFalseAlarmMaps=totalExceed;
cv.CrossFittedPfaMap=pHat;
cv.CrossFittedPfaMapCI=ci;
cv.CILevel=ciLevel;
cv.FoldThresholds=foldGamma;
cv.FoldExceedances=foldExceed;
cv.FoldSizes=foldSize;
cv.MeanFoldThreshold=mean(foldGamma);
cv.StdFoldThreshold=std(foldGamma);
end
