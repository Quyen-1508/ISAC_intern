# STATUS — read this first (2026-09-30)

This block is the entry point for a session picking the package up. The
sections below it are the accumulated history; `CHANGELOG.md` has the dated
detail.

## What this is

A benchmark comparing three spatial adaptive detectors on identical
post-Doppler data — **Full sliding (B=1), Block-4, Block-8 NSCM-ACE** — where
the only thing that differs between them is covariance reuse. Everything else
(training cells K, exclusion E, channel realisation, target, noise draw,
steering grid, association gate, CUT support, target Pfa) is shared, and the
Monte Carlo is paired.

## Code state — changed 2026-09-29 and 2026-09-30

Three changes matter to anyone running this:

**1. The CUT support no longer carries a block margin, and the range grid is
360 bins.** `spatialHalfWindow` is `E + K/2`, not `(maxB-1) + E + K/2`: the
block detector binds only on its first and last block, so its asserts reduce to
the pair the full sliding detector applies and B never enters.
`maxRangeOfInterest` was also raised 1050 → 1134 m, giving **360 native bins**
over 0 … 1132.42 m instead of 333 over 0 … 1047.25 m.

At K=64, E=28 the support is now **61–300, 240 CUT, 189.26–943.16 m** (was
68–266, 199 CUT, 211.34–835.91 m). Both verified end to end, and
`tests.run_validation()` measures the B-independence directly: all three
methods must run at the exact edge and all three must refuse one bin beyond it.

**The widened support changes what the detector sees.** It now contains
clutter cells at 842.22 m (−7.89 dB) and 870.61 m (−7.93 dB), both stronger
than the −9.83 dB cell at 485.77 m that earlier reports called the peak.
`ClutterDiagnostics.PeakRangeM` moves from 485.77 to 842.22 m. Since the ACE
threshold is calibrated from H0 map maxima, **expect Pd to fall relative to
the 199-CUT results**. The scenario box is unchanged (`scenarioExtentsMaxRangeM`
is still 750 m); only the tested cell set grew. The replay cache stays valid —
`maxRangeOfInterest` is not in the fingerprint.

**2. K is no longer forced to 2N.** `K > nChain` in the three helpers and
`K >= 2N` in the main script were statistical rules of thumb, not
implementation requirements: `helperNSCM` is trace-normalised so `tau = 1` at
every K, and `helperShrinkageLoading` adds `lambda*tau*I` with `lambda > 0`, so
the loaded covariance is positive definite for any K. K=32 and K=48 now run;
`Case2:benchmarkBelowRMB` warns below 2N. **The estimator was not touched.**

**3. Monte Carlo raised.** `NumH0Validation` 500 → 600 and
`numTrialsH1RealGeo` 200 → 250, so a run is 1650 maps instead of 1500 (×1.10).
Every saved result predates this too.

**3b. The contamination diagnostic no longer sweeps E.** It uses the run's own
`baseCfg.ExclusionBins`, so every diagnostic number belongs to the
configuration beside it. `GeometryComparison` is empty by construction — it
compared two exclusion widths. Exclusion widths are now compared across runs.
Detection is unaffected; the diagnostic never fed thresholds.

**4. Results are named by K and E**:
`spatial_ace_R<range>_K<K>_E<E>_seed<seed>.mat`. K and E change the support and
therefore the calibrated threshold, so runs differing only in K or E are
different experiments. `helperResolveResultFile` reads either naming and
**refuses to guess** when a range has several saved runs.

## Data state — and the one thing that will trip you

**Every `.mat` in `results/` was produced under the OLD 199-CUT support.**
Nothing has been re-run since the change. Old and new results are **not
comparable**: the ACE threshold is calibrated from H0 map maxima, so changing
the number of cells moves the threshold, Pfa and Pd.

| file | regime | K | E | speed |
|---|---|---|---|---|
| `spatial_ace_R{250,500,600,750}_seed41.mat` | 199 CUT, 333 bin, MC 500/200 | 64 | 28 | 19.40 m/s |
| `spatial_ace_R{603,606,612}_seed41.mat` | 199 CUT, 333 bin, MC 500/200 | 64 | 28 | 9.18 m/s |
| `sweep_KE_R250_seed41.mat` | geometry/covariance only, 72 (B,K,E) rows | — | — | 19.40 m/s |

The sweep file holds contamination, covariance, runtime and blind-region
numbers for the full (B,K,E) grid. It contains **no Pd, Pfa or RMSE** — that
Monte Carlo was deliberately deferred.

## What is pending

**`../PROMPT_cut_support_K48.md`** (one level up, outside this folder) is a
complete work order for the next session: 4 ranges at 19.40 m/s and 3 at
9.18 m/s, each at K ∈ {48,64} × E ∈ {28,12}, 28 runs, ~86 hours, intended for
a machine with no replay cache. The code work it describes is **already done**;
that prompt's section 3 tells you how to verify it rather than redo it.

## Traps that have already cost time

**`targetInitialRangeM` is not the filename label.** The label is
`round(targetInitialRangeM)`. `spatial_ace_R603_*` was run at **602.5 m**, R606
at **605.6 m**, R612 at 612.0 m. Passing 603 creates a different scenario that
writes to the same name.

**A wrong UAV speed destroys a cache entry.** The cache directory is keyed on
`round(targetInitialRangeM)` alone, but the replay fingerprint includes
`uavSpeed`. A wrong speed misses the fingerprint, triggers a cold replay and
**overwrites that range's cache**. This happened on 2026-09-30 and cost a
56-minute replay plus the 602.5 m cache.

Two speed groups, do not mix them: **19.40 m/s → 634.172 Hz** (R200/R250/R500/
R600/R750) and **9.18 m/s → 300.088 Hz** (R603/R606/R612). Those two Doppler
values are exact invariants and are the fastest way to catch a wrong run.

**The 400 Hz comb is not clutter.** Observations take 4 of every 5 slots
(TDD `DDDSU`), so the Doppler transform — an explicit 64×80 DFT on the true
PRS timestamps, **not** an FFT — carries replicas at PRF/5 = 400 Hz. They are
visible at −11 to −12 dB in the target's own Doppler response as well as in
the clutter map, at −800, −400, 0, +400 and +800 Hz. The 9.18 m/s group sits
at 300 Hz, on the inner skirt of the +400 Hz replica, which is why all three
of those ranges give Pd = 0 at nominal power.

---

# Handoff — Full sliding versus block-shared NSCM-ACE

## Purpose

The benchmark compares three detectors on the same post-Doppler data:

- Full sliding, `B=1`;
- Block-4;
- Block-8.

All three use the same `K=64` training cells and the same fixed exclusion
`E=28`. The primary comparison therefore changes covariance reuse rather than
training-cell count or exclusion width.

## Current defaults

```matlab
spatialAceCfg.NumTrainingCells      = 64;
spatialAceCfg.ExclusionBins         = 28;
spatialAceCfg.BlockSizesRangeBins   = [4 8];
spatialAceCfg.MapPfaTarget          = 0.10;
spatialAceCfg.NumH0Calibration      = 500;
spatialAceCfg.NumH0Validation       = 500;
spatialAceCfg.NumCalibrationFolds   = 10;
adaptCfg.numTrialsH1RealGeo         = 200;
adaptCfg.numTrialsSweep             = 50;
targetPowerOffsetDB                 = [-6 0 3 6 9 12];
```

`E=28` is kept fixed for comparability. It is no longer justified from a
single target-relative `-40 dB` PSF width. Recent diagnostics showed that this
width can change strongly with fractional range-bin placement and is therefore
retained only as a descriptive range-response metric.

## Detection and threshold procedure

For each detector, the code:

1. forms post-Doppler target, background and thermal-noise components;
2. estimates NSCM covariance from the configured training cells;
3. applies the same shrinkage loading and ACE statistic;
4. fits the map-level threshold from target-free H0 calibration maps;
5. freezes the threshold and evaluates it on an independent H0 validation set;
6. evaluates H1 only after threshold selection is complete.

Calibration, validation and H1 use separate deterministic random streams.
Methods remain paired within each trial.

## New diagnostic layer

`helperTrainingContaminationDiagnostics.m` tests whether signal present in the
training cells materially changes the covariance used by ACE. For each
configured exclusion `E` and target gain `g`, it computes the same loaded
covariance used by the production detector from:

- background-only training data, `M_B`;
- background-plus-target training data, `M_BT`.

It reports:

- relative Frobenius covariance perturbation;
- relative inverse-covariance perturbation;
- steering-direction perturbation after background whitening;
- ACE change for the same composite range-Doppler gate when only the covariance changes;
- adaptive SINR loss relative to the background covariance;
- condition numbers before the Cholesky-based ACE calculation.

The diagnostic does not change the production training windows, thresholds or
detections. Its purpose is to distinguish signal-in-training from changes
caused by choosing different background training regions.

## Range-grid diagnostics

The result structure now keeps the historical truth-cell SCNR and adds:

- `SCNRPeakCellDB`;
- `SCNRGateDB` over the same association range-Doppler gate;
- `FractionalRangeBinOffset`;
- `TargetRangeGateCaptureFraction`.

These values make it possible to separate propagation/background effects from
energy splitting between adjacent range bins.

## Results — four ranges, channel seed 41

Run 2026-09-26/27 on the warm replay cache. Logs are outside the package,
since the validation forbids a `.probe` folder here. Every range used the
defaults above; only `targetInitialRangeM` changed.

| | 250 m | 500 m | 600 m | 750 m |
|---|---|---|---|---|
| **Pd Full** | **0.9450** | **1.0000** | **0.9850** | **1.0000** |
| **Pd Block-4** | **0.9150** | **1.0000** | **0.9850** | **0.9950** |
| **Pd Block-8** | **0.8250** | **1.0000** | **0.9700** | **1.0000** |
| Pd exact-bin, Full | 0.7450 | 1.0000 | 0.9850 | 1.0000 |
| range RMSE Full (m) | 1.171 | 1.396 | 0.2795 | 1.137 |
| Doppler RMSE (Hz) | 12.95 | 9.172 | 9.172 | 9.172 |
| SCNR truth cell (dB) | -4.89 | -16.99 | -16.42 | -17.95 |
| SCNR peak cell (dB) | -4.89 | -16.50 | -16.42 | -17.95 |
| SCNR gate (dB) | -15.56 | -25.68 | -29.38 | -32.32 |
| fractional bin offset | 0.132 | 0.387 | 0.089 | 0.359 |
| gate capture | 0.9332 | 0.8583 | 0.9455 | 0.9337 |
| PSF half-width at -40 dB | 24 | 112 | 27 | 28 |
| Full s/map | 3.964 | 3.852 | 3.864 | 3.817 |
| speedup Block-4 / Block-8 | 3.00 / 4.55 | 2.98 / 4.51 | 2.97 / 4.49 | 2.97 / 4.52 |
| elapsed (s) | 9578 | 9354 | 9402 | 9279 |

The methods separate only at 250 m. At 500, 600 and 750 m everything
saturates, so Block-8 is the rational choice there: equal detection for about
4.5x less detector time. Block-4's single miss at 750 m is one trial in 200
and carries no information.

### Regression against the previous package

250 m, 500 m and 600 m had already been run with the earlier code. All three
reproduce **exactly**: same Pd, same trial counts, same thresholds to every
printed digit, same RMSE, same SCNR, same covariance-mismatch statistics.
The detector rewrite and the whole diagnostic layer are numerically neutral;
they added measurement without disturbing what is being measured.

### Before and after the leakage-aware Full correction

The original study ran Full with a 12-cell guard, so its training started 7
range bins from the CUT, inside the target's own skirt. Two ranges have
directly comparable numbers:

| Full sliding | guard-12 original | leakage-aware, E = 28 |
|---|---|---|
| 250 m | 0.38 | **0.945** |
| 750 m | 0.93 | **1.000** |

The 250 m gain is large and the 750 m gain is small, and the contamination
diagnostic explains why: at 750 m there was almost nothing to fix.

### A runtime anomaly that did not reproduce

The previous package measured Full at 26.200 s/map at 500 m, against about
4 s/map at every other range, and that run took 12.7 hours. Here 500 m ran at
3.852 s/map in 2.6 hours on the same cached channel data. The explanation
that it was a property of the 500 m data is therefore ruled out. What remains
is an interaction with the previous code, or the machine environment during
that overnight run; the two were not separated and doing so would cost
another 2.6 hours for little return.

---

## What drives training contamination

`ACEContaminatedToBackgroundRatio` at the truth CUT, g = 0, with the target
to background ratio measured inside the same training window:

| range | SCNR truth | PSF at -40 dB | tgt/bg in training, E=6 | ACE ratio E=6 | ACE ratio E=28 |
|---|---|---|---|---|---|
| 250 m | -4.89 | 24 | **-46.2 dB** | **0.5545** | 0.8792 |
| 500 m | -16.99 | 112 | **-49.0 dB** | **0.7330** | 0.9531 |
| 600 m | -16.42 | 27 | **-56.9 dB** | **0.9484** | 0.9856 |
| 750 m | -17.95 | 28 | **-62.6 dB** | **0.9803** | 0.9966 |

**The training target-to-background ratio orders the contamination perfectly
across all four ranges. Nothing else in the table does.**

- SCNR does not: 500 m has a worse SCNR than 600 m yet is markedly more
  contaminated.
- Fractional bin offset does not: 750 m (0.359) and 500 m (0.387) straddle
  almost identically yet sit at opposite ends of the contamination range.
- The -40 dB PSF width does not on its own: it is one of the two inputs.

The ratio is a joint function of how strong the target is and how far its
energy spreads. 250 m is contaminated because the target is strong even
though its response is narrow; 500 m because its response is very wide even
though the target is weak; 600 m and 750 m are clean because neither applies.

**Use `TrainingTargetToBackgroundDB` as the predictor.** It is measured
directly by the diagnostic, it needs no interpretation, and every indirect
proxy tried here failed on at least one of the four ranges.

### A prediction that failed, recorded so it is not repeated

Before 750 m was run, this analysis predicted that because 750 m straddles
its range bin by 0.359, close to the 0.387 at 500 m, its contamination would
resemble 500 m (ACE ratio near 0.73) rather than 600 m. **The measurement was
0.9803, cleaner than 600 m.**

The chain of reasoning broke at its first link: straddle does not reliably
produce a wide range response. The profile shapes show it directly.

```
          -1 bin   +1 bin   +-30 bins
500 m      -0.2    -10.7      ~ -36      energy genuinely split in two
750 m     -10.5    -13.7      ~ -44      straddled but still concentrated
```

At 500 m the neighbouring bin is 0.2 dB below the peak; at 750 m, with nearly
the same fractional offset, it is 10.5 dB below. The near-equal split at
500 m is a property of that range's channel realisation, not a consequence of
straddle. A single observation had been promoted to a rule.

---

## Separating locality from signal in training

`GeometryComparison` changes only the background training geometry, E = 6 to
E = 28, and reports the ACE ratio twice: once with the background covariance
and once with the contaminated one. At g = 0:

| range | ACE ratio with M_B | ACE ratio with M_BT | attributable to contamination |
|---|---|---|---|
| 250 m | 0.9238 | 1.4649 | x1.586, +2.00 dB |
| 500 m | 1.0949 | 1.4237 | x1.300, +1.14 dB |
| 600 m | 0.9896 | 1.0283 | x1.039, +0.17 dB |
| 750 m | 1.0436 | 1.0610 | x1.017, +0.07 dB |

The `M_B` column is the pure training-region effect, with no target involved.
It stays within about 8% of unity everywhere, so widening the exclusion is
nearly free in locality terms, and almost all of the benefit at 250 m is the
removal of signal from the training data.

Note that at 500 m and 750 m the `M_B` ratio is **above** one: moving the
training window further out *improves* the background-only ACE. "More local is
better" is not a general rule, which is exactly why this comparison is needed
rather than assuming the locality penalty away.

### Exclusion saturates when the target is strong

At 250 m the contamination-attributable gain from widening E falls as the
target gets stronger, +2.00 dB at g = 0 but +1.39 dB at g = +12 dB, and at
E = 28 the SINR loss is still 1.97 dB at that gain. No swept E reaches a
0.5 dB tolerance there. At 600 m and 750 m the gain instead rises with g,
from a negligible base. There is a regime boundary: below it the exclusion
works as designed, above it the residual sits too close to the CUT for any
practical exclusion to remove.

`E = 28` is supported by these measurements at nominal target power and no
reduction is recommended.

## Validation

Run:

```matlab
report = tests.run_validation();
```

Executed on MATLAB R2026b with the project helpers supplied from the previous
package on the MATLAB path: **44 measured checks, all passing**, including the
zero-target neutrality of the contamination diagnostic and independent
verification of its Frobenius and ACE-ratio formulas.

The validation returns a table containing measured errors, residuals and
accepted tolerances. It does not use hard-coded PASS messages as evidence.
The checks include:

- zero-padding/native-bin equivalence;
- ACE scale invariance and numerical bounds;
- range-Doppler injected-tone location and power;
- association-gate behaviour;
- cached preprocessing equivalence;
- Full versus an independent per-CUT implementation;
- Block-1 versus Full numerical identity;
- block training geometry and covariance-reuse counts;
- exclusion geometry;
- contamination-diagnostic neutrality with zero target;
- independent verification of the contamination Frobenius and ACE-ratio formulas;
- out-of-sample threshold calibration and cross-fitting;
- deterministic repeated-seed behaviour;
- production configuration and source-distribution checks.

The package still depends on project helpers used by the original simulation,
including `helperNSCM`, `helperShrinkageLoading`, `helperRangeCubeFromPRS`,
`helperRangeDopplerPowerMap`, `helperSpatialACEPostDoppler` and
`helperSpatialACEFromPostDoppler`. The validation checks that these functions
are available on the MATLAB path before the full benchmark is run.

## Interpretation rules

- Do not infer the required exclusion from the `-40 dB` target-relative width alone.
- A small global covariance perturbation does not by itself prove that the
  target direction is unaffected; use the inverse, directional, ACE and SINR
  diagnostics together.
- A difference between background-only results at `E=6` and `E=28` is a
  training-region/locality effect, not signal-in-training.
- `SCNRTruthCellDB` is a single-cell quantity. When fractional range-bin
  placement differs between ranges, also inspect `SCNRGateDB`,
  `SCNRPeakCellDB` and `TargetRangeGateCaptureFraction`.
- The Full/Block comparison should use the common CUT support determined by
  the strictest method so that every detector is scored on the same map.
- Predict contamination from `TrainingTargetToBackgroundDB`, not from proxies.
  Across the four measured ranges it orders the contamination perfectly, while
  `SCNRTruthCellDB`, `FractionalRangeBinOffset` and the `-40 dB` PSF width each
  fail on at least one of them.
- Do not infer a wide range response from a large fractional bin offset. At
  750 m the offset is 0.359 and the PSF half-width 28 bins; at 500 m the offset
  is 0.387 and the half-width 112 bins. Straddle is one contributor, not a
  cause.

---

# Session 2026-09-29 — (B,K,E) sweep and the TDD replica

## What is in this package that was not before

| File | What it is |
|---|---|
| `sweep_KE_contamination.m` | Drives detectors and the contamination diagnostic over 72 (B,K,E) configurations. No Monte Carlo. |
| `build_clutter_doppler_figure.m` | Clutter power versus Doppler bin at chosen range cells. |
| `results/sweep_KE_R250_seed41.mat` / `_full.csv` | The 72-row sweep output, all columns. |
| `results/figures_clutterdoppler_seed41_*` | Three clutter-Doppler figures; the `-1000to1000Hz` one is the informative one. |
| `results/figures_rmse_seed41_20260928_171520` | Current RMSE figures, shared axes. Earlier `figures_rmse_*` are superseded. |

## The K asserts were relaxed, deliberately

`K > nChain` in the three helpers and `K >= 2N` in the main script were both
rule-of-thumb guards, not implementation requirements. The justification is
recorded in the comment above each relaxed assert and verified numerically:
`helperNSCM` is trace-normalised so `tau = 1` at every K, `helperShrinkageLoading`
adds `lambda*tau*I` with `lambda > 0`, and the loaded covariance is positive
definite for any K. `chol` was checked at K = 8 through 96.

**The estimator was not changed.** `helperNSCM` and `helperShrinkageLoading`
are byte-identical to the previous package, and every Cholesky assert remains
in place. What small K costs is reported, not forbidden: at K=32 the condition
number is 250k against 645k at K=96, and the loading is 7.82e-05 against
2.89e-05.

If you want the old behaviour back, restore `K>nChain` in the three helpers
and `K >= 2*nActiveRx` in the main script; nothing else depends on it.

## Blind region: two definitions, and B only enters one

Reading the executable asserts, `helperBlockSharedNSCMACE` binds only on the
first block (`lo = cutIdx(1)`) and the last (`hi = cutIdx(end)`), giving the
same two inequalities as Full. So the **strict native support is
`[1+E+K/2, nRange-E-K/2]` for every B**. Verified by experiment at K=64, E=28:
bin 61 passes for B = 1, 4 and 8, and bin 60 fails for all three.

B enters through the **effective exclusion inside a block**. All CUTs in a
block share one training set taken outside `[lo-E, hi+E]`, so a CUT at `lo+j`
sees exclusion `E+j` on the left and `E+(B-1-j)` on the right: still at least
E on both sides, but stretched to `E+B-1` on one. At B=8, E=28 a block-edge
CUT sees 28 one side and 35 the other.

If you demand a symmetric window at that worst case you get the conservative
support `[1+(B-1)+E+K/2, nRange-(B-1)-E-K/2]`, which is the main script's
formula and does depend on B: **+18.93 m of blind range at B=4 and +44.16 m at
B=8**, constant in K and E.

The benchmark's common support uses `maxB = 8` for all three methods, so Full
and Block-4 currently pay Block-8's blind cost of 44.16 m that they do not
need. That is correct for a fair Pd comparison and wrong as a statement of
each method's standalone coverage.

## What is still missing

**Pd, Pfa_map and RMSE across the (K,E) grid.** 17 feasible configurations at
about 53 hours total on the warm R250 cache. `(K=96, E=32)` is infeasible at
R250: the truth bin 80 falls outside its own support, which starts at bin 81.

Everything needed is in place: the asserts no longer block K = 32 or 48, the
cube export exists, and `sweep_KE_contamination.m` already reports the
geometry and cost per configuration.

## Two claims to treat carefully

The contamination numbers are **one realisation, noise-free**. The diagnostic
uses `ZB` and `ZT` only; no thermal noise enters `M_B`, `M_BT` or the gate
data. At R250 noise is 47 dB below clutter so this is defensible, but it is an
argument, not a measurement. There is no averaging, so small differences
between adjacent cells are not resolved.

The `g = +6` and `g = +12` columns are **not separate simulations**. The code
scales the one simulated target cube by `10^(gdB/20)`. A genuinely stronger
target would come from a different RCS or range and would have a different
spatial signature. Only `g = 0` is a simulated state.

---

# Update 2026-09-30 — support widened, results keyed by K and E

**The "Blind region" section above is superseded for the production path.**
It described a strict native support and a conservative common support that
differed by `(maxBlockSize-1)`. The conservative margin has been removed:
`spatialHalfWindow` is now `E + K/2`, which is what the detector asserts
actually require. Full, Block-4 and Block-8 all share that same support, and
the statement "Full and Block-4 pay Block-8's blind cost" no longer applies.

At K=64, E=28 the support is **61–273, 213 CUT, 189.26–857.99 m**, against
68–266 / 199 CUT / 211.34–835.91 m before.

## What this means for the saved results

**Every result file in `results/` predates the change and belongs to the
199-CUT regime.** They were not re-run and are byte-identical to before.

Old and new results are **not comparable**. The ACE threshold is calibrated
from H0 map maxima; more cells raise that maximum, which raises the threshold
and moves Pfa and Pd. Any future run on the new support starts a separate
series.

## Result file naming

New runs write `spatial_ace_R<range>_K<K>_E<E>_seed<seed>.mat`. The figure
scripts resolve either naming through `helperResolveResultFile`, which refuses
to guess when a range has several saved runs — pass `K` and `E` (trailing
arguments for `build_clutter_figures` and `build_tradeoff_figures`, `opts.K` /
`opts.E` for the other three).

## Two traps worth carrying forward

`targetInitialRangeM` is **not** the label in the filename: the label is
`round(targetInitialRangeM)`. `spatial_ace_R603_*` was run at 602.5 m, R606 at
605.6 m. Passing 603 creates a different scenario that overwrites both the
result and the replay cache of the same label.

The cache directory is keyed on `round(targetInitialRangeM)` alone, but the
replay fingerprint includes `uavSpeed`. A run at the wrong speed misses the
fingerprint and **overwrites that range's cache** with the wrong scenario.
The 19.4 m/s group (R200/R250/R500/R600/R750) and the 9.18 m/s group
(R603/R606/R612) must not be mixed up.
