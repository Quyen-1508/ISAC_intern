function output = Detection_Case2_SpatialACE_Benchmark(validationOverride)
%Detection_Case2_SpatialACE_Benchmark Primary Case-2 UAV detection benchmark.
if nargin < 1 || isempty(validationOverride)
    validationOverride = struct();
end
% Detection_Case2_SpatialACE_Benchmark
% Primary Case-2 UAV detection benchmark.
% Baseline : full per-CUT sliding NSCM-ACE on all active receive chains.
% Proposed : block-shared, leakage-excluded NSCM-ACE on the same chains.
% No MVDR collapse, legacy CA-CFAR detector, target-feedback loop, ECA-C,
% PSF/CLEAN diagnostics and CRLB studies are not on the executable path.
% Range/Doppler RMSE is evaluated only on successfully associated detections.

runWallTic_ = tic;

%% ===================== 1. Physical layer and benchmark controls =========
carrierFrequency   = 4.9e9;
subcarrierSpacing  = 30;
channelBandwidth   = 50;
waveformNSizeGrid  = 133;
txPower            = 46;
rxNoiseFigure      = 5;

uraSize            = [8 4];
numRFChains        = 32;
physicalBoresightAzDeg = 0;
physicalBoresightElDeg = 0;

txRxArraySeparationM = 0.3;
txRUPosition = [0;0;25];
bsPosition = txRUPosition;
rxGeometryMode = "sideBySide";
rxPolarizationBranch = "both";
switch rxGeometryMode
    case "boresight"
        rxOffsetHat=[1;0;0];
    case "sideBySide"
        rxOffsetHat=[0;1;0];
    otherwise
        error('Case2:badGeometryMode','Unsupported rxGeometryMode.');
end
snifferRUPosition=txRUPosition+txRxArraySeparationM*rxOffsetHat;
assert(abs(norm(snifferRUPosition-txRUPosition)-txRxArraySeparationM)<1e-12, ...
    'Case2:separationChanged','Tx/Rx separation changed.');

prsAzSectorDeg=[-30 30];
prsElSectorDeg=[0 25];
numAz=5; numEl=3;
tddPattern=["D" "D" "D" "S" "U" "D" "D" "D" "S" "U"];
tddSpecialSlotFormat=struct('NumDL',10,'NumFlexible',2,'NumUL',2);
symStartPattern=6;
numPRSSymbolsPattern=2;
prsSymbolsPattern=symStartPattern+(0:numPRSSymbolsPattern-1);

% Detection uses native range bins. Zero padding is disabled in the default
% Monte-Carlo path. The validation suite checks native-bin invariance against
% a zero-padded transform on synthetic data.
rangeIFFTZeroPadFactor=1;
minRangeOfInterest=30;
% 1134 m puts floor(1134/3.154382)+1 = 360 native range bins on the grid
% (359 <= 1134/dr < 360). Raised from 1050 m / 333 bins on 2026-09-30.
% maxRangeOfInterest does NOT enter the replay fingerprint, which is built
% from scenarioExtentsXY, so existing caches stay valid. It does change the
% number of CFAR cells and therefore the calibrated threshold.
maxRangeOfInterest=1134;
cfarRangeGuardCells=6;
cfarRangeTrainingCells=12;

targetPowerOffsetdB=0;
consoleVerbosity="summary";
channelSeedCommon=41;
sensingNoiseSeed=300;
dataSeedBase=100;
losProbability=1;

% UE parameters are needed only to generate the coexistence waveform once.
uePosition=[200;-50;1.5];
ueNoiseFigure=9; ueSpeed=0.833; ueChannelSeed=77; ueNoiseSeed=200;
cdlProfile="CDL-D"; cdlDelaySpread=100e-9; pdschBeamMode="ueBeam";

trackingCPI_DurationMs=40;
detectionDwellOffsetDwells=4;
requestedTargetInitialRangeM=250; % run 250 and 750 m as separate replays
requestedUavSpeedMps=19.4;     % 2026-09-23: moved off the 400 Hz TDD replica line. At 25 m/s the
                               % UAV Doppler sits under one bin from the nearest replica, which an
                               % earlier revision showed can steal the blind detector's pick.

spatialAceCfg=struct;
% K = 64 equals 2N for the 32 active receive chains. This keeps the covariance
% training support at the conventional Reed-Mallett-Brennan reference point
% while the benchmark varies only covariance reuse.
spatialAceCfg.NumTrainingCells=64;
% Every method uses the same fixed exclusion E = 28 so the comparison changes
% only covariance reuse. E is not inferred from the -40 dB target-response width:
% that width is retained only as a descriptive PSF diagnostic because fractional
% range-bin placement can make it unstable. Training-contamination diagnostics
% below test the actual loaded covariance and ACE response directly.
spatialAceCfg.ExclusionBins=28;
% Full sliding is the B=1 reference. These are the additional reuse factors
% evaluated against it.
spatialAceCfg.BlockSizesRangeBins=[4 8];
% Thresholds are fitted from one target-free data set and evaluated on a
% separate target-free data set. H1 samples never enter threshold selection.
spatialAceCfg.MapPfaTarget=0.10;
spatialAceCfg.NumH0Calibration=500;
spatialAceCfg.NumH0Validation=600;   % 500 -> 600 on 2026-09-30
spatialAceCfg.NumCalibrationFolds=10; % diagnostic only; not the reported validation set
spatialAceCfg.associationRangeBins=1;
spatialAceCfg.associationDopplerBins=1;

adaptCfg=struct;
adaptCfg.seed=20260913;
adaptCfg.ciLevel=0.95;
adaptCfg.numTrialsH1RealGeo=250;     % 200 -> 250 on 2026-09-30
adaptCfg.numTrialsSweep=50;
targetPowerOffsetDB=[-6 0 3 6 9 12];

cacheCfg.enable=true;
diagCfg.runBackgroundOnlyReplay=true;

% Drivers can override benchmark controls without editing the main file.
if exist('validationOverride','var') && isstruct(validationOverride)
    if isfield(validationOverride,'targetInitialRangeM'), requestedTargetInitialRangeM=double(validationOverride.targetInitialRangeM); end
    if isfield(validationOverride,'channelSeedCommon'), channelSeedCommon=double(validationOverride.channelSeedCommon); end
    if isfield(validationOverride,'uavSpeedMps'), requestedUavSpeedMps=double(validationOverride.uavSpeedMps); end
    if isfield(validationOverride,'sensingNoiseSeed'), sensingNoiseSeed=double(validationOverride.sensingNoiseSeed); end
    if isfield(validationOverride,'spatialAceMapPfaTarget'), spatialAceCfg.MapPfaTarget=double(validationOverride.spatialAceMapPfaTarget); end
    if isfield(validationOverride,'spatialAceNumH0Calibration'), spatialAceCfg.NumH0Calibration=double(validationOverride.spatialAceNumH0Calibration); end
    if isfield(validationOverride,'spatialAceNumH0Validation'), spatialAceCfg.NumH0Validation=double(validationOverride.spatialAceNumH0Validation); end
    if isfield(validationOverride,'spatialAceNumCalibrationFolds'), spatialAceCfg.NumCalibrationFolds=double(validationOverride.spatialAceNumCalibrationFolds); end
    if isfield(validationOverride,'spatialAceNumTrainingCells'), spatialAceCfg.NumTrainingCells=double(validationOverride.spatialAceNumTrainingCells); end
    if isfield(validationOverride,'spatialAceBlockSizesRangeBins'), spatialAceCfg.BlockSizesRangeBins=double(validationOverride.spatialAceBlockSizesRangeBins(:).'); end
    if isfield(validationOverride,'spatialAceExclusionBins'), spatialAceCfg.ExclusionBins=double(validationOverride.spatialAceExclusionBins); end
    if isfield(validationOverride,'adaptNumTrialsH1RealGeo'), adaptCfg.numTrialsH1RealGeo=double(validationOverride.adaptNumTrialsH1RealGeo); end
    if isfield(validationOverride,'adaptNumTrialsSweep'), adaptCfg.numTrialsSweep=double(validationOverride.adaptNumTrialsSweep); end
    if isfield(validationOverride,'targetPowerOffsetDB'), targetPowerOffsetDB=double(validationOverride.targetPowerOffsetDB(:).'); end
    if isfield(validationOverride,'rangeIFFTZeroPadFactor'), rangeIFFTZeroPadFactor=double(validationOverride.rangeIFFTZeroPadFactor); end
    if isfield(validationOverride,'consoleVerbosity'), consoleVerbosity=string(validationOverride.consoleVerbosity); end
end

assert(mod(spatialAceCfg.NumTrainingCells,2)==0, ...
    'Case2:spatialAceWindowParity','ACE training-cell count must be even.');
assert(spatialAceCfg.MapPfaTarget>0 && spatialAceCfg.MapPfaTarget<1, ...
    'Case2:spatialAceMapPfa','MapPfaTarget must lie strictly between zero and one.');
assert(isequal(spatialAceCfg.BlockSizesRangeBins,[4 8]), ...
    'Case2:spatialAceBlockSizes','Primary benchmark requires BlockSizesRangeBins = [4 8].');
assert(ismember(consoleVerbosity,["summary" "full"]), ...
    'Case2:badVerbosity','consoleVerbosity must be summary or full.');
consoleFull_(consoleVerbosity=="full");

cacheCfg.dir=fullfile('cache',sprintf('replay_seed%d',channelSeedCommon));
if exist('validationOverride','var') && isstruct(validationOverride) && isfield(validationOverride,'cacheDir')
    cacheCfg.dir=char(validationOverride.cacheDir);
end

fprintf('\n================ BENCHMARK CONFIGURATION ================\n');
fprintf('Channel seed                 : %d\n',channelSeedCommon);
fprintf('Requested initial UAV range  : %.1f m\n',requestedTargetInitialRangeM);
fprintf('Range zero padding           : x%d\n',rangeIFFTZeroPadFactor);
fprintf('Map-level Pfa target         : %.3f\n',spatialAceCfg.MapPfaTarget);
fprintf('H0 calibration / validation : %d / %d maps\n', ...
    spatialAceCfg.NumH0Calibration,spatialAceCfg.NumH0Validation);
fprintf('H1 / sweep trials            : %d / %d\n', ...
    adaptCfg.numTrialsH1RealGeo,adaptCfg.numTrialsSweep);
fprintf('=========================================================\n');

propagationSpeed=physconst('LightSpeed');
wavelength=propagationSpeed/carrierFrequency;

%% ===================== 2. Waveform configuration ========================
waveformConfig = helperGet5GWaveformConfiguration(channelBandwidth, ...
    [], subcarrierSpacing, waveformNSizeGrid);
assert(waveformConfig.Carrier.NStartGrid == 0, 'Case2:badNStartGrid', ...
    'Carrier RB0 must be CRB0.');
waveformConfig.PDSCH.PRBSet = 0:waveformConfig.Carrier.NSizeGrid-1;
waveformConfig.PRSSlotScheduling    = "rateMatch";
waveformConfig.CorrectTxPowerScaling = true;
waveformConfig.PDSCH.DMRS.DMRSTypeAPosition       = 2;
waveformConfig.PDSCH.DMRS.DMRSLength              = 1;
waveformConfig.PDSCH.DMRS.DMRSAdditionalPosition  = 2;
waveformConfig.PDSCH.DMRS.NumCDMGroupsWithoutData = 1;
waveformConfig.PDSCH.DMRS.DMRSConfigurationType   = 1;

waveformInfo     = nrOFDMInfo(waveformConfig.Carrier);
symbolsPerSlot   = waveformConfig.Carrier.SymbolsPerSlot;
numSlotsPerFrame = waveformInfo.SlotsPerFrame;
numSubcarriers   = waveformConfig.Carrier.NSizeGrid*12;
frameDuration    = 10e-3;
slotDurationS    = frameDuration/numSlotsPerFrame;      % 0.5 ms
tddPeriodSlots   = numel(tddPattern);

% ---- DM-RS vs PRS-symbol collision avoidance (baseline Section 2) -----
% Search a DMRSAdditionalPosition that keeps DM-RS off every PRS symbol at
% both PDSCH durations the TDD schedule produces. PRS never moves.
dmrsCandidateOrder = [2 3 1 0];
dmrsLdValues = [symbolsPerSlot, tddSpecialSlotFormat.NumDL];
dmrsChosenAdditionalPosition = [];
for candAddPos = dmrsCandidateOrder
    okAllLd = true;
    for ldProbe = dmrsLdValues
        pdschProbe = waveformConfig.PDSCH;
        pdschProbe.DMRS.DMRSAdditionalPosition = candAddPos;
        pdschProbe.SymbolAllocation = [0 ldProbe];
        try
            dmrsIdxProbe = nrPDSCHDMRSIndices(waveformConfig.Carrier, pdschProbe);
        catch
            okAllLd = false;
            break
        end
        [~, dmrsSym1BasedProbe] = ind2sub([numSubcarriers symbolsPerSlot], double(dmrsIdxProbe));
        % check EVERY PRS symbol (L_PRS = 2 -> symbols 6 and 7)
        if any(ismember(prsSymbolsPattern, unique(dmrsSym1BasedProbe) - 1))
            okAllLd = false;
            break
        end
    end
    if okAllLd
        dmrsChosenAdditionalPosition = candAddPos;
        break
    end
end
assert(~isempty(dmrsChosenAdditionalPosition), 'Case2:noValidDMRSAdditionalPosition', ...
    'No DMRSAdditionalPosition in %s clears PRS symbols %s at both ld = %s.', ...
    mat2str(dmrsCandidateOrder), mat2str(prsSymbolsPattern), mat2str(dmrsLdValues));
if dmrsChosenAdditionalPosition ~= waveformConfig.PDSCH.DMRS.DMRSAdditionalPosition
    fprintf(['DM-RS config changed: DMRSAdditionalPosition %d -> %d (the starting ' ...
        'value collided with PRS symbol %d; verified via nrPDSCHDMRSIndices).\n'], ...
        waveformConfig.PDSCH.DMRS.DMRSAdditionalPosition, ...
        dmrsChosenAdditionalPosition, symStartPattern(1));
end
waveformConfig.PDSCH.DMRS.DMRSAdditionalPosition = dmrsChosenAdditionalPosition;

%% ===================== 3. TDD schedule derivation (baseline Section 3) ==
prsCapableLocalSlots = zeros(1, 0);
for s = 0:(tddPeriodSlots-1)
    dirThisSlot  = helperTDDSlotDirection(s, tddPattern);
    symTypesSlot = helperTDDSymbolTypes(dirThisSlot, symbolsPerSlot, tddSpecialSlotFormat);
    % all PRS symbols must be downlink
    if all(symTypesSlot(prsSymbolsPattern+1) == "D")
        prsCapableLocalSlots = [prsCapableLocalSlots, s]; %#ok<AGROW>
    end
end
assert(isequal(prsCapableLocalSlots, [0 1 2 3 5 6 7 8]), ...
    'Case2:prsCapableSlotsChanged', ...
    'On the shipped DDDSUDDDSU baseline the PRS-capable slots must be [0 1 2 3 5 6 7 8] (got %s).', ...
    mat2str(prsCapableLocalSlots));

%% ===================== 4. Panel, virtualization, codebook ===============
panel = helperBuildURAPanel(uraSize, numRFChains, carrierFrequency, ...
    physicalBoresightAzDeg, physicalBoresightElDeg);
txArray           = panel.TxArray;
rxArray           = clone(panel.TxArray);
txSteeringVector  = panel.TxSteeringVector;
rxSteeringVector  = phased.SteeringVector('SensorArray', rxArray, ...
    'IncludeElementResponse', false);
virtualizationB   = panel.VirtualizationB;
numRadiatingPorts = panel.NumRadiatingPorts;

txOrientation = [physicalBoresightAzDeg; -physicalBoresightElDeg; 0];
rxOrientation = txOrientation;
bsOrientationAxes = rotz(txOrientation(1))*roty(txOrientation(2))*rotx(txOrientation(3));

% Sine-uniform, cell-centred codebook (baseline Section 3b).
sineUniformCentres = @(sectorDeg, n) asind( ...
    sind(sectorDeg(1)) + ((1:n) - 0.5)*(sind(sectorDeg(2)) - sind(sectorDeg(1)))/n);
[azGrid, elGrid] = meshgrid(sineUniformCentres(prsAzSectorDeg, numAz), ...
                            sineUniformCentres(prsElSectorDeg, numEl));
scanAngles = [reshape(azGrid.', 1, []); reshape(elGrid.', 1, [])];
numBeams   = size(scanAngles, 2);

% Chain-to-polarization map (chains 1..16 one slant, 17..32 the other),
% asserted against the virtualization matrix. rxPolarizationBranch selects
% the RECEIVE subset only; Tx always uses all numRFChains chains.
chainsPol1 = 1:(numRFChains/2);
chainsPol2 = (numRFChains/2 + 1):numRFChains;
polSupport1 = any(abs(virtualizationB(:, chainsPol1)) > 0, 2);
polSupport2 = any(abs(virtualizationB(:, chainsPol2)) > 0, 2);
assert(~any(polSupport1 & polSupport2), 'Case2:polChainsOverlap', ...
    'The two chain halves drive overlapping radiating ports - not the two polarizations.');

switch rxPolarizationBranch
    case "both"
        rxChains = 1:numRFChains;
    case "pol1"
        rxChains = chainsPol1;
    case "pol2"
        rxChains = chainsPol2;
    otherwise
        error('Case2:badRxPolarizationBranch', ...
            'rxPolarizationBranch must be "both", "pol1" or "pol2".');
end

% Transmit weights (one per codebook beam). Receive weights are built in
% Sections 9 and 11b once the TRACK beam b* is known.
wtxAll = zeros(numRadiatingPorts, numBeams);
for b = 1:numBeams
    % baseline Tx recipe, all numRFChains chains
    wcTx = conj(virtualizationB.' * txSteeringVector(carrierFrequency, scanAngles(:, b)));
    wtxAll(:, b) = virtualizationB*(wcTx/norm(wcTx));
end

%% ===================== 5. PRS base config and range grid ================
prs = nrPRSConfig;
prs.PRSResourceSetPeriod  = [numSlotsPerFrame 0];
prs.PRSResourceOffset     = 0;
prs.PRSResourceRepetition = 1;
prs.PRSResourceTimeGap    = 1;
prs.MutingPattern1        = [];
prs.MutingPattern2        = [];
prs.NumRB                 = 132;
prs.RBOffset              = 0;
prs.CombSize              = 2;
prs.NumPRSSymbols         = numPRSSymbolsPattern;
prs.SymbolStart           = symStartPattern;
prs.REOffset              = 0;
prs.NPRSID                = 0;
assert(prs.CombSize == 2 && prs.NumPRSSymbols == 2 && prs.SymbolStart == 6, ...
    'Case2:prsNumerologyChanged', 'PRS must stay L_PRS = 2, comb-2, symbol 6.');

% L_PRS = 2, comb-2: the two symbols tile the comb (offsets 0 and 1), so an
% occasion samples 1584 tones over the same 47.52 MHz occupied bandwidth as
% L = 1 (energy per occasion doubles; range resolution unchanged; comb
% ambiguity removed). The L symbols are merged into ONE slow-time sample.
assert(mod(prs.CombSize, prs.NumPRSSymbols) == 0, 'Case2:combNotDivisible', ...
    'The L PRS symbols must tile the comb exactly (mod(CombSize, L) == 0). Got comb %d, L %d.', ...
    prs.CombSize, prs.NumPRSSymbols);
combStepPRS       = prs.CombSize/prs.NumPRSSymbols;         % 1 for comb-2, L=2
nToneRange        = prs.NumRB*12*prs.NumPRSSymbols/prs.CombSize;   % 1584
nIFFTRange        = rangeIFFTZeroPadFactor*nToneRange;
rangeResolutionPRS = propagationSpeed/(2*nToneRange*combStepPRS*subcarrierSpacing*1e3);   % set by the occupied bandwidth
rangeGridStep      = rangeResolutionPRS/rangeIFFTZeroPadFactor;
maxUnambiguousRangePRS = propagationSpeed/(2*combStepPRS*subcarrierSpacing*1e3);
assert(maxRangeOfInterest < maxUnambiguousRangePRS, 'Case2:rangeBeyondAmbiguity', ...
    'maxRangeOfInterest must stay inside the comb-%d unambiguous range.', combStepPRS);
numRangeBins = floor(maxRangeOfInterest/rangeGridStep) + 1;
rangeGrid    = (0:numRangeBins-1)*rangeGridStep;
assert(numRangeBins <= nIFFTRange, 'Case2:rangeGridLongerThanIFFT', ...
    'rangeGrid has %d bins but the IFFT produces %d.', numRangeBins, nIFFTRange);

nativeIdx       = 1:round(rangeResolutionPRS/rangeGridStep):numRangeBins;   % native (CFAR) range grid on the zero-padded IFFT
rangeGridNative = rangeGrid(nativeIdx);
numNativeBins   = numel(nativeIdx);

rangeProcCfg = struct('combSize', combStepPRS, 'nTone', nToneRange, ...
                      'nIFFT', nIFFTRange);

%% ===================== 6. Range support for ACE ========================
% Keep the historical guard/training half-window only to define a common
% interior range region. Thresholding itself is performed exclusively by ACE.
halfWindowNative = (cfarRangeGuardCells + cfarRangeTrainingCells)/2;
cutIdxNative = intersect( ...
    find(rangeGridNative >= minRangeOfInterest & rangeGridNative <= maxRangeOfInterest), ...
    (1+halfWindowNative):(numNativeBins-halfWindowNative));
cutIdxNative = cutIdxNative(:);
assert(~isempty(cutIdxNative), 'Case2:emptyCFARRegion', 'The CFAR region is empty.');

%% ===================== 7. UAV trajectory ================================
uavSpeedMps = requestedUavSpeedMps; % radial inbound [m/s]; default 25 m/s
targetInitialRangeM = requestedTargetInitialRangeM; % UAV slant range at dwell start [m]

% Cache is separated by range so 250/750 m replays never overwrite one another.
cacheCfg.dir = fullfile(cacheCfg.dir, sprintf('R%d', round(targetInitialRangeM)));

refBeamAzDeg        = 0;
refBeamElDeg        = 20.168;    % UAV elevation ray [deg] - places the drone; bStar picks the nearest codebook beam.
% The elevation codebook is sine-uniform on [0 25] deg with centres at 4.040,
% 12.198 and 20.622 deg, so this ray sits 0.45 deg off the centre of the beam
% b* selects. It reaches the replay-cache fingerprint through
% replayBaseParams.scenarioExtentsXY, which is built from it; beamEl alone is
% quantised to the codebook and would not change.
simulationDuration  = 4;         % s

% Detection dwell offset: how far the dwell sits along the trajectory. Sets
% the UAV truth range at CPI mid and is in the replay-cache fingerprint.
% Nothing is simulated during the offset (dead time).
detectionDwellOffsetS = detectionDwellOffsetDwells*trackingCPI_DurationMs*1e-3;
assert(detectionDwellOffsetS + trackingCPI_DurationMs*1e-3 <= simulationDuration, ...
    'Case2:trajectoryTooShort', ...
    'The dwell offset (%.3f s) plus one dwell exceeds the %.1f s trajectory.', ...
    detectionDwellOffsetS, simulationDuration);
% REGRESSION PIN. Every cached replay and every published number in this
% project was produced at 0.160 s. If this fires, the dwell has moved and
% nothing downstream is comparable with anything that came before.
assert(abs(detectionDwellOffsetS - 0.160) < 1e-12, 'Case2:dwellOffsetMoved', ...
    ['The detection dwell offset is %.4f s, not the 0.160 s every cached ' ...
     'replay and every earlier result in this project was produced at. ' ...
     'Moving it changes the UAV truth range at CPI mid and invalidates ' ...
     'the entire replay cache.'], detectionDwellOffsetS);

droneStartPosition = helperDirRangeToPosition(bsPosition, bsOrientationAxes, ...
    refBeamAzDeg, refBeamElDeg, ...
    targetInitialRangeM + uavSpeedMps*detectionDwellOffsetS);
uHatInbound = (droneStartPosition - bsPosition)/norm(droneStartPosition - bsPosition);
uavVelocity = -uavSpeedMps*uHatInbound;             % closing, purely radial
droneEndPosition = droneStartPosition + uavVelocity*simulationDuration;

droneTrajectory = waypointTrajectory( ...
    [droneStartPosition(:).'; droneEndPosition(:).'], ...
    [0 simulationDuration], ...
    'Velocities', [uavVelocity(:).'; uavVelocity(:).']);
targets.Trajectories = {droneTrajectory};

% ---- Fixed scenario extents, sized for the worst-case study range -------
% Use one scenario box for both 250 m and 750 m. If the box were allowed to
% auto-size independently for each range, a change in scenario geometry could
% become a confound in the range comparison.
scenarioExtentsMaxRangeM = 750;   % covers the farthest required benchmark range
scenarioExtentsMarginM   = 50;    % clearance beyond the farthest waypoint, on every side
droneStartPositionExtent = helperDirRangeToPosition(bsPosition, bsOrientationAxes, ...
    refBeamAzDeg, refBeamElDeg, ...
    scenarioExtentsMaxRangeM + uavSpeedMps*detectionDwellOffsetS);
uHatInboundExtent = (droneStartPositionExtent - bsPosition)/norm(droneStartPositionExtent - bsPosition);
droneEndPositionExtent = droneStartPositionExtent + (-uavSpeedMps*uHatInboundExtent)*simulationDuration;
scenarioPtsX = [bsPosition(1); txRUPosition(1); snifferRUPosition(1); ...
    droneStartPositionExtent(1); droneEndPositionExtent(1)];
scenarioPtsY = [bsPosition(2); txRUPosition(2); snifferRUPosition(2); ...
    droneStartPositionExtent(2); droneEndPositionExtent(2)];
scenarioLeftX   = min(scenarioPtsX) - scenarioExtentsMarginM;
scenarioRightX  = max(scenarioPtsX) + scenarioExtentsMarginM;
scenarioBottomY = min(scenarioPtsY) - scenarioExtentsMarginM;
scenarioTopY    = max(scenarioPtsY) + scenarioExtentsMarginM;
scenarioExtentsXY = [scenarioLeftX, scenarioBottomY, ...
    scenarioRightX - scenarioLeftX, scenarioTopY - scenarioBottomY];

% Precondition: THIS run's actual Tx/Rx/trajectory waypoints (whatever
% targetInitialRangeM is set to right now) must themselves fit inside the
% fixed extent above - guards against the extent and the study range list
% silently drifting apart (e.g. someone raises a study range past
% scenarioExtentsMaxRangeM without updating it here).
scenarioCheckPtsX = [bsPosition(1); txRUPosition(1); snifferRUPosition(1); ...
    droneStartPosition(1); droneEndPosition(1)];
scenarioCheckPtsY = [bsPosition(2); txRUPosition(2); snifferRUPosition(2); ...
    droneStartPosition(2); droneEndPosition(2)];
assert(all(scenarioCheckPtsX >= scenarioLeftX & scenarioCheckPtsX <= scenarioRightX) && ...
       all(scenarioCheckPtsY >= scenarioBottomY & scenarioCheckPtsY <= scenarioTopY), ...
    'Case2:scenarioExtentsTooSmall', ...
    ['targetInitialRangeM = %g m places the UAV/Tx/Rx outside the fixed ' ...
     'scenarioExtentsXY (sized for scenarioExtentsMaxRangeM = %g m with a ' ...
     '%g m margin) - raise scenarioExtentsMaxRangeM to cover it.'], ...
    targetInitialRangeM, scenarioExtentsMaxRangeM, scenarioExtentsMarginM);

%% ===================== 8. TRACK dwell schedule (baseline 14T-b/c) =======
% 40 ms -> 4 frames, 80 slow-time slots, 64 PRS occasions, 25 Hz Doppler
% resolution, +-1000 Hz unambiguous. Everything is derived from
% trackingCPI_DurationMs (declared in Section 1).
trackNumFrames = round(trackingCPI_DurationMs/(frameDuration*1e3));
trackNumSlots  = trackNumFrames*numSlotsPerFrame;
assert(trackNumFrames >= 1 && ...
    abs(trackNumFrames*frameDuration*1e3 - trackingCPI_DurationMs) < 1e-9, ...
    'Case2:badDwell', ...
    ['The dwell must be a whole number of %.1f ms frames; %.3f ms is not ' ...
     '(nearest is %d frames = %.3f ms).'], frameDuration*1e3, ...
    trackingCPI_DurationMs, trackNumFrames, trackNumFrames*frameDuration*1e3);
trackStartTime = detectionDwellOffsetS;

trackPRSSlotsPerFrame = zeros(1, 0);
for p = 0:(numSlotsPerFrame/tddPeriodSlots - 1)
    trackPRSSlotsPerFrame = [trackPRSSlotsPerFrame, ...
        prsCapableLocalSlots + p*tddPeriodSlots]; %#ok<AGROW>
end
trackPRSSlotsPerFrame = sort(trackPRSSlotsPerFrame);
trackPRSSlotOffsets = zeros(1, 0);
for f = 0:(trackNumFrames-1)
    trackPRSSlotOffsets = [trackPRSSlotOffsets, ...
        trackPRSSlotsPerFrame + f*numSlotsPerFrame]; %#ok<AGROW>
end
trackNumPRSResources = numel(trackPRSSlotOffsets);

% Slow-time Doppler axis.
trackFsDoppler   = 1/slotDurationS;                      % 2 kHz
trackDopplerHz   = (-trackNumSlots/2 : trackNumSlots/2 - 1)*(trackFsDoppler/trackNumSlots);
dopplerResHz     = trackFsDoppler/trackNumSlots;         % 25 Hz at 40 ms
dopplerUnambigHz = trackFsDoppler/2;                     % +-1000 Hz

% Legacy CA-CFAR construction removed. spatial ACE owns thresholding.

assert(isequal(trackPRSSlotsPerFrame, [0 1 2 3 5 6 7 8 10 11 12 13 15 16 17 18]), ...
    'Case2:trackPRSSlotSetChanged', ...
    'On the shipped baseline the TRACK PRS slots must be the expected set (got %s).', ...
    mat2str(trackPRSSlotsPerFrame));
assert(trackNumPRSResources == numel(trackPRSSlotsPerFrame)*trackNumFrames, ...
    'Case2:trackBadResourceCount', ...
    'Expected %d TRACK PRS occasions (%d per frame x %d frames), got %d.', ...
    numel(trackPRSSlotsPerFrame)*trackNumFrames, numel(trackPRSSlotsPerFrame), ...
    trackNumFrames, trackNumPRSResources);
assert(max(trackPRSSlotOffsets) < trackNumSlots, 'Case2:trackPRSOutsideWindow', ...
    'The TRACK PRS schedule does not fit the %d-slot window.', trackNumSlots);

prsTrack = nrPRSConfig;
prsTrack.PRSResourceSetPeriod  = [trackNumSlots 0];
prsTrack.PRSResourceOffset     = trackPRSSlotOffsets;
prsTrack.PRSResourceRepetition = 1;
prsTrack.SymbolStart           = symStartPattern*ones(1, trackNumPRSResources);
prsTrack.NumPRSSymbols         = prs.NumPRSSymbols*ones(1, trackNumPRSResources);
prsTrack.REOffset              = zeros(1, trackNumPRSResources);
prsTrack.NumRB                 = prs.NumRB;
prsTrack.RBOffset              = prs.RBOffset;
prsTrack.CombSize              = prs.CombSize;
prsTrack.NPRSID                = prs.NPRSID;
assert(prsTrack.CombSize == prs.CombSize && ...
       all(prsTrack.NumPRSSymbols == prs.NumPRSSymbols) && ...
       all(prsTrack.SymbolStart == 6), 'Case2:trackPRSNumerologyChanged', ...
    'TRACK PRS must match the base config: L_PRS = %d, CombSize = %d, SymbolStart = 6.', ...
    prs.NumPRSSymbols, prs.CombSize);

% Actual PRS timestamps (slots 0,1,2,3,5,... -> 0.5 or 1.0 ms spacings).
% Every Doppler phase in this file uses these. prsTimesS is the centroid of
% the L merged symbols of each occasion.
cpLensSlot = double(waveformInfo.CyclicPrefixLengths);
cpLensSlot = cpLensSlot(1:symbolsPerSlot);
symLensSlot = cpLensSlot + waveformInfo.Nfft;
prsSymbolStartsS = cumsum([0, symLensSlot(:).'])/waveformInfo.SampleRate;
prsSymbolIdx     = symStartPattern + (0:prs.NumPRSSymbols-1);
prsSymbolTimeOffsetS = mean(prsSymbolStartsS(prsSymbolIdx + 1) + ...
    0.5*symLensSlot(prsSymbolIdx + 1)/waveformInfo.SampleRate);
prsTimesS = trackPRSSlotOffsets*slotDurationS + prsSymbolTimeOffsetS;   % 1 x 64
prsDtS = diff(prsTimesS);                                              % 1 x 63
assert(all(prsDtS > 0), 'Case2:prsTimesNotIncreasing', ...
    'PRS timestamps must be strictly increasing.');
rangeCPLimitM = (cpLensSlot(symStartPattern+1)/waveformInfo.SampleRate)*propagationSpeed/2;

%% ===================== 9. Fixed evaluation beam and truth ===============
% Ground truth picks the fixed evaluation beam (bStar). Not a search experiment.
cpiMidTimeS = trackStartTime + 0.5*trackNumFrames*frameDuration;
[truthRangeEqM, truthPosition] = helperTargetRangeTruth(droneTrajectory, ...
    cpiMidTimeS, txRUPosition, snifferRUPosition);
[~, truthAngles] = rangeangle(truthPosition(:), bsPosition, bsOrientationAxes);
[~, bStar] = min(hypot(scanAngles(1,:) - truthAngles(1), ...
                       scanAngles(2,:) - truthAngles(2)));

wtxTrack = repmat(wtxAll(:, bStar), 1, trackNumPRSResources);
assert(max(max(abs(wtxTrack - wtxAll(:, bStar)))) == 0, ...
    'Case2:trackBeamNotFrozen', ...
    'Every TRACK PRS resource must carry the IDENTICAL b* beam weight.');

%% ---- Active receive-chain basis and validation beam -------------------
% The primary detector never beamforms to one scalar stream. Bactive is only
% the 64-port -> 32-chain virtualization used by both ACE methods. wrxConv is
% retained solely for the single-symbol range-helper regression in Section 11.
Bactive = virtualizationB(:,rxChains);
nActiveRx = numel(rxChains);
assert(norm(Bactive'*Bactive-eye(nActiveRx))<1e-9,'Case2:BactiveNotOrthonormal', ...
    'The active receive-chain basis must be orthonormal.');
aTarget = rxSteeringVector(carrierFrequency,scanAngles(:,bStar));
aTchain = Bactive'*aTarget;
wrxConv = Bactive*(aTchain/norm(aTchain));
wrxConv = wrxConv/norm(wrxConv);
assert(all(isfinite(wrxConv)) && abs(norm(wrxConv)-1)<1e-12, ...
    'Case2:badValidationBeam','Validation beam must be finite and unit norm.');

% Doppler truth, exact two-leg bistatic.
[~, ~, vTruth] = lookupPose(droneTrajectory, cpiMidTimeS);
uTx = (truthPosition(:) - txRUPosition)/norm(truthPosition(:) - txRUPosition);
uRx = (truthPosition(:) - snifferRUPosition)/norm(truthPosition(:) - snifferRUPosition);
truthDopplerHz     = -(vTruth(:).'*uTx + vTruth(:).'*uRx)/wavelength;
truthDopplerMonoHz = -2*(vTruth(:).'*uTx)/wavelength;

% ---- UE link (deviation 2) --------------------------------------------
ueRxArray = phased.ULA(2, wavelength/2, 'Element', phased.IsotropicAntennaElement);
plConfig = nrPathLossConfig; plConfig.Scenario = 'UMa';
uePathLossdB = nrPathLoss(plConfig, carrierFrequency, true, bsPosition(:), uePosition(:));
[~, ueAngles] = rangeangle(uePosition(:), bsPosition, bsOrientationAxes);
uePre = conj(virtualizationB.' * txSteeringVector(carrierFrequency, ueAngles(:)));
ueTxPrecoder = (virtualizationB*(uePre/norm(uePre))).';
ueChannelTrack = helperCreateUECDLChannel(cdlProfile, cdlDelaySpread, ueSpeed, ...
    wavelength, carrierFrequency, waveformInfo.SampleRate, ueChannelSeed, ...
    txArray, ueRxArray, uePosition, bsPosition);
ueLinkTrack = struct('Channel', ueChannelTrack, 'PathLossdB', uePathLossdB, ...
    'NoiseFigure', ueNoiseFigure, 'NoiseSeed', ueNoiseSeed, ...
    'PDSCHPrecoder', ueTxPrecoder, 'PDSCHBeamMode', pdschBeamMode);

%% ===================== 10. Frame and sensing replays ====================
waveformConfigTrack = waveformConfig;
waveformConfigTrack.NFrames = trackNumFrames;
tddSymbolTypesTrack = cell(1, trackNumSlots);
for s = 0:trackNumSlots-1
    tddSymbolTypesTrack{s+1} = helperTDDSymbolTypes( ...
        helperTDDSlotDirection(s, tddPattern), symbolsPerSlot, tddSpecialSlotFormat);
end

fprintf('Generating the dwell frame (PDSCH/DM-RS + %d PRS)...\n', trackNumPRSResources);
[frameTxTrack, ~] = helperGenerateISACFrame(waveformConfigTrack, prsTrack, ...
    wtxTrack, txPower, ueLinkTrack, dataSeedBase + 1, false, [], tddSymbolTypesTrack);
release(ueChannelTrack);
assert(frameTxTrack.NumPRSResources == trackNumPRSResources, ...
    'Case2:trackFrameResourceMismatch', ...
    'The TRACK frame produced %d PRS resources, expected %d.', ...
    frameTxTrack.NumPRSResources, trackNumPRSResources);

% ---- REPLAY-CACHE FINGERPRINT ---------------------------------------
% Every parameter that can change the received samples. Compared with
% isequal on each cache load; a field left out here is a stale cache waiting
% to be believed. frameChecksum stands in for the whole transmitted frame.
frameChecksum = [double(frameTxTrack.NumPRSResources), ...
                 numel(frameTxTrack.PRSResourcesTx(1).prsSymbols), ...
                 sum(real(frameTxTrack.PRSResourcesTx(1).prsSymbols(:))), ...
                 sum(imag(frameTxTrack.PRSResourcesTx(1).prsSymbols(:))), ...
                 sum(double(frameTxTrack.PRSResourcesTx(1).kPRS(:))), ...
                 sum(double(frameTxTrack.PRSSlotOffsets(:))), ...
                 sum(frameTxTrack.PRSREPerSlot(:))];
replayBaseParams = struct( ...
    'fc', carrierFrequency, 'fs', waveformInfo.SampleRate, ...
    'scs', subcarrierSpacing, 'nRB', prs.NumRB, ...
    'combSize', prs.CombSize, 'numPRSSym', prs.NumPRSSymbols, ...
    'symStart', symStartPattern, 'cpiMs', trackingCPI_DurationMs, ...
    'nFrames', trackNumFrames, 'nPRSRes', trackNumPRSResources, ...
    'txPos', txRUPosition(:).', 'rxPos', snifferRUPosition(:).', ...
    'uraSize', uraSize, 'nRFChains', numRFChains, ...
    'boresight', [physicalBoresightAzDeg physicalBoresightElDeg], ...
    'beamAz', scanAngles(1, bStar), 'beamEl', scanAngles(2, bStar), ...
    'uavSpeed', uavSpeedMps, 'uavRange0', targetInitialRangeM, ...
    'acqSpan', detectionDwellOffsetS, ...
    'chSeed', channelSeedCommon, 'nf', rxNoiseFigure, ...
    'tpo', targetPowerOffsetdB, 'los', losProbability, ...
    'txPower', txPower, 'frameChecksum', frameChecksum, ...
    'scenarioExtentsXY', scenarioExtentsXY);

% THE COMPOSITE CASE 2 REPLAY - the only one the algorithm ever sees.
dbg_('Replaying: CASE 2 composite (target + background + noise)...\n');
pFull = replayBaseParams;
pFull.startTime = trackStartTime; pFull.noiseSeed = sensingNoiseSeed;
pFull.targetOn = true; pFull.backgroundOn = true;
[YportFull, Xprs, kPRSabs, slotOfObs, metaFull] = helperCachedReplaySnapshots( ...
    'full', pFull, cacheCfg, ...
    @() helperReplayCase2(frameTxTrack, waveformConfigTrack, rxNoiseFigure, ...
        targets, trackStartTime, sensingNoiseSeed, txRUPosition, snifferRUPosition, ...
        txArray, txOrientation, rxArray, rxOrientation, carrierFrequency, ...
        waveformInfo.SampleRate, droneTrajectory, true, true, channelSeedCommon, ...
        targetPowerOffsetdB, losProbability, scenarioExtentsXY), ...
    trackNumPRSResources, true);

% Offline diagnostic replay (same noise seed -> B = Y_full - Y_Tonly is
% exact). Feeds the component diagnostics only.
dbg_('Replaying: target-only (offline diagnostic)...\n');
pTgt = replayBaseParams;
pTgt.startTime = trackStartTime; pTgt.noiseSeed = sensingNoiseSeed;
pTgt.targetOn = true; pTgt.backgroundOn = false;
YportTgt = helperCachedReplaySnapshots('tgt', pTgt, cacheCfg, ...
    @() helperReplayCase2(frameTxTrack, waveformConfigTrack, rxNoiseFigure, ...
        targets, trackStartTime, sensingNoiseSeed, txRUPosition, snifferRUPosition, ...
        txArray, txOrientation, rxArray, rxOrientation, carrierFrequency, ...
        waveformInfo.SampleRate, droneTrajectory, true, false, channelSeedCommon, ...
        targetPowerOffsetdB, losProbability, scenarioExtentsXY), ...
    trackNumPRSResources, false);

% Background-only replay: OFF by default (B = Y_full - Y_Tonly is exact).
% With it off, T and N are NOT separated: the "target component" downstream
% is T + N, and N is treated as identically zero (the noise floor is
% measured separately, from the target-only map away from the target).
% 2026-09-18: wrapped in helperCachedReplaySnapshots (same as 'full'/'tgt'
% above) - previously this called helperReplayCase2 directly with NO cache
% at all, so every run with runBackgroundOnlyReplay=true re-replayed from
% scratch even on an exact repeat of the same seed/scenario. Tag 'bg', same
% cacheCfg.dir (already keyed per seed), so no collision with 'full'/'tgt'.
if diagCfg.runBackgroundOnlyReplay
    dbg_('Replaying: background-only (offline diagnostic)...\n');
    pBg = replayBaseParams;
    pBg.startTime = trackStartTime; pBg.noiseSeed = sensingNoiseSeed;
    pBg.targetOn = false; pBg.backgroundOn = true;
    YportBgReplayed = helperCachedReplaySnapshots('bg', pBg, cacheCfg, ...
        @() helperReplayCase2(frameTxTrack, waveformConfigTrack, rxNoiseFigure, ...
            targets, trackStartTime, sensingNoiseSeed, txRUPosition, snifferRUPosition, ...
            txArray, txOrientation, rxArray, rxOrientation, carrierFrequency, ...
            waveformInfo.SampleRate, droneTrajectory, false, true, channelSeedCommon, ...
            targetPowerOffsetdB, losProbability, scenarioExtentsXY), ...
        trackNumPRSResources, false);
else
    dbg_(['Background-only replay SKIPPED (diagCfg.runBackgroundOnlyReplay = false).\n' ...
             '  B = Y_full - Y_Tonly is exact; T and N are NOT separated, so the\n' ...
             '  target component carries the thermal noise with it.\n']);
    YportBgReplayed = [];
end
fprintf('[TIMING] after Section 10 (replays): cum %.2fs\n', toc(runWallTic_));   % runtime checkpoint


%% ===================== 11. PRS frequency-domain matrices ================
% Yprs / Xprs are built before the range IFFT and are used to reproduce the
% exact PRS range-processing path. Raw port-domain snapshots (YportFull/Tgt)
% come from the Section 10 replays before beamforming.
if isempty(YportBgReplayed)
    YportBg = YportFull - YportTgt;      % exact background; noise folds into the target component
    haveNoiseSplit = false;
else
    YportBg = YportBgReplayed;           % already built by helperCachedReplaySnapshots above
    haveNoiseSplit = true;
end
assert(size(YportFull, 1) == numRadiatingPorts, 'Case2:snapshotPortCount', ...
    'The raw snapshots have %d ports, expected %d.', ...
    size(YportFull, 1), numRadiatingPorts);
assert(isequal(size(YportFull), size(YportTgt), size(YportBg)), ...
    'Case2:snapshotShapeMismatch', 'The three replays gave different shapes.');

% Machinery checks run on the conventional beam; Section 11b re-derives these
% matrices through the primary weight.
Yprs    = helperBeamformSnapshots(YportFull, wrxConv);
YprsTgt = helperBeamformSnapshots(YportTgt,  wrxConv);
YprsBg  = helperBeamformSnapshots(YportBg,   wrxConv);

assert(isequal(size(Yprs), size(Xprs)), 'Case2:prsSizeMismatch', ...
    'Yprs and Xprs must have the same size.');
assert(size(Yprs,1) == nToneRange && size(Yprs,2) == trackNumPRSResources, ...
    'Case2:prsMatrixShape', 'Yprs must be %d x %d, got %d x %d.', ...
    nToneRange, trackNumPRSResources, size(Yprs,1), size(Yprs,2));
assert(all(abs(Xprs(:)) > eps), 'Case2:prsZeroDenominator', ...
    'A transmitted PRS symbol is zero on the extracted active PRS tones.');
assert(all(isfinite(Yprs(:))) && all(isfinite(Xprs(:))), 'Case2:prsNonFinite', ...
    'Yprs/Xprs contain non-finite entries.');
assert(isequal(slotOfObs, trackPRSSlotOffsets), 'Case2:obsSlotOrderMismatch', ...
    'The PRS observation order does not match the derived slot schedule.');

% Offline components in the PRS frequency domain, additive by construction:
%   Y_full = Y_target + Y_background + Y_noise
% When the background-only replay is skipped (default), YprsN is identically
% zero and YprsB is still exact; YprsT then also carries the thermal noise.
YprsT = Yprs - YprsBg;                    % target (+ noise, if not split)
YprsB = Yprs - YprsTgt;                   % background - EXACT either way
YprsN = YprsTgt + YprsBg - Yprs;          % noise (identically 0 if not split)
if haveNoiseSplit
    componentLabelT = 'target component';
else
    componentLabelT = 'target-plus-noise diagnostic component';
end
componentIsExactT = haveNoiseSplit;
Nprs      = YprsN;                        % local, for the noise-flatness check
% DtrueRef and sigmaN2 are assigned in Section 11b, once the primary weight is
% chosen.

% Additivity residual - an algebraic identity, computed only as an upstream guard.
decompResidualDB = 10*log10( ...
    max(sum(abs(Yprs - (YprsT + YprsB + YprsN)).^2, 'all'), realmin) / ...
    max(sum(abs(Yprs).^2, 'all'), realmin));
assert(decompResidualDB < -100, 'Case2:decompositionNotAdditive', ...
    'The PRS-domain component decomposition is not additive (%.1f dB).', ...
    decompResidualDB);
% Noise-flatness diagnostic: a broken decomposition would leave channel
% structure in Nprs and its per-occasion power would vary.
nColPow   = mean(abs(Nprs).^2, 1);
if haveNoiseSplit
    noiseFlatnessDB = 10*log10(max(nColPow)/max(min(nColPow), realmin));
else
    noiseFlatnessDB = NaN;      % no separated noise component to check
end

% Relative comb index and absolute tone frequency, matching
% helperPRSRangeProfilesResourceSniffer exactly.
nRelPRS = (kPRSabs - min(kPRSabs))/combStepPRS;
assert(isequal(sort(nRelPRS(:)).', 0:(nToneRange-1)), 'Case2:badCombIndexMapping', ...
    'The PRS tones do not map onto a contiguous comb index 0..%d.', nToneRange-1);
fAbsPRS = (kPRSabs - 1 - numSubcarriers/2)*subcarrierSpacing*1e3;
tFilterDelayS = metaFull.ChannelFilterDelay/metaFull.SampleRate;

% Range-arithmetic check: process only the first PRS symbol's tones with the
% per-symbol comb parameters and require a bit-for-bit match against the
% shipped helper. Catches drift in the range transform, filter-delay ramp or
% normalization. (The merged L-symbol profile is a different quantity and is
% not compared here.)
firstSymbolTones = mod(kPRSabs - min(kPRSabs), prs.CombSize) == 0;
assert(sum(firstSymbolTones) == prs.NumRB*12/prs.CombSize, ...
    'Case2:firstSymbolToneCount', ...
    'Expected %d tones on the first comb offset, found %d.', ...
    prs.NumRB*12/prs.CombSize, sum(firstSymbolTones));
nRelFirst  = (kPRSabs(firstSymbolTones) - min(kPRSabs))/prs.CombSize;
nToneFirst = sum(firstSymbolTones);
nIFFTFirst = rangeIFFTZeroPadFactor*nToneFirst;
rangeProcCfgFirst = struct('combSize', prs.CombSize, 'nTone', nToneFirst, ...
                           'nIFFT', nIFFTFirst);
RvalidCheck = helperRangeFromPRS(Yprs(firstSymbolTones, :), ...
    Xprs(firstSymbolTones, :), nRelFirst, fAbsPRS(firstSymbolTones), ...
    tFilterDelayS, nToneFirst, nIFFTFirst, numRangeBins);
[~, rRef] = helperPRSRangeProfilesResourceSniffer(metaFull.res1, ...
    metaFull.ChannelFilterDelay, metaFull.SampleRate, wrxConv, rangeGrid, ...
    propagationSpeed, subcarrierSpacing*1e3, numSubcarriers, rangeProcCfgFirst);
rangeReplicaResidualDB = 10*log10( ...
    max(sum(abs(RvalidCheck(:,1) - rRef(:,1)).^2), realmin) / ...
    max(sum(abs(rRef(:,1)).^2), realmin));
assert(rangeReplicaResidualDB < -100, 'Case2:rangePipelineMismatch', ...
    ['The replicated range processing does not reproduce ' ...
     'helperPRSRangeProfilesResourceSniffer (%.1f dB).'], rangeReplicaResidualDB);


%% ===================== 12. PRIMARY SPATIAL-ACE BENCHMARK ==============
% All detectors use identical post-Doppler data, NSCM, shrinkage loading,
% leakage exclusion and ACE equations. They differ only in covariance reuse:
%   Full sliding : B=1, one covariance per CUT and Doppler bin
%   Block-B      : one covariance per B adjacent range CUTs and Doppler bin
% Thresholds are fitted independently from H0 calibration maps at one common
% map-level false-alarm target and then evaluated on separate H0 validation maps.
% H1 data never enters threshold selection.
benchmarkCfg = struct;
% Method names follow the configured block sizes so the two cannot disagree.
benchmarkCfg.MethodNames = ["Full sliding NSCM-ACE", ...
    compose("Block-%d NSCM-ACE",spatialAceCfg.BlockSizesRangeBins(:).')];
benchmarkCfg.MapPfaTarget = spatialAceCfg.MapPfaTarget;
benchmarkCfg.NumH0Calibration = max(spatialAceCfg.NumCalibrationFolds, round(spatialAceCfg.NumH0Calibration));
benchmarkCfg.NumH0Validation = max(1, round(spatialAceCfg.NumH0Validation));
benchmarkCfg.NumCalibrationFolds = round(spatialAceCfg.NumCalibrationFolds);
benchmarkCfg.NumTrainingCells = spatialAceCfg.NumTrainingCells;
benchmarkCfg.BlockSizesRangeBins = spatialAceCfg.BlockSizesRangeBins;
benchmarkCfg.ExclusionBins = spatialAceCfg.ExclusionBins;
benchmarkCfg.NumH1Trials = max(1, round(adaptCfg.numTrialsH1RealGeo));
benchmarkCfg.NumSweepTrials = max(1, round(adaptCfg.numTrialsSweep));
benchmarkCfg.PowerSweepEnable = true;
benchmarkCfg.TargetPowerOffsetDB = targetPowerOffsetDB;
benchmarkCfg.Seed = adaptCfg.seed + 40;
benchmarkCfg.AssociationRangeBins = spatialAceCfg.associationRangeBins;
benchmarkCfg.AssociationDopplerBins = spatialAceCfg.associationDopplerBins;
benchmarkCfg.CILevel = adaptCfg.ciLevel;
benchmarkCfg.DumpCubesTo = "";
if exist('validationOverride','var') && isstruct(validationOverride) && ...
        isfield(validationOverride,'dumpCubesTo')
    benchmarkCfg.DumpCubesTo = string(validationOverride.dumpCubesTo);
end

assert(haveNoiseSplit,'Case2:benchmarkNeedsNoiseSplit', ...
    ['The primary benchmark requires full, target-only and background-only replays ' ...
     'with the same thermal-noise seed. Set diagCfg.runBackgroundOnlyReplay=true.']);
assert(nActiveRx == numRFChains,'Case2:benchmarkActiveChainCount', ...
    'The benchmark requires all %d receive chains; found %d.',numRFChains,nActiveRx);
% K >= 2N is the Reed-Mallett-Brennan reference point, not a requirement of
% this implementation. helperNSCM is trace-normalised so tau=1 at every K and
% helperShrinkageLoading adds lambda*tau*I with lambda>0, so the loaded
% covariance is positive definite for any K; the Cholesky asserts inside the
% detectors still verify it. K below 2N is therefore admitted and what it
% costs is recorded through the condition-number and loading diagnostics.
assert(mod(benchmarkCfg.NumTrainingCells,2)==0 && benchmarkCfg.NumTrainingCells>=2, ...
    'Case2:benchmarkInsufficientTraining', ...
    'Need an even K >= 2. K=%d.',benchmarkCfg.NumTrainingCells);
if benchmarkCfg.NumTrainingCells < 2*nActiveRx
    warning('Case2:benchmarkBelowRMB', ...
        'K=%d is below the RMB reference 2N=%d; covariance conditioning is degraded.', ...
        benchmarkCfg.NumTrainingCells,2*nActiveRx);
end
assert(all(benchmarkCfg.BlockSizesRangeBins>=1) && ...
       all(mod(benchmarkCfg.BlockSizesRangeBins,1)==0), ...
    'Case2:benchmarkBlockSize', ...
    'Every BlockSizesRangeBins entry must be a positive integer.');

% Truth bins are common geometry/grid quantities, not outputs of a detector.
[~,riTruth] = min(abs(rangeGridNative-truthRangeEqM));
[~,qiTruth] = min(abs(trackDopplerHz-truthDopplerHz));

% Exact simulation-only component split. The detector never receives these
% labels; they are used only to construct controlled H0 and H1 trials.
YportNExact = YportTgt + YportBg - YportFull;
YportTExact = YportTgt - YportNExact;
YportBExact = YportBg  - YportNExact;
splitResid = YportFull-(YportTExact+YportBExact+YportNExact);
splitResidRel = norm(splitResid(:))/max(norm(YportFull(:)),realmin);
assert(splitResidRel < 1e-10,'Case2:componentSplit', ...
    'Raw component reconstruction relative residual %.3e exceeds 1e-10.',splitResidRel);

% Physical ports -> active RF-chain domain. No MVDR or conventional receive
% beamforming is applied before ACE.
YchainT = permute(pagemtimes(Bactive',YportTExact),[2 3 1]);
YchainB = permute(pagemtimes(Bactive',YportBExact),[2 3 1]);
YchainN = permute(pagemtimes(Bactive',YportNExact),[2 3 1]);
assert(size(YchainT,3)==nActiveRx,'Case2:chainProjection', ...
    'Active-chain projection produced %d channels; expected %d.',size(YchainT,3),nActiveRx);
sigmaChain2 = mean(abs(YchainN).^2,'all');
assert(isfinite(sigmaChain2) && sigmaChain2>0,'Case2:noisePower', ...
    'Measured active-chain thermal-noise power must be finite and positive.');

% Blind angle hypotheses come from the existing receive search codebook.
spatialSteeringPorts = rxSteeringVector(carrierFrequency,scanAngles);
spatialSteeringChain = Bactive'*spatialSteeringPorts;
for iAng=1:size(spatialSteeringChain,2)
    spatialSteeringChain(:,iAng)=spatialSteeringChain(:,iAng)/max(norm(spatialSteeringChain(:,iAng)),realmin);
end

% Every method uses one common CUT support. Its width follows from what the
% detectors actually require, which is E + K/2 on each side and nothing more.
% helperBlockSharedNSCMACE binds only on its first block (lo = cutIdx(1)) and
% its last block (hi = cutIdx(end)); every interior block sits well inside
% those two. Its two asserts therefore reduce to the same pair that
% helperFullSlidingNSCMACE applies, so the block size does not enter. An
% earlier revision added a (maxBlockSize-1) margin here, which cost 7 bins at
% each edge for B=8 without being required by any detector. No detector clips
% or shortens its window at the range-grid edges.
spatialHalfWindow=benchmarkCfg.ExclusionBins ...
    +benchmarkCfg.NumTrainingCells/2;
spatialCutIdxNative=cutIdxNative(cutIdxNative>spatialHalfWindow & ...
    cutIdxNative<=numNativeBins-spatialHalfWindow);
truthRowSpatial=find(spatialCutIdxNative==riTruth,1);
assert(~isempty(truthRowSpatial),'Case2:truthOutsideSpatialCUT', ...
    'Truth range %.3f m is outside the common ACE CUT support.',truthRangeEqM);

baselineAceCfg=struct('NumTrainingCells',benchmarkCfg.NumTrainingCells, ...
    'ExclusionBins',benchmarkCfg.ExclusionBins);
blockAceCfg=repmat(struct('NumTrainingCells',benchmarkCfg.NumTrainingCells, ...
    'BlockSizeRangeBins',0,'ExclusionBins',benchmarkCfg.ExclusionBins), ...
    1,numel(benchmarkCfg.BlockSizesRangeBins));
for iBlockCfg=1:numel(blockAceCfg)
    blockAceCfg(iBlockCfg).BlockSizeRangeBins=benchmarkCfg.BlockSizesRangeBins(iBlockCfg);
end

fprintf('\n================ PRIMARY DETECTION BENCHMARK ================\n');
fprintf('Range truth / native cell    : %.3f / %.3f m\n',truthRangeEqM,rangeGridNative(riTruth));
fprintf('Doppler truth / grid cell    : %+.3f / %+.3f Hz\n',truthDopplerHz,trackDopplerHz(qiTruth));
fprintf('Range IFFT zero padding      : x%d (detection uses native bins)\n',rangeIFFTZeroPadFactor);
fprintf('Methods                      : %s\n',strjoin(benchmarkCfg.MethodNames,' | '));
fprintf('Full sliding window          : %d training, %d exclusion bins, one covariance per CUT\n', ...
    benchmarkCfg.NumTrainingCells,benchmarkCfg.ExclusionBins);
fprintf('Block windows                : %d training, %d exclusion bins, block sizes [%s]\n', ...
    benchmarkCfg.NumTrainingCells,benchmarkCfg.ExclusionBins, ...
    char(strjoin(string(benchmarkCfg.BlockSizesRangeBins),', ')));
fprintf('Common CUT half-window       : %d bins -> %d CUT cells\n', ...
    spatialHalfWindow,numel(spatialCutIdxNative));
fprintf('Map-level Pfa target         : %.3f\n',benchmarkCfg.MapPfaTarget);
fprintf('H0 calibration / validation : %d / %d maps\n', ...
    benchmarkCfg.NumH0Calibration,benchmarkCfg.NumH0Validation);
fprintf('Calibration folds / H1       : %d / %d trials\n', ...
    benchmarkCfg.NumCalibrationFolds,benchmarkCfg.NumH1Trials);

results = helperRunSpatialACEBenchmark_(YchainT,YchainB,sigmaChain2,Xprs, ...
    nRelPRS,fAbsPRS,tFilterDelayS,nToneRange,nIFFTRange,numRangeBins,nativeIdx, ...
    rangeGridNative,spatialCutIdxNative,prsTimesS,trackDopplerHz,spatialSteeringChain, ...
    truthRangeEqM,truthDopplerHz,truthRowSpatial,qiTruth,benchmarkCfg, ...
    baselineAceCfg,blockAceCfg);

fprintf('\n---------------- HEADLINE RESULTS ----------------\n');
fprintf('CP-equivalent one-way range : %.3f m (truth/CP = %.3f)\n', ...
    rangeCPLimitM,truthRangeEqM/rangeCPLimitM);
for iMethod=1:numel(results.Method)
    r=results.Method(iMethod);
    fprintf('%s\n',r.Name);
    fprintf('  empirical threshold        : %.8f\n',r.Threshold);
    fprintf('  calibration Pfa_map        : %.4f (%d H0 calibration maps)\n', ...
        r.CalibrationPfaMap,r.NumH0Calibration);
    fprintf('  cross-fitted Pfa_map       : %.4f, 95%% CI [%.4f, %.4f] (%d/%d maps, %d folds)\n', ...
        r.CrossFittedPfaMap,r.CrossFittedPfaMapCI(1),r.CrossFittedPfaMapCI(2), ...
        r.CrossFittedFalseAlarmMaps,r.NumH0Calibration,r.NumCalibrationFolds);
    fprintf('  Pfa_cell (validation)      : %.3e\n',r.PfaCell);
    fprintf('  Pfa_map (validation)       : %.4f (%d/%d maps)\n',r.PfaMap,r.NumFalseAlarmMaps,r.NumH0Validation);
    fprintf('  E[N_FA/map]                : %.4f\n',r.MeanFalseAlarmsPerMap);
    fprintf('  Pd associated              : %.4f, %.0f%% CI [%.4f, %.4f] (%d/%d)\n', ...
        r.PdAssociated,100*benchmarkCfg.CILevel,r.PdAssociatedCI(1),r.PdAssociatedCI(2), ...
        r.NumDetAssociated,r.NumH1);
    fprintf('  Pd exact-bin               : %.4f, %.0f%% CI [%.4f, %.4f] (%d/%d)\n', ...
        r.PdExact,100*benchmarkCfg.CILevel,r.PdExactCI(1),r.PdExactCI(2),r.NumDetExact,r.NumH1);
    fprintf('  H0 association-gate rate   : %.4f\n',r.H0AssociationGateRate);
    fprintf('  associated range RMSE      : %.4f m (%d associated detections)\n',r.RangeRMSEm,r.NumRMSESamples);
    fprintf('  associated Doppler RMSE    : %.4f Hz (%d associated detections)\n',r.DopplerRMSEHz,r.NumRMSESamples);
end
cd=results.ClutterDiagnostics;
fprintf('Shared pre-ACE target/background/noise power at truth: %+.2f / %+.2f / %+.2f dB\n', ...
    10*log10(max(results.TargetPowerTruth,realmin)),10*log10(max(results.BackgroundPowerTruth,realmin)), ...
    10*log10(max(results.NoisePowerTruth,realmin)));
fprintf('Shared pre-ACE SCNR at truth  : %+.2f dB\n',results.SCNR0dB);
fprintf('Shared pre-ACE SCNR peak/gate : %+.2f / %+.2f dB\n', ...
    results.SCNRPeakCellDB,results.SCNRGateDB);
fprintf('Fractional range-bin offset    : %.3f bin\n',results.FractionalRangeBinOffset);
fprintf('Target range energy in +/-1 gate: %.4f\n',results.TargetRangeGateCaptureFraction);
fprintf('Clutter peak                   : %+.2f dB at %.3f m, %+.3f Hz\n', ...
    cd.PeakPowerDB,cd.PeakRangeM,cd.PeakDopplerHz);
fprintf('Clutter median / P95           : %+.2f / %+.2f dB\n',cd.MedianPowerDB,cd.P95PowerDB);
fprintf('Clutter truth-cell power       : %+.2f dB\n',cd.TruthCellPowerDB);
cx=results.Complexity;
for iComplexity=1:numel(cx.Method)
    cm=cx.Method(iComplexity);
    fprintf('Complexity %-20s : %d cov/map, %.3f s/map, %.2fx speedup vs Full\n', ...
        char(cm.Name),cm.NumCovarianceEstimatesPerMap,cm.SecondsPerMap,cm.MeasuredSpeedupVsFull);
end
for iDiag=1:numel(results.CovarianceReuseDiagnostics)
    dCov=results.CovarianceReuseDiagnostics(iDiag);
    fprintf('Covariance mismatch %-14s : median %.4f, P95 %.4f, max %.4f\n', ...
        char(dCov.Name),dCov.MedianRelativeFrobeniusMismatch, ...
        dCov.P95RelativeFrobeniusMismatch,dCov.MaxRelativeFrobeniusMismatch);
end
lk=results.TargetLeakageProfile;
fprintf('Target leakage half-width      : %d bins at -40 dB (exclusion configured %d bins)\n', ...
    lk.HalfWidthBinsAt40dB,cx.ExclusionBins);
cdg=results.TrainingContaminationDiagnostics;
fprintf('Training-contamination diagnostic: same K, NSCM, shrinkage and ACE; E/g are diagnostic only\n');
for iE=1:numel(cdg.ExclusionBins)
    for iG=1:numel(cdg.TargetGainDB)
        de=cdg.Entry(iE,iG);
        if de.ExclusionBins==cx.ExclusionBins || de.ExclusionBins==6
            fprintf(['  E=%2d g=%+3.0f dB: C_M %.4g, C_inv %.4g, dir %.4g, ' ...
                'ACE ratio %.4f (%+.3f dB), SINR loss(best) %.3f dB\n'], ...
                de.ExclusionBins,de.TargetGainDB,de.RelativeFrobeniusPerturbation, ...
                de.RelativeInversePerturbation,de.MaxAbsDirectionalPerturbation, ...
                de.ACEContaminatedToBackgroundRatio,de.ACEChangeDB, ...
                de.AdaptiveSINRLossAtBackgroundBestAngleDB);
        end
    end
end
if ~isempty(cdg.GeometryComparison)
    fprintf('Direct training-geometry comparison (E=%d -> E=%d):\n', ...
        cdg.GeometryComparison(1).FirstExclusionBins,cdg.GeometryComparison(1).SecondExclusionBins);
    for ig=1:numel(cdg.GeometryComparison)
        gg=cdg.GeometryComparison(ig);
        fprintf('  g=%+3.0f dB: ACE ratio using M_B %.4f, using M_BT %.4f\n', ...
            gg.TargetGainDB,gg.BackgroundACESecondToFirstRatio,gg.ContaminatedACESecondToFirstRatio);
    end
end
fprintf('Cached noise transforms        : %d nominal + %d power-sweep\n', ...
    results.NumNoiseTransformsNominal,results.NumNoiseTransformsPowerSweep);

fprintf('\nAll methods use identical post-Doppler data and paired random-noise draws within each trial.\n');
fprintf('Only covariance reuse differs: Full is B=1; Block methods use B=4/8 with the same K and E.\n');
fprintf('Thresholds are fitted on H0 calibration maps and reported Pfa is measured on independent H0 validation maps.\n');
fprintf('H1 truth is used only after detection for association and error scoring.\n');
fprintf('RMSE is conditional on successful association; misses remain represented by Pd.\n');

output = struct();
output.TargetInitialRangeM = targetInitialRangeM;
output.TruthRangeM = truthRangeEqM;
output.TruthDopplerHz = truthDopplerHz;
output.UAVSpeedMps = uavSpeedMps;
output.ChannelSeed = channelSeedCommon;
output.RangeIFFTZeroPadFactor = rangeIFFTZeroPadFactor;
output.MapPfaTarget = benchmarkCfg.MapPfaTarget;
output.RangeCPLimitM = rangeCPLimitM;
output.TruthRangeToCPLimitRatio = truthRangeEqM/rangeCPLimitM;
output.ExceedsCPLimit = truthRangeEqM > rangeCPLimitM;
output.RangeResolutionM = rangeResolutionPRS;
output.DopplerGridSpacingHz = dopplerResHz;
output.RangeGridM = rangeGridNative;
output.DopplerGridHz = trackDopplerHz;
output.SpatialCutIdxNative = spatialCutIdxNative;
output.Results = results;
output.ElapsedSeconds = toc(runWallTic_);

resultDir = fullfile('results');
if ~exist(resultDir,'dir'), mkdir(resultDir); end
% K and E are in the name because they change the CUT support and therefore
% the calibrated threshold: two runs that differ only in K or E are different
% experiments and must not overwrite one another.
resultFile = fullfile(resultDir,sprintf('spatial_ace_R%d_K%d_E%d_seed%d.mat', ...
    round(targetInitialRangeM),benchmarkCfg.NumTrainingCells, ...
    benchmarkCfg.ExclusionBins,channelSeedCommon));
save(resultFile,'output');
fprintf('Saved result                  : %s\n',resultFile);
fprintf('Elapsed time                  : %.2f s\n',output.ElapsedSeconds);
end

function results = helperRunSpatialACEBenchmark_(YchainT,YchainB,sigmaChain2,Xprs, ...
    nRelPRS,fAbsPRS,tFilterDelayS,nToneRange,nIFFTRange,numRangeBins,nativeIdx, ...
    rangeGridNative,cutIdx,prsTimesS,dopplerHz,steering, ...
    truthRangeM,truthDopplerHz,truthRow,truthQ,C,baseCfg,blkCfg)
% Evaluate fixed-exclusion Full (B=1) and Block-4/8 NSCM-ACE on paired trials.
% Range/Doppler preprocessing is shared exactly. The methods differ only in
% covariance reuse. Each detector calibrates its threshold independently from
% target-free H0 MAP MAXIMA at the same requested map-level false-alarm rate.

methodNames=C.MethodNames;
nMethods=numel(methodNames);
assert(nMethods==3,'Case2:benchmarkMethodCount', ...
    'Expected Full, Block-4 and Block-8 benchmark methods.');
assert(numel(blkCfg)==2 && isequal([blkCfg.BlockSizeRangeBins],[4 8]), ...
    'Case2:benchmarkBlockConfigs','Expected block configurations [4 8].');
assert(numel(rangeGridNative)==numel(nativeIdx), ...
    'Case2:benchmarkRangeGridSize','Native range grid is inconsistent with nativeIdx.');
cutRangeM=rangeGridNative(cutIdx);

% Deterministic target and background are transformed once. Every detector
% receives the exact same post-Doppler cube for a given trial.
Tr=helperRangeCubeFromPRS(YchainT,Xprs,nRelPRS,fAbsPRS,tFilterDelayS,nToneRange,nIFFTRange,numRangeBins);
Br=helperRangeCubeFromPRS(YchainB,Xprs,nRelPRS,fAbsPRS,tFilterDelayS,nToneRange,nIFFTRange,numRangeBins);
Tr=Tr(nativeIdx,:,:);
Br=Br(nativeIdx,:,:);
[~,ZT]=helperRangeDopplerPowerMap(Tr,prsTimesS,dopplerHz);
[clutterPower,ZB]=helperRangeDopplerPowerMap(Br,prsTimesS,dopplerHz);
clutterDiag=localClutterDiagnostics_(clutterPower,rangeGridNative,dopplerHz,cutIdx,truthRow,truthQ);
% Opt-in export of the post-Doppler cubes so a (K,E) sweep can be driven
% outside this script without re-running the Monte Carlo. Nothing downstream
% reads it back; the run proceeds unchanged whether or not it is written.
if isfield(C,'DumpCubesTo') && strlength(string(C.DumpCubesTo))>0
    dumpTruthNativeIdx=cutIdx(truthRow); %#ok<NASGU>
    save(char(C.DumpCubesTo),'ZB','ZT','cutIdx','truthRow','truthQ', ...
        'steering','rangeGridNative','dopplerHz','truthRangeM','truthDopplerHz', ...
        'sigmaChain2','dumpTruthNativeIdx','-v7.3');
    fprintf('Dumped post-Doppler cubes to %s\n',char(C.DumpCubesTo));
end
leakageProfile=localTargetLeakageProfile_(ZT,truthQ,cutIdx(truthRow));
covReuseDiag=localCovarianceReuseDiagnostics_(ZB,cutIdx,truthQ,baseCfg,blkCfg,methodNames);
% The diagnostic no longer sweeps a grid of exclusion widths. It reports the
% covariance the detector in THIS run actually uses, at this run's own K and
% E, so a diagnostic number always belongs to the configuration beside it.
%
% GeometryComparison is therefore gone: it contrasted two exclusion widths
% (E=6 against production E) and has no meaning with a single E. The helper
% leaves the field empty when GeometryComparisonBins is absent, and the
% console report is already guarded on that. Comparing exclusion widths is now
% done by comparing whole runs, which is what the (K,E) matrix is for.
%
% The target-gain sweep stays: it costs three covariance estimates and
% measures how much harder a stronger target makes its own training window.
contamCfg=struct('NumTrainingCells',baseCfg.NumTrainingCells, ...
    'ExclusionBins',baseCfg.ExclusionBins, ...
    'TargetGainDB',[0 6 12], ...
    'RangeGateBins',-C.AssociationRangeBins:C.AssociationRangeBins, ...
    'DopplerGateBins',-C.AssociationDopplerBins:C.AssociationDopplerBins);
trainingContamDiag=helperTrainingContaminationDiagnostics_( ...
    ZB,ZT,cutIdx(truthRow),truthQ,steering,contamCfg);

nH0Cal=round(C.NumH0Calibration);
nH0Val=round(C.NumH0Validation);
nH1=C.NumH1Trials;
nFolds=round(C.NumCalibrationFolds);
assert(nH0Cal>=nFolds && mod(nH0Cal,nFolds)==0,'Case2:benchmarkH0Folds', ...
    'NumH0Calibration (%d) must be a positive multiple of NumCalibrationFolds (%d).',nH0Cal,nFolds);
assert(nH0Val>=1,'Case2:benchmarkH0Validation', ...
    'NumH0Validation must be positive.');
expectedFalseMaps=C.MapPfaTarget*(nH0Cal-nH0Cal/nFolds);
if expectedFalseMaps < 10
    warning('Case2:mapThresholdSupport', ...
        ['Each calibration fold permits only %.2f expected false-alarm maps at the ' ...
         'requested Pfa_map. Increase NumH0Calibration before treating the threshold as precise.'], ...
        expectedFalseMaps);
end
nTests=numel(cutIdx)*numel(dopplerHz)*size(steering,2);
state=rng; cleanup=onCleanup(@() rng(state));

% Warm up every detector once, outside the timed region, so first-call JIT
% overhead is not charged to the first method. The warm-up map is discarded.
rng(C.Seed-1,'twister');
detSeconds=zeros(1,nMethods);
[~,~,methodInfoRepresentative]=localMethodMaps_( ...
    ZB+localNoiseDraw_(sigmaChain2,YchainT,Xprs,nRelPRS,fAbsPRS,tFilterDelayS, ...
        nToneRange,nIFFTRange,numRangeBins,nativeIdx,prsTimesS,dopplerHz), ...
    cutIdx,steering,baseCfg,blkCfg);

rGate=max(1,truthRow-C.AssociationRangeBins):min(numel(cutIdx),truthRow+C.AssociationRangeBins);
qGate=max(1,truthQ-C.AssociationDopplerBins):min(numel(dopplerHz),truthQ+C.AssociationDopplerBins);

% ---------- H0 calibration ----------
% Only the maximum statistic from each target-free map is required to fit the
% map-level threshold. All methods see the same noise realization in a trial.
h0MapMax=zeros(nMethods,nH0Cal);
rng(C.Seed,'twister');
for it=1:nH0Cal
    Zn=localNoiseDraw_(sigmaChain2,YchainT,Xprs,nRelPRS,fAbsPRS,tFilterDelayS, ...
        nToneRange,nIFFTRange,numRangeBins,nativeIdx,prsTimesS,dopplerHz);
    [maps,dt]=localMethodMaps_(ZB+Zn,cutIdx,steering,baseCfg,blkCfg);
    detSeconds=detSeconds+dt;
    for m=1:nMethods
        h0MapMax(m,it)=max(maps{m},[],'all');
    end
end

% Cross-validation is a calibration-stability diagnostic. The operating
% threshold itself is fitted once to the complete calibration set.
crossVal=cell(1,nMethods);
gamma=zeros(1,nMethods);
thresholdInfo=cell(1,nMethods);
for m=1:nMethods
    crossVal{m}=helperCrossValidateMapThreshold(h0MapMax(m,:),C.MapPfaTarget,nFolds,C.CILevel);
    [gamma(m),thresholdInfo{m}]=helperCalibrateMapThreshold(h0MapMax(m,:),C.MapPfaTarget);
end

% ---------- independent H0 validation ----------
% This stream is disjoint from calibration. It is the only H0 set used to
% report Pfa_map, Pfa_cell, false alarms/map and the association-gate H0 rate.
nKeepTop=256;
h0GateMax=zeros(nMethods,nH0Val);
h0TopVals=zeros(nMethods,nH0Val,nKeepTop);
rng(C.Seed+1,'twister');
for it=1:nH0Val
    Zn=localNoiseDraw_(sigmaChain2,YchainT,Xprs,nRelPRS,fAbsPRS,tFilterDelayS, ...
        nToneRange,nIFFTRange,numRangeBins,nativeIdx,prsTimesS,dopplerHz);
    [maps,dt]=localMethodMaps_(ZB+Zn,cutIdx,steering,baseCfg,blkCfg);
    detSeconds=detSeconds+dt;
    for m=1:nMethods
        A=maps{m};
        g=A(rGate,qGate,:);
        h0GateMax(m,it)=max(g,[],'all');
        h0TopVals(m,it,:)=reshape(maxk(A(:),nKeepTop),1,1,[]);
    end
end

nFA=zeros(nMethods,nH0Val);
gateH0=false(nMethods,nH0Val);
for m=1:nMethods
    top=reshape(h0TopVals(m,:,:),nH0Val,nKeepTop);
    assert(all(top(:,end)<=gamma(m)),'Case2:h0TopValueTruncation', ...
        ['A retained top-statistic list did not reach below the operating threshold, ' ...
         'so the cell-level false-alarm count would be truncated. Increase nKeepTop.']);
    nFA(m,:)=sum(top>gamma(m),2).';
    gateH0(m,:)=h0GateMax(m,:)>gamma(m);
end

% ---------- nominal H1 ----------
% H1 uses a third deterministic stream. Thresholds are already frozen.
rng(C.Seed+2,'twister');
noiseTruthPow=zeros(1,nH1);
noiseGatePow=zeros(1,nH1);
noisePeakPow=zeros(1,nH1);
targetPeakNativeRow=leakageProfile.PeakNativeRow;

% Nominal 0 dB H1 benchmark.
nExact=zeros(1,nMethods); nAssoc=zeros(1,nMethods);
rangeErrM=nan(nMethods,nH1); dopplerErrHz=nan(nMethods,nH1);
for j=1:nH1
    Zn=localNoiseDraw_(sigmaChain2,YchainT,Xprs,nRelPRS,fAbsPRS,tFilterDelayS, ...
        nToneRange,nIFFTRange,numRangeBins,nativeIdx,prsTimesS,dopplerHz);
    [maps,dt]=localMethodMaps_(ZB+ZT+Zn,cutIdx,steering,baseCfg,blkCfg);
    detSeconds=detSeconds+dt;
    for m=1:nMethods
        est=helperAssociateACEEstimate(maps{m},gamma(m),cutRangeM,dopplerHz,truthRow,truthQ, ...
            C.AssociationRangeBins,C.AssociationDopplerBins);
        nExact(m)=nExact(m)+double(est.Exact);
        nAssoc(m)=nAssoc(m)+double(est.Associated);
        if est.Associated
            rangeErrM(m,j)=est.RangeM-truthRangeM;
            dopplerErrHz(m,j)=est.DopplerHz-truthDopplerHz;
        end
    end
    noiseTruthPow(j)=localTruthPowerPostDoppler_(Zn,cutIdx(truthRow),truthQ);
    noiseGatePow(j)=localGatePowerPostDoppler_(Zn,cutIdx(rGate),qGate);
    noisePeakPow(j)=localTruthPowerPostDoppler_(Zn,targetPeakNativeRow,truthQ);
end

pT=localTruthPowerPostDoppler_(ZT,cutIdx(truthRow),truthQ);
pB=localTruthPowerPostDoppler_(ZB,cutIdx(truthRow),truthQ);
pN=mean(noiseTruthPow(noiseTruthPow>0));
scnr0=10*log10(max(pT,realmin)/max(pB+pN,realmin));
pTGate=localGatePowerPostDoppler_(ZT,cutIdx(rGate),qGate);
pBGate=localGatePowerPostDoppler_(ZB,cutIdx(rGate),qGate);
pNGate=mean(noiseGatePow(noiseGatePow>0));
scnrGate=10*log10(max(pTGate,realmin)/max(pBGate+pNGate,realmin));
pTPeak=localTruthPowerPostDoppler_(ZT,targetPeakNativeRow,truthQ);
pBPeak=localTruthPowerPostDoppler_(ZB,targetPeakNativeRow,truthQ);
pNPeak=mean(noisePeakPow(noisePeakPow>0));
scnrPeak=10*log10(max(pTPeak,realmin)/max(pBPeak+pNPeak,realmin));
rangeSpacing=median(diff(rangeGridNative));
fractionalRangeBinOffset=abs(truthRangeM-rangeGridNative(cutIdx(truthRow)))/max(abs(rangeSpacing),realmin);
pTRangeGate=localGatePowerPostDoppler_(ZT,cutIdx(rGate),truthQ);
targetRangeGateCaptureFraction=pTRangeGate/max(sum(abs(ZT(:,truthQ,:)).^2,'all'),realmin);

R=repmat(struct,1,nMethods);
for m=1:nMethods
    validAssoc=isfinite(rangeErrM(m,:)) & isfinite(dopplerErrHz(m,:));
    R(m).Name=methodNames(m);
    R(m).Threshold=gamma(m);
    R(m).MapPfaTarget=C.MapPfaTarget;
    R(m).CalibrationPfaMap=thresholdInfo{m}.CalibrationPfaMap;
    R(m).NumH0Calibration=nH0Cal;
    R(m).CrossFittedPfaMap=crossVal{m}.CrossFittedPfaMap;
    R(m).CrossFittedPfaMapCI=crossVal{m}.CrossFittedPfaMapCI;
    R(m).CrossFittedFalseAlarmMaps=crossVal{m}.NumFalseAlarmMaps;
    R(m).NumCalibrationFolds=crossVal{m}.NumFolds;
    R(m).FoldThresholdStd=crossVal{m}.StdFoldThreshold;
    R(m).ThresholdOrderIndex=thresholdInfo{m}.OrderIndex;
    R(m).PfaCell=sum(nFA(m,:))/(nH0Val*nTests);
    R(m).PfaMap=mean(nFA(m,:)>0);
    R(m).NumFalseAlarmMaps=nnz(nFA(m,:)>0);
    R(m).NumH0Validation=nH0Val;
    R(m).MeanFalseAlarmsPerMap=mean(nFA(m,:));
    R(m).H0AssociationGateRate=mean(gateH0(m,:));
    R(m).PdExact=nExact(m)/nH1;
    R(m).PdAssociated=nAssoc(m)/nH1;
    R(m).PdExactCI=localWilsonCI_(nExact(m),nH1,C.CILevel);
    R(m).PdAssociatedCI=localWilsonCI_(nAssoc(m),nH1,C.CILevel);
    R(m).NumDetExact=nExact(m);
    R(m).NumDetAssociated=nAssoc(m);
    R(m).NumH1=nH1;
    R(m).RangeRMSEm=localRMSE_(rangeErrM(m,validAssoc));
    R(m).DopplerRMSEHz=localRMSE_(dopplerErrHz(m,validAssoc));
    R(m).NumRMSESamples=nnz(validAssoc);
end

% Target-power sweep: [-6 0 3 6 9 12] dB. The same noise realization is reused
% across all powers and all methods, so the comparison remains paired.
off=C.TargetPowerOffsetDB(:).';
for m=1:nMethods
    R(m).PdPowerSweep=zeros(size(off));
    R(m).PdPowerSweepCI=nan(numel(off),2);
    R(m).RangeRMSEPowerSweepM=nan(size(off));
    R(m).DopplerRMSEPowerSweepHz=nan(size(off));
    R(m).NumRMSESamplesPowerSweep=zeros(size(off));
end
nSweep=max(1,round(C.NumSweepTrials));
nSweepMaps=0;
if C.PowerSweepEnable
    sweepState=rng; sweepCleanup=onCleanup(@() rng(sweepState)); rng(C.Seed+1000,'twister');
    ZsweepNoise=cell(1,nSweep);
    for it=1:nSweep
        N=sqrt(sigmaChain2/2)*(randn(size(YchainT))+1j*randn(size(YchainT)));
        ZsweepNoise{it}=localNoisePostDoppler_(N,Xprs,nRelPRS,fAbsPRS,tFilterDelayS, ...
            nToneRange,nIFFTRange,numRangeBins,nativeIdx,prsTimesS,dopplerHz);
    end
    nSweepMaps=numel(off)*nSweep;
    for ip=1:numel(off)
        g=10^(off(ip)/20);
        det=zeros(nMethods,1);
        rangeErr=nan(nMethods,nSweep); dopErr=nan(nMethods,nSweep);
        for it=1:nSweep
            [maps,dt]=localMethodMaps_(ZB+g*ZT+ZsweepNoise{it},cutIdx,steering,baseCfg,blkCfg);
            detSeconds=detSeconds+dt;
            for m=1:nMethods
                est=helperAssociateACEEstimate(maps{m},gamma(m),cutRangeM,dopplerHz,truthRow,truthQ, ...
                    C.AssociationRangeBins,C.AssociationDopplerBins);
                if est.Associated
                    det(m)=det(m)+1;
                    rangeErr(m,it)=est.RangeM-truthRangeM;
                    dopErr(m,it)=est.DopplerHz-truthDopplerHz;
                end
            end
        end
        for m=1:nMethods
            R(m).PdPowerSweep(ip)=det(m)/nSweep;
            R(m).PdPowerSweepCI(ip,:)=localWilsonCI_(det(m),nSweep,C.CILevel);
            good=isfinite(rangeErr(m,:)) & isfinite(dopErr(m,:));
            R(m).RangeRMSEPowerSweepM(ip)=localRMSE_(rangeErr(m,good));
            R(m).DopplerRMSEPowerSweepHz(ip)=localRMSE_(dopErr(m,good));
            R(m).NumRMSESamplesPowerSweep(ip)=nnz(good);
        end
    end
end

nMapsEvaluated=nH0Cal+nH0Val+nH1+nSweepMaps;
cx=struct();
cx.NumTrainingCells=baseCfg.NumTrainingCells;
cx.ExclusionBins=blkCfg(1).ExclusionBins;
cx.NumCUT=numel(cutIdx);
cx.NumDoppler=numel(dopplerHz);
cx.NumMapsEvaluated=nMapsEvaluated;
cx.TimingSource='steady-state measured in this run after one untimed JIT warm-up; shared preprocessing excluded';
% repmat(struct,1,n) yields a struct array with no fields, so assigning a
% populated struct into one of its elements fails. The per-method entries are
% collected in a cell and concatenated once every field exists.
methodCx=cell(1,nMethods);
baseCov=methodInfoRepresentative{1}.NumCovarianceEstimatesPerMap;
for m=1:nMethods
    infom=methodInfoRepresentative{m};
    cm=struct();
    cm.Name=methodNames(m);
    if m==1
        cm.BlockSizeRangeBins=1;
        cm.NumBlocks=numel(cutIdx);
    else
        cm.BlockSizeRangeBins=blkCfg(m-1).BlockSizeRangeBins;
        cm.NumBlocks=infom.NumBlocks;
    end
    cm.NumCovarianceEstimatesPerMap=infom.NumCovarianceEstimatesPerMap;
    cm.NumCholeskyFactorizationsPerMap=infom.NumCholeskyFactorizationsPerMap;
    cm.CovarianceReuseFactor=baseCov/max(cm.NumCovarianceEstimatesPerMap,1);
    cm.DetectorSeconds=detSeconds(m);
    cm.SecondsPerMap=detSeconds(m)/max(nMapsEvaluated,1);
    cm.MeasuredSpeedupVsFull=detSeconds(1)/max(detSeconds(m),realmin);
    methodCx{m}=cm;
end
cx.Method=[methodCx{:}];

results=struct('Method',R,'TargetPowerOffsetDB',off);
results.MapPfaTarget=C.MapPfaTarget;
results.ClutterPowerMap=clutterPower;
results.ClutterDiagnostics=clutterDiag;
results.TargetPowerTruth=pT;
results.BackgroundPowerTruth=pB;
results.NoisePowerTruth=pN;
results.SCNR0dB=scnr0;
results.SCNRTruthCellDB=scnr0;
results.SCNRPeakCellDB=scnrPeak;
results.SCNRGateDB=scnrGate;
results.FractionalRangeBinOffset=fractionalRangeBinOffset;
results.TargetPeakNativeRow=targetPeakNativeRow;
results.TargetRangeGateCaptureFraction=targetRangeGateCaptureFraction;
results.TargetPowerGate=pTGate;
results.BackgroundPowerGate=pBGate;
results.NoisePowerGate=pNGate;
results.Complexity=cx;
results.TargetLeakageProfile=leakageProfile;
results.CovarianceReuseDiagnostics=covReuseDiag;
results.TrainingContaminationDiagnostics=trainingContamDiag;
results.RuntimeArchitecture=['shared post-Doppler data; fixed-exclusion Full (B=1) and Block-B ACE; ' ...
    'one paired noise transform per realization'];
results.NumNoiseTransformsNominal=nH0Cal+nH0Val+nH1;
results.NumNoiseTransformsPowerSweep=nSweep;
end

function diagOut = localCovarianceReuseDiagnostics_(ZB,cutIdx,truthQ,baseCfg,blkCfg,methodNames)
%localCovarianceReuseDiagnostics_ Background-only covariance mismatch at truth Doppler.
%   The Full B=1 loaded covariance is the local reference at every CUT. For
%   each Block-B method, the shared loaded covariance is compared with those
%   local references using relative Frobenius norm. This diagnostic does not
%   alter thresholds or detections; it shows how much locality is traded for
%   covariance reuse in the supplied background realization.

[nRange,~,nChain]=size(ZB);
K=baseCfg.NumTrainingCells;
E=baseCfg.ExclusionBins;
halfK=K/2;
nCut=numel(cutIdx);
assert(truthQ>=1 && truthQ<=size(ZB,2),'Case2:covDiagTruthQ', ...
    'Truth Doppler index is outside the background cube.');

localCov=cell(nCut,1);
for ic=1:nCut
    c=cutIdx(ic);
    idx=[(c-E-halfK):(c-E-1), (c+E+1):(c+E+halfK)];
    assert(idx(1)>=1 && idx(end)<=nRange && numel(idx)==K, ...
        'Case2:covDiagFullSupport','Full covariance diagnostic window is invalid.');
    Y=reshape(ZB(idx,truthQ,:),K,nChain).';
    localCov{ic}=helperShrinkageLoading(helperNSCM(Y),K);
end

diagOut=repmat(struct('Name',"",'BlockSizeRangeBins',0, ...
    'MedianRelativeFrobeniusMismatch',NaN,'P95RelativeFrobeniusMismatch',NaN, ...
    'MaxRelativeFrobeniusMismatch',NaN),1,1+numel(blkCfg));
diagOut(1).Name=methodNames(1);
diagOut(1).BlockSizeRangeBins=1;
diagOut(1).MedianRelativeFrobeniusMismatch=0;
diagOut(1).P95RelativeFrobeniusMismatch=0;
diagOut(1).MaxRelativeFrobeniusMismatch=0;

for ibCfg=1:numel(blkCfg)
    B=blkCfg(ibCfg).BlockSizeRangeBins;
    assert(blkCfg(ibCfg).NumTrainingCells==K && blkCfg(ibCfg).ExclusionBins==E, ...
        'Case2:covDiagConfigMismatch','Covariance diagnostic requires common K and E.');
    err=zeros(nCut,1);
    blockStart=1:B:nCut;
    for ib=1:numel(blockStart)
        a=blockStart(ib);
        b=min(a+B-1,nCut);
        lo=cutIdx(a); hi=cutIdx(b);
        idx=[(lo-E-halfK):(lo-E-1), (hi+E+1):(hi+E+halfK)];
        assert(idx(1)>=1 && idx(end)<=nRange && numel(idx)==K, ...
            'Case2:covDiagBlockSupport','Block covariance diagnostic window is invalid.');
        Y=reshape(ZB(idx,truthQ,:),K,nChain).';
        Mb=helperShrinkageLoading(helperNSCM(Y),K);
        for ic=a:b
            denom=max(norm(localCov{ic},'fro'),realmin);
            err(ic)=norm(Mb-localCov{ic},'fro')/denom;
        end
    end
    eSort=sort(err);
    p95=eSort(max(1,ceil(0.95*numel(eSort))));
    outIdx=1+ibCfg;
    diagOut(outIdx).Name=methodNames(outIdx);
    diagOut(outIdx).BlockSizeRangeBins=B;
    diagOut(outIdx).MedianRelativeFrobeniusMismatch=median(err);
    diagOut(outIdx).P95RelativeFrobeniusMismatch=p95;
    diagOut(outIdx).MaxRelativeFrobeniusMismatch=max(err);
end
end

function d = localClutterDiagnostics_(powerMap,rangeGridM,dopplerHz,cutIdx,truthRow,truthQ)
P=powerMap(cutIdx,:);
flat=P(:);
[peakPower,idx]=max(P,[],'all','linear');
[ir,iq]=ind2sub(size(P),idx);
sorted=sort(flat);
p95=sorted(max(1,ceil(0.95*numel(sorted))));
med=median(flat);
truthNativeIdx=cutIdx(truthRow);
d=struct;
d.PeakPower=peakPower;
d.PeakPowerDB=10*log10(max(peakPower,realmin));
d.PeakRangeM=rangeGridM(cutIdx(ir));
d.PeakDopplerHz=dopplerHz(iq);
d.MedianPower=med;
d.MedianPowerDB=10*log10(max(med,realmin));
d.P95Power=p95;
d.P95PowerDB=10*log10(max(p95,realmin));
d.PeakToMedianDB=10*log10(max(peakPower,realmin)/max(med,realmin));
d.TruthCellPower=powerMap(truthNativeIdx,truthQ);
d.TruthCellPowerDB=10*log10(max(d.TruthCellPower,realmin));
d.TotalPower=sum(P,'all');
end

function y = localRMSE_(e)
if isempty(e)
    y=NaN;
else
    y=sqrt(mean(abs(e).^2));
end
end

function ci = localWilsonCI_(k,n,confidenceLevel)
if n<=0
    ci=[NaN NaN]; return
end
alpha=1-confidenceLevel;
z=sqrt(2)*erfcinv(alpha);
phat=k/n;
den=1+z^2/n;
center=(phat+z^2/(2*n))/den;
half=z/den*sqrt(phat*(1-phat)/n+z^2/(4*n^2));
ci=[max(0,center-half) min(1,center+half)];
end

function Z = localNoisePostDoppler_(N,Xprs,nRelPRS,fAbsPRS,tFilterDelayS,nTone,nIFFT,numRangeBins,nativeIdx,prsTimesS,dopplerHz)
Nr=helperRangeCubeFromPRS(N,Xprs,nRelPRS,fAbsPRS,tFilterDelayS,nTone,nIFFT,numRangeBins);
Nr=Nr(nativeIdx,:,:);
[~,Z]=helperRangeDopplerPowerMap(Nr,prsTimesS,dopplerHz);
end

function p = localTruthPowerPostDoppler_(Z,rangeIdx,q)
y=squeeze(Z(rangeIdx,q,:));
p=sum(abs(y).^2);
end

function tf = consoleFull_(setTo)
%consoleFull_  Verbosity latch for dbg_ (see consoleVerbosity in Section 1),
%   latched once after the validationOverride block. Unset state prints everything.
    persistent lvl
    if nargin > 0
        lvl = logical(setTo);
    elseif isempty(lvl)
        lvl = true;
    end
    tf = lvl;
end


function dbg_(varargin)
%dbg_  fprintf, but printed only when consoleVerbosity is "full". No
%   computation may live in a call to it.
    if consoleFull_()
        fprintf(varargin{:});
    end
end


function [Yport, Xprs, kPRSabs, slotOfObs, meta] = helperCachedReplaySnapshots( ...
    tag, params, cacheCfg, replayFcn, K, keepFirstResource)
%helperCachedReplaySnapshots  Port-domain PRS snapshots, from disk if valid.
%   Yport is numPort x nTone x K, before any receive weight, so the cache is
%   independent of the beamformer. The full parameter struct is stored beside
%   the data and compared with isequal on load; any difference and the replay
%   runs.
    meta = struct('ChannelFilterDelay', [], 'SampleRate', [], 'res1', []);
    if cacheCfg.enable
        if ~isfolder(cacheCfg.dir)
            mkdir(cacheCfg.dir);
        end
        cacheFile = fullfile(cacheCfg.dir, sprintf('replay_%s.mat', tag));
        if isfile(cacheFile)
            S = load(cacheFile);
            if isfield(S, 'params') && isequal(S.params, params)
                Yport = S.Yport; Xprs = S.Xprs;
                kPRSabs = S.kPRSabs; slotOfObs = S.slotOfObs;
                meta = S.meta;
                fprintf('  [cache hit ] %s\n', tag);
                return
            end
            fprintf('  [cache stale] %s - parameters changed, replaying\n', tag);
            if isfield(S, 'params')
                helperDiffParamsStruct_(S.params, params, tag);
            else
                fprintf('    (cached file has no ''params'' field at all - pre-fingerprint cache format.)\n');
            end
        end
    end

    sensingOut = replayFcn();
    [Yport, Xprs, kPRSabs, slotOfObs] = helperBuildPRSArraySnapshots(sensingOut, K);
    meta.ChannelFilterDelay = sensingOut.ChannelFilterDelay;
    meta.SampleRate         = sensingOut.SampleRate;
    if keepFirstResource
        % Only the first PRS resource (the range-pipeline equivalence check
        % feeds it to the shipped helper).
        meta.res1 = sensingOut.PRSResources(1);
    end
    if cacheCfg.enable
        save(cacheFile, 'Yport', 'Xprs', 'kPRSabs', 'slotOfObs', 'meta', ...
            'params', '-v7.3');
        d = dir(cacheFile);
        fprintf('  [cache save] %s (%.0f MB)\n', tag, d.bytes/1e6);
    end
end


function helperDiffParamsStruct_(oldP, newP, tag)
%helperDiffParamsStruct_  Field-by-field explanation for WHY
%   helperCachedReplaySnapshots called a cache stale. isequal() on the whole
%   struct only ever says "not equal" - never which field, or by how much -
%   which turned one real staleness episode (2026-09) into a dead end: the
%   cache file gets overwritten with the fresh params in the SAME call, so
%   by the time anyone looks, the "old" side is gone and the mismatch is
%   unreproducible. This prints the diff INLINE, at the only moment both
%   sides still exist, so every future stale event is self-explaining
%   instead of requiring a manual before/after backup to investigate.
%   Purely diagnostic - never changes cache validity or replay behaviour.
    fieldsOld = fieldnames(oldP);
    fieldsNew = fieldnames(newP);
    onlyOld = setdiff(fieldsOld, fieldsNew);
    onlyNew = setdiff(fieldsNew, fieldsOld);
    if ~isempty(onlyOld)
        fprintf('    field(s) only in CACHED params: %s\n', strjoin(onlyOld, ', '));
    end
    if ~isempty(onlyNew)
        fprintf('    field(s) only in CURRENT params: %s\n', strjoin(onlyNew, ', '));
    end
    common = intersect(fieldsOld, fieldsNew);
    nDiff = 0;
    for i = 1:numel(common)
        f = common{i};
        vOld = oldP.(f); vNew = newP.(f);
        if isequal(vOld, vNew)
            continue
        end
        nDiff = nDiff + 1;
        if (isnumeric(vOld) || islogical(vOld)) && (isnumeric(vNew) || islogical(vNew)) && ...
                isequal(size(vOld), size(vNew))
            d = double(vNew) - double(vOld);
            fprintf('    DIFF %-16s old=%-24s new=%-24s delta=%s\n', ...
                f, mat2str(vOld, 12), mat2str(vNew, 12), mat2str(d, 6));
        else
            fprintf('    DIFF %-16s old=[%s %s] new=[%s %s] (shape/type differs)\n', ...
                f, class(vOld), mat2str(size(vOld)), class(vNew), mat2str(size(vNew)));
        end
    end
    if nDiff == 0 && isempty(onlyOld) && isempty(onlyNew)
        fprintf(['    NO FIELD DIFFERS (every common field isequal, no field ' ...
            'added/removed) - the mismatch is in isequal()/load() itself, ' ...
            'not in the params values. Tag: %s.\n'], tag);
    end
end


function Rvalid = helperRangeFromPRS(Y, X, nRel, fAbs, tFilterDelayS, ...
    nTone, nIFFT, numBins)
%helperRangeFromPRS  The post-beamforming stage of
%   helperPRSRangeProfilesResourceSniffer, replicated for deterministic
%   validation of the range-processing arithmetic. Equivalence with the
%   shipped helper is asserted at the call site.
    K = size(Y, 2);
    Rvalid = complex(zeros(numBins, K));
    for m = 1:K
        h = Y(:, m) .* conj(X(:, m)) ./ (abs(X(:, m)).^2 + eps);
        h = h .* exp(1j*2*pi*fAbs(:)*tFilterDelayS);
        Hp = zeros(nIFFT, 1);
        Hp(nRel(:) + 1) = h;
        r = ifft(Hp, nIFFT)*(nIFFT/nTone);
        Rvalid(:, m) = r(1:numBins);
    end
end


function [Yport, Xprs, kPRSabs, slotOfObs] = helperBuildPRSArraySnapshots(sensingOut, K)
%helperBuildPRSArraySnapshots  Raw multi-antenna PRS observations, in the
%   array domain before any receive beamforming - the single PRS extraction
%   point; every receive method is a linear combination of the same Yport.
%
%   Yport     numRadiatingPorts x nTone x K   complex, port domain
%   Xprs      nTone x K                       transmitted PRS symbols
%   kPRSabs   nTone x 1                       absolute subcarrier indices
%   slotOfObs 1 x K                           slot number of each occasion
%
%   The L_PRS PRS symbols of an occasion occupy interleaved, disjoint tone
%   sets, so merging them is a denser sampling in frequency (not an average);
%   the occasion still produces one slow-time sample. Cost: the tone subsets
%   are one OFDM symbol apart, an uncompensated paired echo (-20.7 dB here).
    kPRSabs = zeros(0, 1);
    for m = 1:K
        res = sensingOut.PRSResources(m);
        cols = res.prsSymbolColumns(:).';
        k_m = zeros(0, 1);  s_m = complex(zeros(0, 1));  Yrx = [];
        for c = cols
            selc = (res.lPRS == c);
            kc = double(res.kPRS(selc));
            sc = res.prsSymbols(selc);
            Yc = reshape(res.rxGrid(kc, c, :), numel(kc), []);
            k_m = [k_m; kc(:)];      %#ok<AGROW>
            s_m = [s_m; sc(:)];      %#ok<AGROW>
            Yrx = [Yrx; Yc];         %#ok<AGROW>
        end
        [k_m, ord] = sort(k_m);      % ascending absolute subcarrier
        s_m = s_m(ord);
        Yrx = Yrx(ord, :);
        assert(numel(unique(k_m)) == numel(k_m), 'Case2:prsToneCollision', ...
            ['PRS occasion %d has two symbols on the SAME subcarrier, so ' ...
             'merging them in frequency would overwrite one. This file ' ...
             'assumes the L symbols tile the comb.'], m);
        if m == 1
            kPRSabs = k_m(:);
            nPortLocal = size(Yrx, 2);
            Yport = complex(zeros(nPortLocal, numel(k_m), K));
            Xprs  = complex(zeros(numel(k_m), K));
            slotOfObs = zeros(1, K);
        end
        assert(isequal(double(k_m(:)), kPRSabs), 'Case2:prsToneSetChanged', ...
            'PRS occasion %d occupies a different tone set than occasion 1.', m);
        assert(size(Yrx, 2) == nPortLocal, 'Case2:prsPortCountChanged', ...
            'PRS occasion %d has %d ports, occasion 1 had %d.', ...
            m, size(Yrx, 2), nPortLocal);
        Yport(:, :, m) = Yrx.';
        Xprs(:, m)     = s_m(:);
        slotOfObs(m)   = res.NSlot;
    end
end


function Yprs = helperBeamformSnapshots(Yport, wrx)
%helperBeamformSnapshots  Apply one receive weight to the raw array data.
%   Yport is numPort x nTone x K, wrx is numPort x 1, Yprs is nTone x K.
    wrxU = wrx(:)/norm(wrx);
    assert(size(Yport, 1) == numel(wrxU), 'Case2:beamformPortMismatch', ...
        'The weight has %d entries but the snapshots have %d ports.', ...
        numel(wrxU), size(Yport, 1));
    Yprs = reshape(sum(conj(wrxU).*Yport, 1), size(Yport, 2), size(Yport, 3));
end


function sensingOut = helperReplayCase2(frameTx, waveformConfig, rxNoiseFigure, ...
    targets, startTime, noiseSeed, txPos, rxPos, txArray, txOrientation, ...
    rxArray, rxOrientation, fc, fs, trajectory, targetOn, backgroundOn, ...
    channelSeed, targetPowerOffsetdB, losProbability, scenarioExtentsXY)
%helperReplayCase2  One sensing replay with the baseline helpers.
%   The same frame, the same trajectory, the same channel seed and the SAME
%   noise seed every time; only the Target/Background flags differ, which is
%   what makes the offline component decomposition additive.
%   SCENARIOEXTENTSXY (optional, appended 2026-09-18): [left bottom width
%   height], forwarded to h38901ISACChannel.ScenarioExtents. Default []
%   (channel auto-computes from STX/STs/SRX) - too small for a UAV placed
%   beyond ~300 m at this file's fixed elevation ray; callers studying
%   farther ranges (Section 24g-full-real) must pass a fixed extent sized
%   for their worst-case range (Section 7's scenarioExtentsXY).
    if nargin < 21, scenarioExtentsXY = []; end
    ch = helperCreateSnifferISACChannel(txPos, rxPos, txArray, txOrientation, ...
        rxArray, rxOrientation, fc, fs, trajectory, targetOn, backgroundOn, ...
        channelSeed, targetPowerOffsetdB, scenarioExtentsXY, losProbability);
    sensingOut = helperSimulateSensingFrame(frameTx, ch, waveformConfig, ...
        rxNoiseFigure, targets, startTime, noiseSeed);
    release(ch);
end


function pos = helperDirRangeToPosition(bsPosition, bsOrientationAxes, azDeg, elDeg, rangeM)
% COPIED UNCHANGED FROM BASELINE (test_8x4panel_sniffer.m, local function).
    dirLocal = [cosd(elDeg)*cosd(azDeg); cosd(elDeg)*sind(azDeg); sind(elDeg)];
    pos = bsPosition(:) + bsOrientationAxes*(rangeM*dirLocal);
end


function [rangeEq, targetPosition, rangeTx, rangeRx] = helperTargetRangeTruth( ...
    trajectory, time, txPosition, rxPosition)
% COPIED UNCHANGED FROM BASELINE (test_8x4panel_sniffer.m, local function).
    if nargin < 4 || isempty(rxPosition)
        rxPosition = txPosition;
    end
    position = lookupPose(trajectory, time);
    targetPosition = position(:);
    rangeTx = norm(targetPosition - txPosition(:));
    rangeRx = norm(targetPosition - rxPosition(:));
    rangeEq = (rangeTx + rangeRx)/2;
end


function ST = helperApplyInitialPose(ST, trajectory)
% COPIED UNCHANGED FROM BASELINE (test_8x4panel_sniffer.m, local function).
    ST.Position = trajectory.Waypoints(1, :);
    ST.Orientation = [0 0 0];
    ST.Velocity = trajectory.Velocities(1, :);
end


function channel = helperCreateSnifferISACChannel(txPosition, rxPosition, ...
    txArray, txOrientation, rxArray, rxOrientation, carrierFrequency, ...
    sampleRate, droneTrajectory, targetEnabled, backgroundEnabled, seed, ...
    targetPowerOffsetdB, scenarioExtentsXY, losProbability)
% COPIED FROM BASELINE (test_8x4panel_sniffer.m, local function) with one
% addition: a 15th argument for LOSProbability (omitting it reproduces the
% baseline stochastic draw).
    if nargin < 13, targetPowerOffsetdB = 0; end
    if nargin < 14, scenarioExtentsXY = []; end
    if nargin < 15, losProbability = []; end

    channel = h38901ISACChannel;
    channel.SensingScenario = "ISAC-UAV";
    channel.SensingMode = "TRP-TRP Bistatic";
    channel.CommunicationScenario = "UMa-AV";
    if ~isempty(scenarioExtentsXY)
        channel.ScenarioExtents = scenarioExtentsXY;
    end
    channel.STX.Position = txPosition(:).';
    channel.STX.TransmitAntennaArray = txArray;
    channel.STX.TransmitArrayOrientation = txOrientation;
    channel.SRX.Position = rxPosition(:).';
    channel.SRX.ReceiveAntennaArray = rxArray;
    channel.SRX.ReceiveArrayOrientation = rxOrientation;
    channel.STs(1) = helperApplyInitialPose(channel.STs(1), droneTrajectory);
    channel.CenterFrequency = carrierFrequency;
    channel.SampleRate = sampleRate;
    channel.SpatialConsistency = "None";

    % Set to the h38901ISACChannel defaults, written out so the fading state
    % is visible. AbsoluteTOA = true is required for TRP-TRP bistatic (direct
    % path at its true absolute delay tau = d/c).
    channel.RCSModel      = "Model 1";     % TR 38.901 Sec 7.9.1, only model valid for ISAC-UAV
    channel.HasSmallScale = true;
    channel.FastFading    = true;
    channel.AbsoluteTOA   = true;

    channel.LOSProbability = losProbability;   % [] = baseline stochastic draw
    channel.TargetPowerOffset = targetPowerOffsetdB;
    channel.Seed = seed;
    channel.TargetChannel = targetEnabled;
    channel.BackgroundChannel = backgroundEnabled;
end


function cdl = helperCreateUECDLChannel(cdlProfile, cdlDelaySpread, ueSpeed, ...
    wavelength, carrierFrequency, sampleRate, seed, txArray, ueRxArray, ...
    uePosition, bsPosition)
% COPIED FROM BASELINE (test_8x4panel_sniffer.m, local function), reduced to
% the construction this file needs.
    cdl = nrCDLChannel;
    cdl.DelayProfile        = char(cdlProfile);
    cdl.DelaySpread         = cdlDelaySpread;
    cdl.MaximumDopplerShift = ueSpeed/wavelength;
    cdl.CarrierFrequency    = carrierFrequency;
    cdl.SampleRate          = sampleRate;
    cdl.Seed                = seed;
    cdl.TransmitAntennaArray = clone(txArray);
    cdl.ReceiveAntennaArray  = clone(ueRxArray);
    d = uePosition(:) - bsPosition(:);
    [az, el] = cart2sph(d(1), d(2), d(3));
    cdl.TransmitArrayOrientation = [rad2deg(az); -rad2deg(el); 0];
    cdl.ReceiveArrayOrientation  = [rad2deg(az) + 180; rad2deg(el); 0];
end

function [maps,dt,methodInfo] = localMethodMaps_(Z,cutIdx,steering,baseCfg,blkCfg)
%localMethodMaps_ Full (B=1) and Block-B maps from one post-Doppler cube.
%   All methods see identical data. Wall time is measured separately for each
%   detector and excludes shared range/Doppler preprocessing.
nMethods=1+numel(blkCfg);
maps=cell(1,nMethods); dt=zeros(1,nMethods); methodInfo=cell(1,nMethods);
t0=tic;
[maps{1},methodInfo{1}]=helperFullSlidingNSCMACE(Z,cutIdx,steering,baseCfg);
dt(1)=toc(t0);
for ib=1:numel(blkCfg)
    t=tic;
    [maps{1+ib},methodInfo{1+ib}]=helperBlockSharedNSCMACE(Z,cutIdx,steering,blkCfg(ib));
    dt(1+ib)=toc(t);
end
end

function D = helperTrainingContaminationDiagnostics_(ZB,ZT,cutNativeIdx,truthQ,steering,cfg)
%helperTrainingContaminationDiagnostics_ Thin wrapper around the testable helper file.
D=helperTrainingContaminationDiagnostics(ZB,ZT,cutNativeIdx,truthQ,steering,cfg);
end

function prof = localTargetLeakageProfile_(ZT,truthQ,truthNativeRow)
%localTargetLeakageProfile_ Range spread of the target at the truth Doppler.
%   Returns the per-bin target power normalized to its own peak, and the
%   half-widths at a few reference levels. These are descriptive PSF metrics
%   only; the production exclusion is not selected from a fixed relative-dB width.
P=squeeze(sum(abs(ZT(:,truthQ,:)).^2,3));
[pk,peakRow]=max(P);
PdB=10*log10(max(P,realmin)/max(pk,realmin));
prof=struct();
prof.TruthNativeRow=truthNativeRow;
prof.PeakNativeRow=peakRow;
prof.ProfileDB=PdB(:).';
prof.HalfWidthBinsAt20dB=localHalfWidth_(PdB,peakRow,-20);
prof.HalfWidthBinsAt30dB=localHalfWidth_(PdB,peakRow,-30);
prof.HalfWidthBinsAt40dB=localHalfWidth_(PdB,peakRow,-40);
prof.Criterion='descriptive target-relative PSF widths; not the exclusion-selection rule';
end

function e = localHalfWidth_(PdB,peakRow,levelDB)
above=find(PdB>levelDB);
e=max(abs(above-peakRow));
end

function p = localGatePowerPostDoppler_(Z,rangeIdx,dopIdx)
%localGatePowerPostDoppler_ Sum chain power over an explicit range-Doppler gate.
rangeIdx=rangeIdx(:).'; dopIdx=dopIdx(:).';
assert(all(rangeIdx>=1 & rangeIdx<=size(Z,1)) && all(dopIdx>=1 & dopIdx<=size(Z,2)), ...
    'Case2:gatePowerIndex','Range/Doppler gate index is outside the post-Doppler cube.');
Y=Z(rangeIdx,dopIdx,:);
p=sum(abs(Y).^2,'all');
end

function Zn = localNoiseDraw_(sigmaChain2,YchainT,Xprs,nRelPRS,fAbsPRS,tFilterDelayS, ...
    nToneRange,nIFFTRange,numRangeBins,nativeIdx,prsTimesS,dopplerHz)
%localNoiseDraw_ One thermal-noise realization, already range/Doppler transformed.
%   Drawn and transformed at the point of use rather than cached. At the map
%   counts this study needs, holding every post-Doppler noise cube in memory
%   would require tens of gigabytes. Each cube is consumed exactly once, so
%   nothing is recomputed: the work is identical, only its timing moves.
N=sqrt(sigmaChain2/2)*(randn(size(YchainT))+1j*randn(size(YchainT)));
Zn=localNoisePostDoppler_(N,Xprs,nRelPRS,fAbsPRS,tFilterDelayS, ...
    nToneRange,nIFFTRange,numRangeBins,nativeIdx,prsTimesS,dopplerHz);
end
