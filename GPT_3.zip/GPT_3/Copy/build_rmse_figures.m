function build_rmse_figures(seed,rangesM,opts)
%BUILD_RMSE_FIGURES Range and Doppler RMSE versus target power, per method.
%   Reads the per-range MAT-files the benchmark already wrote and draws the
%   RMSE curves. Nothing is recomputed.
%
%   EVERY PANEL SHARES ONE TARGET-POWER AXIS AND ONE PAIR OF RMSE LIMITS.
%   The limits are taken over all requested ranges, all methods and all power
%   points, so panels may be compared by eye without reading the ticks. The
%   requested ranges must share an identical power grid; this is asserted.
%
%   Default units are RANGE AND DOPPLER BINS, each RMSE divided by its own
%   grid spacing. That puts the two quantities on one proportional footing:
%   1.0 means "one resolution cell of error" in both panels. Physical units
%   (m, Hz) are drawn as a second overview figure.
%
%   THE RANGE AXIS IS PINNED TO ONE BIN. A range whose error genuinely
%   exceeds one bin is given an extended 1.4-bin axis rather than forcing
%   every other panel to rescale to it. That panel is labelled "axis to 1.4
%   bins" and is the one place in the figure where the shared scale does not
%   hold; it must not be compared by eye against the others.
%
%   RMSE IS CONDITIONAL ON SUCCESSFUL ASSOCIATION. Each method contributes a
%   different number of samples at each power point, and a method that only
%   associates the easy trials will look artificially accurate. The sample
%   count is drawn as a third panel, titled "Samples detected", and printed
%   on the console beside every curve, so the selection effect stays visible;
%   do not compare RMSE across methods or across ranges without it. A missing
%   point is a power offset at which that method associated nothing at all,
%   not an RMSE of zero. "Detected" here always means detected AND associated
%   with the truth cell, which is how the sweep counts it.
%
%   build_rmse_figures(seed,rangesM)
%   build_rmse_figures(seed,rangesM,struct('Scale','log'))
%     Scale : 'linear' (default) or 'log'. On 'log' the pinned one-bin range
%             axis is dropped and the global data limits are used instead,
%             because a log axis cannot start at zero.

if nargin<1 || isempty(seed), seed=41; end
if nargin<2 || isempty(rangesM), rangesM=250; end
if nargin<3 || isempty(opts), opts=struct(); end
if ~isfield(opts,'Scale'), opts.Scale='linear'; end
assert(any(strcmp(opts.Scale,{'linear','log'})), ...
    'Case2:rmseScale','Scale must be ''linear'' or ''log''.');
if ~isfield(opts,'K'), opts.K=[]; end
if ~isfield(opts,'E'), opts.E=[]; end
Kwant=opts.K; Ewant=opts.E;
resultDir='results';
rangesM=rangesM(:).';

out=cell(1,numel(rangesM));
for k=1:numel(rangesM)
    f=helperResolveResultFile(resultDir,rangesM(k),seed,Kwant,Ewant);
    S=load(f);
    assert(isfield(S,'output'),'Case2:rmseBadResult','%s has no ''output''.',f);
    out{k}=S.output;
    fprintf('Loaded %s\n',f);
end

% One shared target-power axis is only meaningful if every range was swept on
% the same grid, and one shared bin-normalised axis only if the grid spacings
% match. Both are checked rather than assumed.
off=out{1}.Results.TargetPowerOffsetDB(:).';
names=string({out{1}.Results.Method.Name});
rangeBinM=median(diff(out{1}.RangeGridM));
dopBinHz=out{1}.DopplerGridSpacingHz;
for k=2:numel(rangesM)
    assert(isequal(out{k}.Results.TargetPowerOffsetDB(:).',off), ...
        'Case2:rmsePowerGrid', ...
        ['%d m was swept on a different target-power grid than %d m; ' ...
         'a shared axis would misrepresent it.'],rangesM(k),rangesM(1));
    assert(isequal(string({out{k}.Results.Method.Name}),names), ...
        'Case2:rmseMethodSet','%d m has a different method set.',rangesM(k));
    assert(abs(median(diff(out{k}.RangeGridM))-rangeBinM)<1e-9 && ...
           abs(out{k}.DopplerGridSpacingHz-dopBinHz)<1e-9, ...
        'Case2:rmseGridSpacing', ...
        '%d m has a different range/Doppler grid spacing.',rangesM(k));
end

% Shared limits over everything that will be drawn.
allRng=[]; allDop=[]; allN=[];
for k=1:numel(rangesM)
    M=out{k}.Results.Method;
    allRng=[allRng M.RangeRMSEPowerSweepM];         %#ok<AGROW>
    allDop=[allDop M.DopplerRMSEPowerSweepHz];      %#ok<AGROW>
    allN  =[allN   M.NumRMSESamplesPowerSweep];     %#ok<AGROW>
end
lim=struct();
lim.dopBins=localAxisLimit_(allDop/dopBinHz,opts.Scale);
lim.dopPhys=localAxisLimit_(allDop,opts.Scale);
lim.n=[0 max(1,max(allN))*1.08];
lim.x=[min(off)-1.5 max(off)+1.5];
lim.capBins=1;
lim.extendedBins=1.4;

% Range axis: pinned to one bin, extended only for the panels that need it.
rngMaxBins=zeros(1,numel(rangesM));
for k=1:numel(rangesM)
    v=[out{k}.Results.Method.RangeRMSEPowerSweepM]/rangeBinM;
    v=v(isfinite(v));
    if ~isempty(v), rngMaxBins(k)=max(v); end
end
assert(all(rngMaxBins<=lim.extendedBins+1e-9),'Case2:rmseRangeCap', ...
    ['Range RMSE reaches %.3f bins at %d m, beyond the %.1f-bin extended ' ...
     'axis. Raise the cap deliberately rather than clipping data silently.'], ...
    max(rngMaxBins),rangesM(find(rngMaxBins==max(rngMaxBins),1)),lim.extendedBins);
lim.rngExtended=rngMaxBins>lim.capBins;
lim.rngPanelBins=repmat([0 lim.capBins],numel(rangesM),1);
lim.rngPanelBins(lim.rngExtended,2)=lim.extendedBins;
if strcmp(opts.Scale,'log')
    % A log axis cannot start at zero, so the pinned axis is abandoned and the
    % global data limits are used for every panel instead.
    Lg=localAxisLimit_(allRng/rangeBinM,opts.Scale);
    lim.rngPanelBins=repmat(Lg,numel(rangesM),1);
    lim.rngExtended(:)=false;
    lim.dopBins=localAxisLimit_(allDop/dopBinHz,opts.Scale);
end

figDir=fullfile(resultDir,sprintf('figures_rmse_seed%d_%s',out{1}.ChannelSeed, ...
    datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
saved={};

% ---- overview: every range on one shared pair of axes -------------------
variants={'bins','physical'};
for iv=1:numel(variants)
    fh=localOverviewFigure_(out,rangesM,off,names,variants{iv},lim, ...
        rangeBinM,dopBinHz,opts.Scale);
    b=fullfile(figDir,sprintf('figRMSE_AllRanges_%s',variants{iv}));
    exportgraphics(fh,[b '.png'],'Resolution',150); savefig(fh,[b '.fig']);
    saved{end+1}=b; %#ok<AGROW>
end

% ---- per range, drawn on the same shared limits -------------------------
for k=1:numel(rangesM)
    fh=localPerRangeFigure_(out{k},rangesM(k),off,names,lim,k, ...
        rangeBinM,dopBinHz,opts.Scale);
    b=fullfile(figDir,sprintf('figRMSE_%dM',rangesM(k)));
    exportgraphics(fh,[b '.png'],'Resolution',150); savefig(fh,[b '.fig']);
    saved{end+1}=b; %#ok<AGROW>
end

% The selection effect is the thing a reader most easily misses, so the
% supporting counts are printed rather than only drawn.
for k=1:numel(rangesM)
    M=out{k}.Results.Method;
    fprintf('\n%d m - associated detections behind each RMSE point\n',rangesM(k));
    fprintf('%-24s','offset dB:'); fprintf('%7d',off); fprintf('\n');
    for m=1:numel(M)
        fprintf('%-24s',names(m));
        fprintf('%7d',M(m).NumRMSESamplesPowerSweep);
        fprintf('   (nominal n=%d)\n',M(m).NumRMSESamples);
    end
end

fprintf('\nShared axes: target power %g..%g dB; ',lim.x(1),lim.x(2));
fprintf('Doppler RMSE %.3f..%.3f bins (%s scale)\n', ...
    lim.dopBins(1),lim.dopBins(2),opts.Scale);
fprintf('Range RMSE pinned to %.1f bin; extended to %.1f bins at: %s\n', ...
    lim.capBins,lim.extendedBins,localExtendedList_(rangesM,lim.rngExtended));
fprintf('Bin spacing: %.6f m, %.4f Hz\n',rangeBinM,dopBinHz);
for k=1:numel(saved), fprintf('  saved %s\n',saved{k}); end
fprintf('Saved %d figure(s) to %s\n',numel(saved),figDir);
end

% =========================================================================
function fh = localOverviewFigure_(out,rangesM,off,names,variant,lim, ...
    rangeBinM,dopBinHz,scaleMode)
%localOverviewFigure_ One row per range, three columns on shared scales.
nR=numel(rangesM);
isBins=strcmp(variant,'bins');
if isBins
    sR=1/rangeBinM; sD=1/dopBinHz; uR=1; uD=1;
    labR='Range RMSE (bins)'; labD='Doppler RMSE (bins)';
    dopLim=lim.dopBins;
else
    sR=1; sD=1; uR=rangeBinM; uD=dopBinHz;
    labR='Range RMSE (m)'; labD='Doppler RMSE (Hz)';
    dopLim=lim.dopPhys;
end
styles={'--o','-s','-^','-d'};

fh=figure('Name',sprintf('RMSE overview (%s) - shared axes',variant), ...
    'NumberTitle','off','Position',[60 40 1180 max(320,215*nR)]);
tl=tiledlayout(nR,3,'TileSpacing','compact','Padding','compact');

for k=1:nR
    M=out{k}.Results.Method;

    ax=nexttile; hold(ax,'on'); grid(ax,'on');
    for m=1:numel(M)
        plot(ax,off,M(m).RangeRMSEPowerSweepM*sR,styles{min(m,numel(styles))}, ...
            'LineWidth',1.4,'MarkerSize',6);
    end
    localFixAxis_(ax,off,lim.x,lim.rngPanelBins(k,:)*uR,scaleMode);
    ylabel(ax,labR);
    if ~strcmp(scaleMode,'log'), yline(ax,1*uR,':'); end
    lab=sprintf('%d m',rangesM(k));
    if lim.rngExtended(k)
        lab=sprintf('%d m  (axis to %.1f bins)',rangesM(k),lim.extendedBins);
    end
    text(ax,0.02,0.90,lab,'Units','normalized', ...
        'FontWeight','bold','BackgroundColor','w');
    if k==nR, xlabel(ax,'Target power offset (dB)'); end

    ax=nexttile; hold(ax,'on'); grid(ax,'on');
    for m=1:numel(M)
        plot(ax,off,M(m).DopplerRMSEPowerSweepHz*sD,styles{min(m,numel(styles))}, ...
            'LineWidth',1.4,'MarkerSize',6);
    end
    localFixAxis_(ax,off,lim.x,dopLim,scaleMode);
    ylabel(ax,labD);
    if ~strcmp(scaleMode,'log'), yline(ax,1*uD,':'); end
    if k==nR, xlabel(ax,'Target power offset (dB)'); end

    ax=nexttile; hold(ax,'on'); grid(ax,'on');
    for m=1:numel(M)
        plot(ax,off,M(m).NumRMSESamplesPowerSweep,styles{min(m,numel(styles))}, ...
            'LineWidth',1.4,'MarkerSize',6);
    end
    localFixAxis_(ax,off,lim.x,lim.n,'linear');
    ylabel(ax,'Samples detected');
    if k==nR, xlabel(ax,'Target power offset (dB)'); end
    if k==1
        lg=legend(ax,names,'Interpreter','none');
        lg.Layout.Tile='north';
        lg.Orientation='horizontal';
    end
end

if isBins
    extra=sprintf('1 bin = %.3f m / %.2f Hz; dotted line marks one bin',rangeBinM,dopBinHz);
else
    extra='physical units';
end
title(tl,sprintf(['Range and Doppler RMSE versus target power, seed %d - ' ...
    'shared axes across all ranges (%s)\n' ...
    'RMSE is conditional on association; a missing point means nothing was ' ...
    'associated, not zero error'],out{1}.ChannelSeed,extra));
end

% =========================================================================
function fh = localPerRangeFigure_(o,rangeM,off,names,lim,k,rangeBinM,dopBinHz,scaleMode)
%localPerRangeFigure_ Single range on the shared limits, so the saved
%   per-range files stay directly comparable with one another.
M=o.Results.Method;
styles={'--o','-s','-^','-d'};

fh=figure('Name',sprintf('Range and Doppler RMSE - %d m',rangeM), ...
    'NumberTitle','off','Position',[100 100 1180 430]);
tl=tiledlayout(1,3,'TileSpacing','compact','Padding','compact');

ax=nexttile; hold(ax,'on'); grid(ax,'on');
for m=1:numel(M)
    plot(ax,off,M(m).RangeRMSEPowerSweepM/rangeBinM,styles{min(m,numel(styles))}, ...
        'LineWidth',1.4,'MarkerSize',6);
end
localFixAxis_(ax,off,lim.x,lim.rngPanelBins(k,:),scaleMode);
if ~strcmp(scaleMode,'log'), yline(ax,1,':'); end
xlabel(ax,'Target power offset (dB)'); ylabel(ax,'Range RMSE (bins)');
if lim.rngExtended(k)
    title(ax,sprintf('Range  (1 bin = %.3f m)  -  axis extended to %.1f bins', ...
        rangeBinM,lim.extendedBins));
else
    title(ax,sprintf('Range  (1 bin = %.3f m)',rangeBinM));
end

ax=nexttile; hold(ax,'on'); grid(ax,'on');
for m=1:numel(M)
    plot(ax,off,M(m).DopplerRMSEPowerSweepHz/dopBinHz,styles{min(m,numel(styles))}, ...
        'LineWidth',1.4,'MarkerSize',6);
end
localFixAxis_(ax,off,lim.x,lim.dopBins,scaleMode);
if ~strcmp(scaleMode,'log'), yline(ax,1,':'); end
xlabel(ax,'Target power offset (dB)'); ylabel(ax,'Doppler RMSE (bins)');
title(ax,sprintf('Doppler  (1 bin = %.2f Hz)',dopBinHz));

ax=nexttile; hold(ax,'on'); grid(ax,'on');
for m=1:numel(M)
    plot(ax,off,M(m).NumRMSESamplesPowerSweep,styles{min(m,numel(styles))}, ...
        'LineWidth',1.4,'MarkerSize',6);
end
localFixAxis_(ax,off,lim.x,lim.n,'linear');
xlabel(ax,'Target power offset (dB)'); ylabel(ax,'Samples detected');
title(ax,'Samples detected');
legend(ax,names,'Location','best','Interpreter','none');

title(tl,sprintf(['%d m, seed %d - axes shared with every other range; ' ...
    'RMSE conditional on association'],rangeM,o.ChannelSeed));
end

% =========================================================================
function localFixAxis_(ax,off,xlim_,ylim_,scaleMode)
xlim(ax,xlim_); xticks(ax,off);
if strcmp(scaleMode,'log') && ylim_(1)>0
    set(ax,'YScale','log');
end
ylim(ax,ylim_);
end

% =========================================================================
function s = localExtendedList_(rangesM,mask)
if ~any(mask), s='none'; return; end
s=strjoin(arrayfun(@(r)sprintf('%d m',r),rangesM(mask),'UniformOutput',false),', ');
end

% =========================================================================
function L = localAxisLimit_(v,scaleMode)
%localAxisLimit_ Shared limits with headroom, ignoring the empty points.
v=v(isfinite(v));
if isempty(v), L=[0 1]; return; end
hi=max(v);
if strcmp(scaleMode,'log')
    lo=min(v(v>0));
    if isempty(lo) || ~(hi>0), L=[0 1]; return; end
    L=[lo/1.6 hi*1.6];
else
    L=[0 hi*1.08];
    if L(2)<=L(1), L(2)=L(1)+1; end
end
end
