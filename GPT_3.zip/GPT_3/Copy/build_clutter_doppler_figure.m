function build_clutter_doppler_figure(seed,sourceRanges,dopplerWindowHz,opts)
%BUILD_CLUTTER_DOPPLER_FIGURE Clutter power versus Doppler bin at fixed range cells.
%   Reads ClutterPowerMap out of the saved per-range MAT-files and slices it
%   along Doppler at the range cell each run's target occupies. Nothing is
%   recomputed and no replay cache is touched.
%
%   Curves are named by their SOURCE RUN, and the range cell is taken from
%   that run's own TargetPeakNativeRow (or its truth bin with Cell='truth').
%   An earlier version took ranges in metres and matched them to the nearest
%   grid bin, which silently picks the wrong cell when a target straddles:
%   at 500 m the peak bin is 160 but the truth bin is 159, and their Doppler
%   profiles differ by up to 9 dB.
%
%   THE BACKGROUND MAP IS COMMON TO EVERY RANGE RUN AT ONE SEED. Only the
%   target position changes between those runs, so the maps stored in the
%   different result files are the same realisation. This is asserted rather
%   than assumed. Consequently the curves are different range cells of ONE
%   map, not separate experiments.
%
%   EACH RUN'S OWN TARGET DOPPLER IS MARKED SEPARATELY. Runs at different UAV
%   speeds sit at different Doppler bins, so a single marker would be wrong
%   for all but one curve.
%
%   The reference curve is the maximum over the CUT support, not over all
%   native bins: localClutterDiagnostics_ restricts itself the same way and
%   the cells outside that support are never tested by any detector.
%
%   build_clutter_doppler_figure(41,[250 606],[-1000 1000])
%   build_clutter_doppler_figure(41,[603 606 612],[200 400],struct('Cell','truth'))

if nargin<1 || isempty(seed), seed=41; end
if nargin<2 || isempty(sourceRanges), sourceRanges=[606 612]; end
if nargin<3 || isempty(dopplerWindowHz), dopplerWindowHz=[200 400]; end
if nargin<4 || isempty(opts), opts=struct(); end
if ~isfield(opts,'Cell'), opts.Cell='peak'; end
assert(any(strcmp(opts.Cell,{'peak','truth'})),'Case2:clutterDopplerCell', ...
    'Cell must be ''peak'' or ''truth''.');
if ~isfield(opts,'K'), opts.K=[]; end
if ~isfield(opts,'E'), opts.E=[]; end
Kwant=opts.K; Ewant=opts.E;
resultDir='results';
sourceRanges=sourceRanges(:).';
assert(numel(dopplerWindowHz)==2 && dopplerWindowHz(2)>dopplerWindowHz(1), ...
    'Case2:clutterDopplerWindow','dopplerWindowHz must be [lo hi].');

% ---- load, and prove the maps really are the same realisation -----------
runs=struct('Label',{},'Row',{},'RangeM',{},'TruthQ',{},'TruthDopplerHz',{},'SpeedMps',{});
ref=[]; refName='';
for k=1:numel(sourceRanges)
    f=helperResolveResultFile(resultDir,sourceRanges(k),seed,Kwant,Ewant);
    o=load(f).output;
    fprintf('Loaded %s\n',f);
    if isempty(ref)
        ref=o; refName=f;
    else
        d=max(abs(ref.Results.ClutterPowerMap(:)-o.Results.ClutterPowerMap(:)));
        rel=d/max(max(abs(ref.Results.ClutterPowerMap(:))),realmin);
        assert(rel<1e-12,'Case2:clutterMapMismatch', ...
            ['%s and %s hold different clutter maps (relative %.3e). ' ...
             'They cannot be drawn as cells of one map.'],refName,f,rel);
        fprintf('  clutter map matches %s (relative difference %.2e)\n',refName,rel);
    end
    dr=median(diff(o.RangeGridM));
    if strcmp(opts.Cell,'peak')
        row=o.Results.TargetPeakNativeRow;
    else
        row=round((o.TruthRangeM-o.RangeGridM(1))/dr)+1;
    end
    [~,tq]=min(abs(o.DopplerGridHz-o.TruthDopplerHz));
    runs(end+1)=struct('Label',sprintf('R%d',sourceRanges(k)), ...
        'Row',row,'RangeM',o.RangeGridM(row),'TruthQ',tq, ...
        'TruthDopplerHz',o.TruthDopplerHz,'SpeedMps',o.UAVSpeedMps); %#ok<AGROW>
end

C=ref.Results.ClutterPowerMap;
fHz=ref.DopplerGridHz(:).';
qSel=find(fHz>=dopplerWindowHz(1) & fHz<=dopplerWindowHz(2));
assert(~isempty(qSel),'Case2:clutterDopplerEmptyWindow', ...
    'No Doppler bin falls inside [%g %g] Hz.',dopplerWindowHz);
rowIdx=[runs.Row];
assert(numel(unique(rowIdx))==numel(rowIdx),'Case2:clutterDopplerSameBin', ...
    'Two runs resolve to the same native range bin; they would overplot.');

cutIdx=ref.SpatialCutIdxNative(:).';
dB=@(x)10*log10(max(x,realmin));
cellDB=dB(C(rowIdx,qSel));
peakDB=dB(max(C(cutIdx,qSel),[],1));
for k=1:numel(runs)
    assert(any(cutIdx==runs(k).Row),'Case2:clutterDopplerOutsideCUT', ...
        '%s cell %.2f m (bin %d) lies outside the CUT support.', ...
        runs(k).Label,runs(k).RangeM,runs(k).Row);
end

% ---- figure --------------------------------------------------------------
fh=figure('Name','Clutter versus Doppler at fixed range cells', ...
    'NumberTitle','off','Position',[80 80 1120 560]);
ax=axes(fh); hold(ax,'on'); grid(ax,'on');

styles={'-o','-s','-^','-d'};
nR=numel(runs);
leg=strings(1,nR+1);
for k=1:nR
    plot(ax,qSel,cellDB(k,:),styles{min(k,numel(styles))}, ...
        'LineWidth',1.5,'MarkerSize',5);
    leg(k)=sprintf('%s: %.2f m (bin %d)',runs(k).Label,runs(k).RangeM,runs(k).Row);
end
plot(ax,qSel,peakDB,'--','Color',[0.45 0.45 0.45],'LineWidth',1.3);
leg(nR+1)=sprintf('peak over the %d CUT cells',numel(cutIdx));

% Each run sits at its own Doppler; one shared marker would be wrong.
cols=lines(nR);
for k=1:nR
    if any(qSel==runs(k).TruthQ)
        xline(ax,runs(k).TruthQ,'-.', ...
            sprintf('%s tgt %.0f Hz',runs(k).Label,runs(k).TruthDopplerHz), ...
            'Color',cols(k,:),'LabelVerticalAlignment','bottom', ...
            'LabelOrientation','horizontal','FontSize',8);
    end
end

xticks(ax,localThinTicks_(qSel));
set(ax,'TickLabelInterpreter','tex');
xticklabels(ax,arrayfun(@(q)sprintf('%d\\newline%g',q,fHz(q)), ...
    localThinTicks_(qSel),'UniformOutput',false));
xlim(ax,[qSel(1)-0.4 qSel(end)+0.4]);
xlabel(ax,'Doppler bin index (grid frequency in Hz below)');
ylabel(ax,'Clutter power (dB)');
legend(ax,leg,'Location','best','Interpreter','none');
title(ax,sprintf(['Clutter power versus Doppler, seed %d, %g to %g Hz\n' ...
    'one background realisation; curves are different range cells of the ' ...
    'same map (%s cell)'],ref.ChannelSeed,dopplerWindowHz(1), ...
    dopplerWindowHz(2),opts.Cell));

% ---- console table -------------------------------------------------------
fprintf('\nClutter power (dB), [%g %g] Hz, %s cell\n',dopplerWindowHz,opts.Cell);
show=localThinTicks_(qSel);
[~,iShow]=ismember(show,qSel);
fprintf('%-26s','Doppler bin:');    fprintf('%8d',show);        fprintf('\n');
fprintf('%-26s','frequency (Hz):'); fprintf('%8g',fHz(show));   fprintf('\n');
for k=1:nR
    fprintf('%-26s',sprintf('%s bin %d (%.1f m)',runs(k).Label,runs(k).Row,runs(k).RangeM));
    fprintf('%8.2f',cellDB(k,iShow)); fprintf('\n');
end
fprintf('%-26s','peak over CUT support'); fprintf('%8.2f',peakDB(iShow)); fprintf('\n');
fprintf('\nAt each run''s own target Doppler:\n');
for k=1:nR
    fprintf('  %-6s bin %3d, %7.2f Hz (grid %+5g Hz), UAV %5.2f m/s : %7.2f dB\n', ...
        runs(k).Label,runs(k).TruthQ,runs(k).TruthDopplerHz,fHz(runs(k).TruthQ), ...
        runs(k).SpeedMps,dB(C(runs(k).Row,runs(k).TruthQ)));
end

figDir=fullfile(resultDir,sprintf('figures_clutterdoppler_seed%d_%s', ...
    ref.ChannelSeed,datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
b=fullfile(figDir,sprintf('figClutterDoppler_%gto%gHz', ...
    dopplerWindowHz(1),dopplerWindowHz(2)));
exportgraphics(fh,[b '.png'],'Resolution',150); savefig(fh,[b '.fig']);
fprintf('\n  saved %s\n',b);
end

% =========================================================================
function t = localThinTicks_(qSel)
%localThinTicks_ Keep the axis readable when the window spans many bins.
n=numel(qSel);
if n<=20, t=qSel; return; end
step=ceil(n/16);
t=qSel(1:step:end);
if t(end)~=qSel(end), t=[t qSel(end)]; end
end
