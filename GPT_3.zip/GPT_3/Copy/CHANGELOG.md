# Change log

## 2026-09-30 (d) — diagnostic stops sweeping E; MC to 600/250

### The contamination diagnostic uses this run's own K and E

`contamCfg.ExclusionBins` was `unique([6 12 18 24 28 32 baseCfg.ExclusionBins])`
and is now simply `baseCfg.ExclusionBins`. The diagnostic reports the
covariance the detector in that run actually whitens with, so a diagnostic
number always belongs to the configuration printed beside it.

**`GeometryComparison` is now empty by construction.** It contrasted E=6
against production E and has no meaning with a single E. The field is dropped
from `contamCfg`; `helperTrainingContaminationDiagnostics` leaves
`D.GeometryComparison=[]` when `GeometryComparisonBins` is absent, and the
console report was already guarded on that. Exclusion widths are now compared
by comparing whole runs, which is what the (K,E) matrix exists for.

The target-gain sweep `[0 6 12]` dB stays: three covariance estimates, and it
measures how much a stronger target damages its own training window.

Detector, threshold calibration, Pd/Pfa/RMSE and the Full/Block-4/Block-8
logic are untouched. The diagnostic never fed thresholds or detections, so
this changes no detection result.

### Monte Carlo

`NumH0Validation` 700 → **600**, `numTrialsH1RealGeo` 300 → **250**;
`numTrialsSweep` stays 50. Maps per run 1800 → **1650**. The section-14 config
pins were updated to match.

### Planned matrix

Three configurations per range: **(48,28), (64,12), (64,28)**. (48,12) is
not run. Phase 1 (4 ranges at 19.40 m/s) = 12 runs ≈ 45 h; Phase 2 (3 ranges
at 9.18 m/s) = 9 runs ≈ 34 h; **≈ 79 h total**.

### Run in flight

R750 at K=64, E=28 started 23:04 on the 360-bin grid with 500/600/250/50. It
was launched before this diagnostic edit, so **its saved diagnostic will carry
the old six-value E sweep** while later runs carry a single E. Its Pd, Pfa and
RMSE are unaffected — the diagnostic is inert with respect to detection.

## 2026-09-30 (c) — Monte Carlo raised; R485 replaces R500 in the plan

Config only; **no range was re-run**.

| | was | now |
|---|---|---|
| `spatialAceCfg.NumH0Validation` | 500 | **700** |
| `adaptCfg.numTrialsH1RealGeo` | 200 | **300** |
| `adaptCfg.numTrialsSweep` | 50 | 50 |

Maps per run go 500 + 500 + 200 + 300 = 1500 → 500 + 700 + 300 + 300 =
**1800**, a ×1.20 runtime factor. The seven saved results were all produced at
500/200 and are not comparable on Pfa or Pd resolution either.

**The validation config pin caught this**, which is what it is for: section 14
of `validate_primary_pipeline.m` asserts the production values appear verbatim
in the main source, and `Validation:BlockConfig` fired on the first run after
the change. The pins were updated to 700 and 300 deliberately, and the error
text now names 700.

### R485 replaces R500 in the planned matrix

Prompt change only — nothing has been run. `targetInitialRangeM = 485` gives
truth **484.6121 m → native bin 155**, centre 485.7748 m. That cell carries
**−9.83 dB** of clutter: it is the clutter peak of the old support, and it is
**22.4 dB above** the next strongest cell in 400–600 m (bin 191, −32.27 dB).

R500's truth cell carried −59.46 dB, so R485 sits under roughly **49.6 dB more
clutter** at the cell to be detected. This is a different problem, not a 15 m
shift of R500, and low Pd there is the measurement rather than a fault.

Bin 155 lies inside the new support at all four (K,E) combinations.

### Cost of the planned campaign

With 1800 maps per run and the 360-bin supports: Phase 1 (4 ranges ×
K{48,64} × E{28,12}) ≈ **64 h**, Phase 2 (3 ranges at 9.18 m/s) ≈ **48 h**,
**≈ 112 h total**, up from 94 h.

## 2026-09-30 (b) — range grid raised to 360 native bins

`maxRangeOfInterest` 1050 → **1134 m**, giving
`floor(1134/3.154382)+1 = 360` native bins over 0 … 1132.42 m (was 333 over
0 … 1047.25 m). Code only; **no range was re-run**.

**The replay cache stays valid.** `maxRangeOfInterest` does not enter the
fingerprint, which is built from `scenarioExtentsXY` — itself derived from the
separate `scenarioExtentsMaxRangeM = 750`. Confirmed by measurement: the
verification run completed in 319 s on the existing R250 cache with no cold
replay.

With the block margin already removed, the common support becomes:

| K | E | CUT | n | span |
|---|---|---|---|---|
| 64 | 28 | 61–300 | 240 | 189.26 – 943.16 m |
| 64 | 12 | 45–316 | 272 | 138.79 – 993.63 m |
| 48 | 28 | 53–308 | 256 | 164.03 – 968.40 m |
| 48 | 12 | 37–324 | 288 | 113.56 – 1018.87 m |

Verified end to end at K=64, E=28: 360 grid bins, `SpatialCutIdxNative` =
61:300, 240 cells.

### What the extended window pulls in — measured, and it matters

The widened support now contains two clutter cells at **842.22 m (−7.89 dB)**
and **870.61 m (−7.93 dB)**. Both are **stronger than the −9.83 dB cell at
485.77 m** that every earlier report called the clutter peak; they were simply
outside the old 211–836 m support. `ClutterDiagnostics` on the new
configuration reports `PeakRangeM` = 842.22 m and `PeakPowerDB` = −7.89, with
peak-to-median rising from 47.11 to 48.83 dB.

Because the ACE threshold is calibrated from H0 map maxima, a stronger cell
inside the support raises the threshold. **Expect Pd to fall relative to the
199-CUT results.** That is a consequence of the configuration, not a fault.

Neither the scenario box nor the channel changed: `scenarioExtentsMaxRangeM`
is still 750 m, so the map beyond roughly 780 m was always present in the
333-bin grid. What changed is only which cells the detector is allowed to
test.

`tests.run_validation()`: 46 rows, none over tolerance.

## 2026-09-30 — CUT support dropped the block margin; results named by K and E

Code only. **No range was re-run**; every saved result still belongs to the
199-CUT regime and is byte-identical to before this change.

### The (maxBlockSize-1) margin is gone

`spatialHalfWindow` is now `E + K/2`, with no block term. Reading the
executable asserts: `helperBlockSharedNSCMACE` binds only on its first block
(`lo = cutIdx(1)`) and its last (`hi = cutIdx(end)`), so its two asserts
reduce to the pair `helperFullSlidingNSCMACE` already applies and the block
size never enters. The old margin cost 7 bins at each edge for B=8.

At K=64, E=28 the common support goes from **68–266 (199 CUT)** to
**61–273 (213 CUT)**, widening coverage from 211.34–835.91 m to
**189.26–857.99 m**, a gain of 44.16 m.

Verified end to end on the warm R250 cache: `numel(SpatialCutIdxNative) = 213`,
first and last CUT `[61 273]`, truth bin inside, `UAVSpeedMps = 19.4000`,
`TruthDopplerHz = 634.1718`.

### New validation check, measured rather than read

`+tests/validate_primary_pipeline.m` builds the support at its exact
theoretical edge `1+E+K/2 : nRange-E-K/2` and requires **all three methods to
run there**, then moves the lower edge out one bin and requires **all three to
refuse**. Recorded as two counts, both 3. A reinstated B-1 margin fails the
first half; a block helper that began constraining interior blocks fails the
second. Validation is now 46 rows, none over tolerance.

### Results are named by K and E

`spatial_ace_R<range>_K<K>_E<E>_seed<seed>.mat`. K and E change the CUT support
and therefore the calibrated threshold, so runs differing only in K or E are
different experiments; the old name let them overwrite one another silently.

`helperResolveResultFile.m` resolves either naming for the five figure
scripts. **It never guesses**: with K and E it requires that exact file;
without them it accepts a single match, and raises `Case2:resultFileAmbiguous`
listing the candidates when several exist. Unit-tested on all five branches.

`build_clutter_figures` and `build_tradeoff_figures` take optional trailing
`K,E`; `build_rmse_figures`, `build_clutter_doppler_figure` and
`build_target_psf_figure` take `opts.K` / `opts.E`. Existing calls are
unchanged while only the legacy files are present.

### Diagnostic exclusion sweep no longer loses E=28

The list was `unique([6 12 18 24 baseCfg.ExclusionBins 32])`, which silently
dropped 28 whenever production E was not 28 — a run at E=12 would have had no
diagnostic column at the production exclusion. Now
`unique([6 12 18 24 28 32 baseCfg.ExclusionBins])`.

### Housekeeping

`checkcode` over the ten touched files: 18 warnings before, **12 after**, and
a diff against the pre-change backups confirms none of the 12 is new.

## 2026-09-29 — (B,K,E) sweep, TDD replica identified, K asserts relaxed

### Code changes

- **`K > nChain` relaxed to `K >= 2`** in `helperFullSlidingNSCMACE`,
  `helperBlockSharedNSCMACE` and `helperTrainingContaminationDiagnostics`.
  It was a statistical rule of thumb, not an implementation requirement:
  `helperNSCM` normalises each snapshot to norm `sqrt(N)`, so `trace(M)=N` and
  `tau=1` for every K, and `helperShrinkageLoading` then adds `lambda*tau*I`
  with `lambda>0`. Verified numerically: `chol` succeeds at K = 8, 16, 24, 32,
  40, 48, 64, 96, and at K = 32 = N the NSCM is still full rank 32.
  **The estimator is unchanged**; `helperNSCM` and `helperShrinkageLoading`
  were not touched, and every Cholesky positive-definiteness assert remains.
- **`K >= 2N` in the main script relaxed** to an even/positive check plus a
  `Case2:benchmarkBelowRMB` warning. Its comment claimed full rank was the
  hard requirement; full rank needs `K >= N`, and positive definiteness after
  loading needs nothing. It was the RMB reference point, not a constraint.
- **Opt-in cube export** added via `validationOverride.dumpCubesTo`. Writes
  `ZB`, `ZT`, steering, CUT indices and truth indices after the range-Doppler
  stage. Nothing downstream reads it back.
- `tests.run_validation()` re-run after all four edits: every check within
  tolerance, including `Test B Block-1 equals fixed-exclusion Full` = 0 and
  all `training geometry violations` = 0.

### New scripts

- `sweep_KE_contamination.m` — drives the production detectors and the
  production contamination diagnostic over B in {1,4,8}, K in {32,48,64,96},
  E in {6,12,18,24,28,32}. 72 configurations, minutes rather than hours.
- `build_clutter_doppler_figure.m` — clutter power versus Doppler bin at
  chosen range cells, with each run's own target Doppler marked separately.
- `build_rmse_figures.m` rewritten: one shared target-power axis, shared RMSE
  limits in bin units, a `Samples detected` panel, and a range axis pinned to
  one bin that extends to 1.4 bins only for the panels that need it.

### Measured

- Full 72-configuration sweep in `results/sweep_KE_R250_seed41.mat` and
  `..._full.csv`. Pd, Pfa_map and RMSE are **not** included: the Monte Carlo
  for the 17 feasible (K,E) cells costs about 53 hours and was deferred.
- Cross-check: at the production point (K=64, E=28) the sweep returns
  `R_ACE = 0.8792`, identical to the value in the existing R250 result.
- **Shrinkage loading falls as 1/K** exactly as the formula predicts:
  7.82e-05 at K=32 to 2.89e-05 at K=96.
- **Condition number rises with K**, 250k to 645k, the opposite of the
  white-noise intuition. Real clutter covariance is near-singular; small K is
  loaded more heavily and therefore looks better conditioned. The number
  measures regularisation, not quality.
- At E=6 the two contamination metrics disagree in their K direction. The
  absolute ACE values resolve it: `ACE(M_B)` rises with K (0.4026 to 0.5645)
  while `ACE(M_BT)` falls (0.3911 to 0.3014). At a narrow exclusion a larger
  training window is **absolutely** worse, not merely relatively.
- At E=28, K=48 gives the highest absolute contaminated ACE (0.4437) ahead of
  the production K=64 (0.4272). This is **not** a Pd claim: ACE is normalised
  and the threshold is recalibrated per configuration.

### The 400 Hz structure is a TDD gating replica, not clutter

- `slotOfObs` takes 4 slots out of every 5 (`mod 10 = [0 1 2 3 5 6 7 8]`).
  With PRF = 2000 Hz that puts replicas at PRF/5 = 400 Hz.
- The full-span clutter slice confirms it: local maxima at bins 9, 25, 41, 57
  and 73, that is -800, -400, 0, +400, +800 Hz, spaced exactly 16 bins. The
  four sidebands lie within 0.76 dB of one another, about 12 dB below the 0 Hz
  peak. That regularity is a periodic gating comb, not physical scatterers.
- Consequence for the failed 300 Hz runs: the 9.18 m/s target sits on the
  inner skirt of the +400 Hz replica, while the 19.4 m/s runs at 634 Hz sit in
  the valley between +400 and +800.
- The SCNR gap between R250 and R605.6 decomposes exactly:
  16.45 dB from target strength plus 9.90 dB from clutter equals the measured
  26.35 dB. This is the first clean separation of the two contributions.

### Corrections made this session

- The reference curve in the first clutter-Doppler figure used the peak over
  all 333 native bins (+5.98 dB at 91 m, a cell no detector tests). Changed to
  the peak over the 199 CUT cells, matching `localClutterDiagnostics_`.
- `build_clutter_doppler_figure` originally took ranges in metres and matched
  the nearest grid bin. At 500 m that silently picks bin 160 (peak) instead of
  bin 159 (truth), whose Doppler profiles differ by up to 9 dB. It now takes
  source runs and reads each run's own `TargetPeakNativeRow`.
- A two-line tick label written with a literal newline was split by MATLAB
  into separate labels, shifting every label off its tick. Uses `\newline`.
- "The 400 Hz replica appears identically in all three cells" was measured
  over cells spanning under 10 m. Over 350 m the replica strength varies
  strongly with range: from 700 to 800 Hz the 599 m cell rises 12.13 dB, the
  249 m cell 3.10 dB, and the 501 m cell falls 0.84 dB. The uniformity claim
  is local only.

## 2026-09-27 — four ranges measured, contamination predictor identified

- Ran 250, 500, 600 and 750 m at seed 41 on the warm replay cache, about
  2.6 hours each. Results in `results/spatial_ace_R{250,500,600,750}_seed41.mat`.
- **Regression is clean.** 250, 500 and 600 m reproduce the previous package
  exactly: same Pd, same trial counts, same thresholds to every printed digit,
  same RMSE and SCNR. The detector rewrite and the diagnostic layer are
  numerically neutral.
- `tests.run_validation()` executed for the first time in an environment that
  supplies the project helpers: **44 measured checks, all passing**, including
  zero-target neutrality of the contamination diagnostic.
- The methods separate only at 250 m (0.945 / 0.915 / 0.825). At 500, 600 and
  750 m everything saturates and Block-8 gives equal detection for about 4.5x
  less detector time.
- Second before-and-after for the leakage-aware Full: 750 m goes 0.93 to 1.000,
  against 0.38 to 0.945 at 250 m. The small gain at 750 m is consistent with
  its contamination diagnostic, which shows almost nothing to fix there.
- **`TrainingTargetToBackgroundDB` is the predictor of contamination.** It
  orders all four ranges perfectly (-46.2, -49.0, -56.9, -62.6 dB against ACE
  ratios 0.555, 0.733, 0.948, 0.980). SCNR does not: 500 m has a worse SCNR
  than 600 m but far more contamination. Fractional offset does not: 750 m and
  500 m straddle almost identically and sit at opposite ends.
- Recorded a prediction that failed: 750 m was expected to resemble 500 m
  because of its similar straddle, and measured cleaner than 600 m instead.
  Straddle does not reliably widen the range response; at 500 m the
  neighbouring bin is 0.2 dB below the peak, at 750 m it is 10.5 dB below.
- `GeometryComparison` shows the pure locality effect stays within about 8% of
  unity at every range, and is above unity at 500 and 750 m, so "more local is
  better" is not general. Almost all of the 250 m benefit from widening E is
  removal of signal from the training data, +2.00 dB.
- Exclusion saturates when the target is strong: at 250 m no swept E reaches a
  0.5 dB loss tolerance at g = +6 or +12 dB. `E = 28` is supported at nominal
  power and no reduction is recommended.
- The previous package's 26.2 s/map Full anomaly at 500 m did not reproduce
  here (3.852 s/map on the same cached data), ruling out the 500 m data as its
  cause.


## Current revision

- Kept the production comparison at Full (`B=1`), Block-4 and Block-8 with
  common `K=64` and fixed `E=28`.
- Removed the claim that `E=28` is selected or validated by a `-40 dB`
  target-relative PSF width. That width is now descriptive only.
- Added `helperTrainingContaminationDiagnostics.m` to separate:
  - total covariance perturbation;
  - inverse-covariance sensitivity;
  - steering-direction perturbation;
  - production ACE change;
  - adaptive SINR loss.
- Added truth/peak/gate SCNR reporting, fractional range-bin offset and target
  energy capture in the association gate.
- Kept calibration and independent H0 validation separate.
- Kept the common CUT support based on the strictest Block-8 geometry.
- Added validation of the new diagnostic formulas and zero-target neutrality.
- Replaced stale runner checks with checks of the files actually delivered and
  explicit checks for required project helpers on the MATLAB path.
- Removed development backup/log folders from the distribution.
