function estimate = helperAssociateACEEstimate(statMap,threshold,cutRangeM,dopplerHz, ...
    truthRow,truthQ,associationRangeBins,associationDopplerBins)
%helperAssociateACEEstimate Associate one ACE detection to the known truth gate.
%   This helper is for evaluation only. Truth is used only to define the
%   association gate after detection. If more than one threshold crossing is
%   inside the gate, the cell with the largest ACE statistic is selected.
%   The returned range and Doppler are the actual detector-grid coordinates;
%   no sub-bin interpolation or truth-directed peak fitting is performed.

validateattributes(statMap,{'single','double'},{'nonempty','real','finite'});
assert(ndims(statMap)==3,'Case2:associationStatDims', ...
    'statMap must be Ncut-by-Ndoppler-by-Nangle.');
validateattributes(threshold,{'numeric'},{'scalar','real','finite'});
cutRangeM=cutRangeM(:);
dopplerHz=dopplerHz(:).';
assert(numel(cutRangeM)==size(statMap,1),'Case2:associationRangeGrid', ...
    'cutRangeM length must match statMap range dimension.');
assert(numel(dopplerHz)==size(statMap,2),'Case2:associationDopplerGrid', ...
    'dopplerHz length must match statMap Doppler dimension.');
assert(truthRow>=1 && truthRow<=size(statMap,1) && truthQ>=1 && truthQ<=size(statMap,2), ...
    'Case2:associationTruthIndex','Truth index is outside the ACE map.');

detectionStrength=max(statMap,[],3);
hitMap=detectionStrength>threshold;
rGate=max(1,truthRow-associationRangeBins):min(size(statMap,1),truthRow+associationRangeBins);
qGate=max(1,truthQ-associationDopplerBins):min(size(statMap,2),truthQ+associationDopplerBins);

estimate=struct('Associated',false,'Exact',logical(hitMap(truthRow,truthQ)), ...
    'RangeRow',NaN,'DopplerIndex',NaN,'RangeM',NaN,'DopplerHz',NaN, ...
    'ACEStatistic',NaN);

localHits=hitMap(rGate,qGate);
if ~any(localHits,'all')
    return
end
localStrength=detectionStrength(rGate,qGate);
localStrength(~localHits)=-Inf;
[peakValue,linearIndex]=max(localStrength,[],'all','linear');
[ir,iq]=ind2sub(size(localStrength),linearIndex);
rSel=rGate(ir);
qSel=qGate(iq);
estimate.Associated=true;
estimate.RangeRow=rSel;
estimate.DopplerIndex=qSel;
estimate.RangeM=cutRangeM(rSel);
estimate.DopplerHz=dopplerHz(qSel);
estimate.ACEStatistic=peakValue;
end
