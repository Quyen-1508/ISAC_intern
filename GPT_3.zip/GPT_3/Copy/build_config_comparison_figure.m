function build_config_comparison_figure(seed,rangeLabel,KE,resultDir)
%BUILD_CONFIG_COMPARISON_FIGURE Pd and RMSE versus target power across (K,E).
%   One column per (K,E) configuration of one range, three rows:
%
%     Pd (associated)       from PdPowerSweep
%     range RMSE   (bins)   from RangeRMSEPowerSweepM / range bin
%     Doppler RMSE (bins)   from DopplerRMSEPowerSweepHz / Doppler bin
%
%   Each panel carries the three methods. Every row shares one y-axis across
%   the columns, so a configuration's effect is read straight across a row.
%
%   ALL CURVES ARE THE POWER SWEEP, 50 trials per point. The nominal headline
%   Pd (250 trials at 0 dB) is drawn as a hollow marker at 0 dB so the two
%   estimates of the same quantity can be compared; they differ only by
%   Monte Carlo noise.
%
%   RMSE IS CONDITIONAL ON ASSOCIATION. A missing RMSE point means no trial
%   was associated at that power, not zero error, and RMSE across configs
%   with very different Pd is computed on different trial subsets.
%
%   Every configuration must share the power grid; this is asserted. They do
%   NOT share the CUT support (it depends on K and E), so Pd differences
%   between columns include the threshold change that support size causes.
%
%   build_config_comparison_figure(41,750,[64 28; 64 12; 48 28])
%   build_config_comparison_figure(41,200,[],'results/Data')

if nargin<1 || isempty(seed), seed=41; end
if nargin<2 || isempty(rangeLabel), rangeLabel=750; end
if nargin<3 || isempty(KE), KE=[64 28; 64 12; 48 28]; end
if nargin<4 || isempty(resultDir), resultDir='results'; end
nC=size(KE,1);

out=cell(1,nC);
for c=1:nC
    f=helperResolveResultFile(resultDir,rangeLabel,seed,KE(c,1),KE(c,2));
    out{c}=load(f).output;
    fprintf('Loaded %s\n',f);
end

off=out{1}.Results.TargetPowerOffsetDB(:).';
names=string({out{1}.Results.Method.Name});
rb=median(diff(out{1}.RangeGridM));
db=out{1}.DopplerGridSpacingHz;
for c=2:nC
    assert(isequal(out{c}.Results.TargetPowerOffsetDB(:).',off),'Case2:cfgPowerGrid', ...
        'Configuration %d was swept on a different power grid.',c);
    assert(isequal(string({out{c}.Results.Method.Name}),names),'Case2:cfgMethods', ...
        'Configuration %d has a different method set.',c);
end

% Shared limits per row.
allR=[]; allD=[];
for c=1:nC
    M=out{c}.Results.Method;
    allR=[allR M.RangeRMSEPowerSweepM]/1; %#ok<AGROW>
    allD=[allD M.DopplerRMSEPowerSweepHz]; %#ok<AGROW>
end
limR=[0 max(1,max(allR(isfinite(allR)))/rb*1.12)];
limD=[0 max(1,max(allD(isfinite(allD)))/db*1.12)];
limX=[min(off)-1.5 max(off)+1.5];

styles={'--o','-s','-^'};
cols=[0.10 0.45 0.95; 0.85 0.33 0.10; 0.93 0.69 0.13];

fh=figure('Name',sprintf('R%d config comparison',rangeLabel), ...
    'NumberTitle','off','Color','w','Position',[50 40 1300 860]);
tl=tiledlayout(fh,3,nC,'TileSpacing','compact','Padding','compact');

for row=1:3
    for c=1:nC
        o=out{c}; M=o.Results.Method;
        ax=nexttile(tl,(row-1)*nC+c); hold(ax,'on'); grid(ax,'on');
        for m=1:numel(M)
            switch row
                case 1, y=M(m).PdPowerSweep;
                case 2, y=M(m).RangeRMSEPowerSweepM/rb;
                case 3, y=M(m).DopplerRMSEPowerSweepHz/db;
            end
            plot(ax,off,y,styles{m},'Color',cols(m,:),'LineWidth',1.5, ...
                'MarkerSize',6,'MarkerFaceColor',cols(m,:));
        end
        xlim(ax,limX); xticks(ax,off);
        switch row
            case 1
                % Headline Pd: 250 trials at nominal power.
                for m=1:numel(M)
                    plot(ax,0,M(m).PdAssociated,'o','Color',cols(m,:), ...
                        'MarkerSize',11,'LineWidth',1.4,'HandleVisibility','off');
                end
                ylim(ax,[0 1.05]); yline(ax,1,':','HandleVisibility','off');
                title(ax,sprintf('K = %d,  E = %d   |   %d CUT', ...
                    KE(c,1),KE(c,2),numel(o.SpatialCutIdxNative)),'FontWeight','bold');
                if c==1, ylabel(ax,'P_D (associated)'); end
            case 2
                ylim(ax,limR); yline(ax,1,':','HandleVisibility','off');
                if c==1, ylabel(ax,'range RMSE (bins)'); end
            case 3
                ylim(ax,limD); yline(ax,1,':','HandleVisibility','off');
                if c==1, ylabel(ax,'Doppler RMSE (bins)'); end
                xlabel(ax,'target power offset (dB)');
        end
        if row==1 && c==nC
            lg=legend(ax,names,'Interpreter','none','Orientation','horizontal');
            lg.Layout.Tile='north';
        end
    end
end

title(tl,sprintf(['R%d, seed %d — P_D and RMSE versus target power across ' ...
    '(K,E)'],rangeLabel,seed),'FontWeight','bold');
nSw=out{1}.Results.Method(1).PdPowerSweepCI; %#ok<NASGU>
nH1=out{1}.Results.Method(1).NumH1;
subtitle(tl,sprintf(['duong = sweep (50 trial/diem); vong rong tai 0 dB = P_D ' ...
    'chinh (%d trial)  |  1 bin = %.3f m / %.2f Hz  |  RMSE co dieu kien ' ...
    'theo association'],nH1,rb,db),'FontSize',8);

% ---- console ------------------------------------------------------------
fprintf('\nR%d sweep P_D, offsets %s dB\n',rangeLabel,mat2str(off));
for c=1:nC
    M=out{c}.Results.Method;
    fprintf(' (K=%d,E=%d) %d CUT\n',KE(c,1),KE(c,2),numel(out{c}.SpatialCutIdxNative));
    for m=1:numel(M)
        fprintf('   %-22s %s | chinh %.4f\n',M(m).Name,num2str(M(m).PdPowerSweep,'%6.2f'), ...
            M(m).PdAssociated);
    end
end

figDir=fullfile('results',sprintf('figures_configcmp_seed%d_%s',seed, ...
    datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
b=fullfile(figDir,sprintf('figConfigCompare_R%d',rangeLabel));
exportgraphics(fh,[b '.png'],'Resolution',150); savefig(fh,[b '.fig']);
fprintf('\n  saved %s\n',b);
end
