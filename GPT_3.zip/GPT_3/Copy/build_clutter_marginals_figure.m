function build_clutter_marginals_figure(seed,rangeLabel,K,E)
%BUILD_CLUTTER_MARGINALS_FIGURE Clutter power along range and along Doppler.
%   Two panels from the saved ClutterPowerMap of one run. Nothing is
%   recomputed.
%
%     left  : clutter power versus RANGE bin, taken over Doppler
%     right : clutter power versus DOPPLER bin, taken over range
%
%   EACH PANEL SHOWS TWO REDUCTIONS, because one alone misleads. The maximum
%   says where the worst cell is and is what sets a map-maximum threshold;
%   the median says what a typical cell faces. A peak 40 dB above the median
%   is a point scatterer, whereas a peak 3 dB above it is a raised floor, and
%   only plotting one of the two cannot tell those apart.
%
%   REDUCTIONS RUN OVER THE CUT SUPPORT, not the whole grid. Cells outside
%   `SpatialCutIdxNative` are never tested by any detector, and including
%   them would report a peak the study never sees — over the full 360-bin
%   grid the maximum sits at 91 m, outside every support used here.
%
%   build_clutter_marginals_figure(41,750,64,28)

if nargin<1 || isempty(seed), seed=41; end
if nargin<2 || isempty(rangeLabel), rangeLabel=750; end
if nargin<3, K=[]; end
if nargin<4, E=[]; end
resultDir='results';

f=helperResolveResultFile(resultDir,rangeLabel,seed,K,E);
o=load(f).output;
fprintf('Loaded %s\n',f);

C=o.Results.ClutterPowerMap;
rM=o.RangeGridM(:).';
fHz=o.DopplerGridHz(:).';
cut=o.SpatialCutIdxNative(:).';
[nR,nD]=size(C);
assert(numel(rM)==nR && numel(fHz)==nD,'Case2:marginalGrid', ...
    'Saved grids do not match the clutter map.');
dB=@(x)10*log10(max(x,realmin));

% Range marginal: reduce over Doppler, report only the CUT rows.
rMax=dB(max(C(cut,:),[],2)).';
rMed=dB(median(C(cut,:),2)).';
% Doppler marginal: reduce over the CUT rows at each Doppler bin.
dMax=dB(max(C(cut,:),[],1));
dMed=dB(median(C(cut,:),1));

truthRow=o.Results.TargetLeakageProfile.TruthNativeRow;
[~,truthQ]=min(abs(fHz-o.TruthDopplerHz));
lo=min([rMed dMed])-3; hi=max([rMax dMax])+3;

fh=figure('Name',sprintf('Clutter marginals R%d K%d E%d',rangeLabel, ...
    o.Results.TrainingContaminationDiagnostics.NumTrainingCells, ...
    o.Results.TrainingContaminationDiagnostics.ExclusionBins(1)), ...
    'NumberTitle','off','Color','w','Position',[70 70 1280 500]);
tl=tiledlayout(fh,1,2,'TileSpacing','compact','Padding','compact');

% ---- range panel ---------------------------------------------------------
ax=nexttile(tl); hold(ax,'on'); grid(ax,'on');
plot(ax,cut,rMax,'-','LineWidth',1.3,'Color',[0.85 0.33 0.10]);
plot(ax,cut,rMed,'-','LineWidth',1.1,'Color',[0.10 0.45 0.95]);
xline(ax,truthRow,'-.',sprintf('truth %.0f m',o.TruthRangeM), ...
    'Color',[0.15 0.55 0.15],'LabelVerticalAlignment','bottom','FontSize',8);
[~,ipk]=max(rMax);
plot(ax,cut(ipk),rMax(ipk),'kv','MarkerFaceColor','k','MarkerSize',7);
text(ax,cut(ipk),rMax(ipk)+2.5,sprintf(' %.2f dB @ %.0f m',rMax(ipk),rM(cut(ipk))), ...
    'FontSize',8,'HorizontalAlignment','center');
ylim(ax,[lo hi]); xlim(ax,[cut(1) cut(end)]);
xlabel(ax,sprintf('range bin  (1 bin = %.3f m)',median(diff(rM))));
ylabel(ax,'clutter power (dB)');
title(ax,sprintf('vs RANGE bin  |  CUT %d-%d  (%.0f-%.0f m)', ...
    cut(1),cut(end),rM(cut(1)),rM(cut(end))));
legend(ax,{'max qua Doppler','median qua Doppler'},'Location','northwest','FontSize',8);

% ---- Doppler panel -------------------------------------------------------
ax=nexttile(tl); hold(ax,'on'); grid(ax,'on');
plot(ax,1:nD,dMax,'-','LineWidth',1.3,'Color',[0.85 0.33 0.10]);
plot(ax,1:nD,dMed,'-','LineWidth',1.1,'Color',[0.10 0.45 0.95]);
% TDD gating takes 4 of every 5 slots, so the Doppler point spread carries a
% comb at PRF/5 = 400 Hz. Marking it keeps those peaks from being read as
% physical scatterers.
for fr=[-800 -400 0 400 800]
    [dd,q]=min(abs(fHz-fr));
    if dd<=median(diff(fHz))/2
        xline(ax,q,':',sprintf('%+g',fr),'Color',[0.6 0.1 0.1], ...
            'LabelVerticalAlignment','top','FontSize',7);
    end
end
xline(ax,truthQ,'-.',sprintf('target %.0f Hz',o.TruthDopplerHz), ...
    'Color',[0.15 0.55 0.15],'LabelVerticalAlignment','bottom','FontSize',8);
ylim(ax,[lo hi]); xlim(ax,[1 nD]);
xlabel(ax,sprintf('Doppler bin  (1 bin = %.2f Hz)',o.DopplerGridSpacingHz));
ylabel(ax,'clutter power (dB)');
title(ax,sprintf('vs DOPPLER bin  |  rut gon tren %d o CUT',numel(cut)));
legend(ax,{'max qua range','median qua range'},'Location','northwest','FontSize',8);

title(tl,sprintf(['Clutter power marginals — R%d, seed %d, %d x %d map, ' ...
    'rut gon tren CUT support'],rangeLabel,o.ChannelSeed,nR,nD),'FontWeight','bold');
subtitle(tl,'cham do = replica TDD tai boi so cua PRF/5 = 400 Hz','FontSize',8);

% ---- console -------------------------------------------------------------
fprintf('\nRANGE: dinh %.2f dB tai bin %d (%.2f m) | median toan dai %.2f dB\n', ...
    rMax(ipk),cut(ipk),rM(cut(ipk)),median(rMed));
fprintf('       tai o truth bin %d: max %.2f dB\n',truthRow,rMax(cut==truthRow));
[~,jpk]=max(dMax);
fprintf('DOPPLER: dinh %.2f dB tai bin %d (%+g Hz) | median %.2f dB\n', ...
    dMax(jpk),jpk,fHz(jpk),median(dMed));
fprintf('         tai Doppler target bin %d (%+.1f Hz): max %.2f dB\n', ...
    truthQ,o.TruthDopplerHz,dMax(truthQ));

figDir=fullfile(resultDir,sprintf('figures_cluttermarg_seed%d_%s',o.ChannelSeed, ...
    datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
b=fullfile(figDir,sprintf('figClutterMarginals_R%d',rangeLabel));
exportgraphics(fh,[b '.png'],'Resolution',150); savefig(fh,[b '.fig']);
fprintf('\n  saved %s\n',b);
end
