function build_clutter_figures(seed,rangesM,Kwant,Ewant)
%BUILD_CLUTTER_FIGURES Target-free range-Doppler clutter power from saved results.
%   Draws the same figure run_two_ranges produces, but from the per-range
%   MAT-files, so a range run made by calling the benchmark directly still
%   gets its clutter diagnostic. Nothing is recomputed.
%
%   The clutter map is upstream of the detector: it is the background-only
%   replay, identical for every method, so it explains the scene rather than
%   any detector result. Several ranges are drawn on one common colour scale
%   taken from the CUT support, which is the only region any detector scores.

if nargin<1 || isempty(seed), seed=41; end
if nargin<2 || isempty(rangesM), rangesM=250; end
% Kwant/Ewant pick one (K,E) run when several are saved for a range; leave
% them empty when only one exists. helperResolveResultFile refuses to guess.
if nargin<3, Kwant=[]; end
if nargin<4, Ewant=[]; end
resultDir='results';

out=cell(1,numel(rangesM));
for k=1:numel(rangesM)
    f=helperResolveResultFile(resultDir,rangesM(k),seed,Kwant,Ewant);
    S=load(f);
    assert(isfield(S,'output'),'Case2:clutterBadResult','%s has no ''output''.',f);
    out{k}=S.output;
    fprintf('Loaded %s\n',f);
end

% A shared colour scale is only meaningful on a shared grid.
for k=2:numel(out)
    assert(isequal(out{k}.RangeGridM,out{1}.RangeGridM) && ...
           isequal(out{k}.DopplerGridHz,out{1}.DopplerGridHz), ...
        'Case2:clutterGridMismatch','Ranges use different range-Doppler axes.');
end

clutterDB=cell(1,numel(rangesM)); allDB=[];
for k=1:numel(rangesM)
    clutterDB{k}=10*log10(max(out{k}.Results.ClutterPowerMap,realmin));
    v=clutterDB{k}(out{k}.SpatialCutIdxNative,:);
    allDB=[allDB; v(isfinite(v))]; %#ok<AGROW>
end
commonClim=[min(allDB) max(allDB)];
if commonClim(2)<=commonClim(1), commonClim=commonClim+[-0.5 0.5]; end

if numel(rangesM)<2
    figName=sprintf('Range-Doppler clutter power - %d m only',rangesM(1));
else
    figName='Range-Doppler clutter power - all ranges';
end
fh=figure('Name',figName,'NumberTitle','off', ...
    'Position',[100 100 560*numel(rangesM)+140 560]);
tiledlayout(1,numel(rangesM),'TileSpacing','compact','Padding','compact');
for k=1:numel(rangesM)
    nexttile;
    imagesc(out{k}.DopplerGridHz,out{k}.RangeGridM,clutterDB{k}); axis xy;
    cutIdx=out{k}.SpatialCutIdxNative;
    ylim([out{k}.RangeGridM(cutIdx(1)) out{k}.RangeGridM(cutIdx(end))]);
    clim(commonClim); colorbar; hold on;
    plot(out{k}.TruthDopplerHz,out{k}.TruthRangeM,'wx','LineWidth',1.5,'MarkerSize',10);
    xlabel('Doppler (Hz)'); ylabel('Equivalent bistatic range (m)');
    d=out{k}.Results.ClutterDiagnostics;
    title(sprintf('%d m: peak %.1f dB, truth cell %.1f dB', ...
        rangesM(k),d.PeakPowerDB,d.TruthCellPowerDB));
end
sgtitle(sprintf('Target-free clutter power, seed %d (dB, CUT support)', ...
    out{1}.ChannelSeed));

for k=1:numel(rangesM)
    d=out{k}.Results.ClutterDiagnostics;
    fprintf(['%d m: peak %.2f dB at %.1f m / %+.0f Hz | median %.2f | ' ...
        'P95 %.2f | truth cell %.2f\n'],rangesM(k),d.PeakPowerDB,d.PeakRangeM, ...
        d.PeakDopplerHz,d.MedianPowerDB,d.P95PowerDB,d.TruthCellPowerDB);
end

figDir=fullfile(resultDir,sprintf('figures_clutter_seed%d_%s',out{1}.ChannelSeed, ...
    datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
if ~exist(figDir,'dir'), mkdir(figDir); end
b=fullfile(figDir,sprintf('figClutter_%s',strjoin(string(rangesM),'_')));
exportgraphics(fh,[b '.png'],'Resolution',150);
savefig(fh,[b '.fig']);
fprintf('  saved %s\n',b);
end
