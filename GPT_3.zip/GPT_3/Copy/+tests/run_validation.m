function report = run_validation()
%RUN_VALIDATION Entry point for deterministic primary-pipeline validation.
report=tests.validate_primary_pipeline();
end
