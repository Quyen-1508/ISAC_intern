# Prompt công việc — chạy hai giai đoạn trên máy mới

- **Giai đoạn 1** (mục 0–10): 4 range ở **19.40 m/s**, **12** lần chạy, ~45 h.
- **Giai đoạn 2** (mục 11–16): 3 range ở **9.18 m/s**, **9** lần chạy, ~34 h.

Tổng ~79 giờ. Hai giai đoạn dùng hai vận tốc khác nhau và có hai quy tắc
**ngược nhau** về `uavSpeedMps` — đọc mục 0 và mục 11 trước khi chạy bất cứ gì.

**Phần sửa code đã hoàn tất ngày 2026-09-30 trên máy gốc.** Việc của máy mới
là *xác minh* code nhận được đã có các thay đổi đó (mục 3), rồi chạy. **Không
sửa lại, không làm lại.**

Bối cảnh: **máy khác, KHÔNG có replay cache**. Mọi range đều phải replay lạnh.

---

## 0. CẢNH BÁO ĐẦU TIÊN — VẬN TỐC UAV

**Ở GIAI ĐOẠN 1: KHÔNG truyền `uavSpeedMps`. Không sửa dòng 84. Không
"chuẩn hoá" nó về giá trị khác.** (Giai đoạn 2 ngược lại — bắt buộc truyền
9.18; xem mục 11. Đừng áp quy tắc của giai đoạn này sang đó.)

```matlab
% dòng 84, GIỮ NGUYÊN
requestedUavSpeedMps = 19.4;   % 2026-09-23: moved off the 400 Hz TDD replica line
```

19.4 m/s **được chọn có chủ đích**. Ở 4.9 GHz nó cho Doppler 634.17 Hz, nằm
trong thung lũng giữa hai replica TDD ở +400 và +800 Hz. Giá trị 9.18 m/s —
dùng cho nhóm R603/R606/R612 — cho 300 Hz, **trên sườn replica +400 Hz**, và
cả ba run ở vận tốc đó đều cho **Pd = 0.0000**. Chạy nhầm 9.18 m/s ở Giai
đoạn 1 thì 49 giờ máy ra toàn số 0.

### Vì sao sai vận tốc là phá hoại chứ không chỉ sai kết quả

Thư mục cache khoá theo **`round(targetInitialRangeM)` mà thôi** (dòng 357),
nhưng dấu vân tay replay **có chứa `uavSpeed`** (dòng 606). Sai vận tốc ⇒ vân
tay lệch ⇒ replay lạnh ⇒ **ghi đè cache của range đó**. Đã xảy ra thật ngày
2026-09-30: chạy 603 thay vì 602.5 (cùng làm tròn về nhãn "R603") đã huỷ cache
602.5 m và tốn một replay lạnh 56 phút.

---

## 1. Khối tham số KHOÁ CỨNG

Giai đoạn 1 chỉ được truyền **ba** trường:

```matlab
out = Detection_Case2_SpatialACE_Benchmark(struct( ...
    'targetInitialRangeM', <200|485|600|750>, ...
    'spatialAceNumTrainingCells', <48|64>, ...
    'spatialAceExclusionBins',    <28|12>));
```

Mọi thứ khác để nguyên mặc định. Kiểm trước khi chạy:

| tham số | dòng | giá trị bắt buộc |
|---|---|---|
| `requestedUavSpeedMps` | 84 | **19.4** |
| `channelSeedCommon` | 71 | 41 |
| `sensingNoiseSeed` | 72 | 300 |
| `dataSeedBase` | 73 | 100 |
| `adaptCfg.seed` | 112 | 20260913 |
| `refBeamElDeg` | 365 | 20.168 |
| `carrierFrequency` | 17 | 4.9e9 |
| `subcarrierSpacing` | 18 | 30 |
| `channelBandwidth` | 19 | 50 |
| `rangeIFFTZeroPadFactor` | 58 | 1 |
| `minRangeOfInterest` | 59 | 30 |
| `maxRangeOfInterest` | 65 | **1134** (cho 360 native bin) |
| `spatialAceCfg.NumTrainingCells` | 92 | 64 (mặc định; override khi cần 48) |
| `spatialAceCfg.ExclusionBins` | 98 | 28 (mặc định; override khi cần 12) |
| `spatialAceCfg.MapPfaTarget` | 104 | 0.10 |
| `NumH0Calibration` / `NumH0Validation` | 105–106 | 500 / **600** |
| `NumCalibrationFolds` | 107 | 10 |
| `associationRangeBins` / `DopplerBins` | 108–109 | 1 / 1 |
| `numTrialsH1RealGeo` | 114 | **250** |
| `numTrialsSweep` | 115 | 50 |
| `targetPowerOffsetDB` | 116 | [-6 0 3 6 9 12] |
| `BlockSizesRangeBins` | 101 | [4 8] |

**Tuyệt đối không** truyền `uavSpeedMps`, `channelSeedCommon`,
`sensingNoiseSeed`, `adaptNumTrials*`, `targetPowerOffsetDB`,
`spatialAceNumH0*` cho các lần chạy thật. Chúng chỉ dùng ở cổng kiểm mục 7,
và lần đó **không** tính là kết quả.

---

## 2. Điều kiện môi trường

1. Helper của project mẹ phải trên path: tối thiểu `helperNSCM`,
   `helperShrinkageLoading`, `helperRangeCubeFromPRS`,
   `helperRangeDopplerPowerMap` (có trong `external_required/`), cộng
   `helperGet5GWaveformConfiguration`, `helperCachedReplaySnapshots`,
   `helperBeamformSnapshots`, `helperGenerateISACFrame`,
   `helperSimulateSensingFrame`, `helperTDDSlotDirection`,
   `helperTDDSymbolTypes`, `helperPDSCHFullSymbolReservedRE`.
2. Toolbox: 5G Toolbox, Phased Array System Toolbox.
3. **Đĩa trống ≥ 3 GB** cho cache: 7 range × 308 MB ≈ 2.2 GB (4 range ở Giai
   đoạn 1, thêm 3 ở Giai đoạn 2).
4. Ghi lại `version` và `ver` của MATLAB vào báo cáo. RNG dùng `'twister'` với
   seed cố định nên tất định trong cùng phiên bản; khác phiên bản có thể lệch.

---

## 3. Code ĐÃ SỬA — xác minh, không làm lại

Năm thay đổi dưới đây đã nằm trong bản code bạn nhận. Chạy các lệnh kiểm và
**dừng lại nếu có mục nào không khớp** — nghĩa là bạn đang cầm bản cũ.

| # | thay đổi | cách kiểm | kết quả đúng |
|---|---|---|---|
| 1 | Bỏ margin `(maxBlockSize-1)` | `grep -n "spatialHalfWindow=" Detection_Case2_SpatialACE_Benchmark.m` | dòng 879, chỉ còn `benchmarkCfg.ExclusionBins` + `NumTrainingCells/2` |
| 2 | `maxBlockSize` thành biến chết, đã xoá | `grep -n "maxBlockSize" ...` | chỉ còn xuất hiện trong comment |
| 3 | Tên file kết quả có K và E | `grep -n "spatial_ace_R%d_K%d_E%d" ...` | có, quanh dòng 1029 |
| 4 | Diagnostic KHÔNG quét lưới E | `grep -n "'ExclusionBins',baseCfg" ...` | có, quanh dòng 1090; và `grep "6 12 18 24"` phải **không ra gì** |
| 5 | Assert K đã nới cho K=48 | `grep -n "K>=2,'Case2:"` trên 3 helper | `helperFullSlidingNSCMACE:48`, `helperBlockSharedNSCMACE:64`, `helperTrainingContaminationDiagnostics:58` |
| 6 | Lưới range nâng lên 360 bin | `grep -n "^maxRangeOfInterest=" ...` | dòng 65, giá trị **1134** (không phải 1050) |
| 7 | Monte Carlo đã nâng | `grep -n "NumH0Validation=\|numTrialsH1RealGeo=" ...` | **600** (dòng 106) và **250** (dòng 114), không phải 500 và 200 |

Thêm: `Detection_Case2_SpatialACE_Benchmark.m:825` phải là
`mod(...,2)==0 && ...>=2` kèm `warning('Case2:benchmarkBelowRMB')`, **không**
phải `assert(K >= 2*nActiveRx)`. Bản cũ sẽ chặn K=48.

Và phải có file mới `helperResolveResultFile.m` trong thư mục gói.

---

## 4. Hình học sau thay đổi

`numNativeBins = 360` (nâng từ 333 ngày 2026-09-30):

| K | E | half | **CUT** | **n** | |
|---|---|---|---|---|---|
| 64 | 28 | 60 | **61–300** | **240** | chạy |
| 64 | 12 | 44 | 45–316 | 272 | chạy |
| 48 | 28 | 52 | 53–308 | 256 | chạy |
| 48 | 12 | 36 | 37–324 | 288 | *(không chạy)* |

Đã kiểm end-to-end trên máy gốc ở K=64/E=28: `numel(SpatialCutIdxNative)=240`,
`[61 300]`, tâm 189.26 … 943.16 m.

---

## 5a. R485 — target đặt thẳng lên đỉnh clutter

Đây là range thay cho R500, và nó **không phải một thay thế tương đương**.

`targetInitialRangeM = 485` cho truth **484.6121 m → native bin 155**, tâm
485.7748 m. Ô đó có clutter **−9.83 dB**, đúng bằng đỉnh clutter của support
cũ, và cao hơn ô mạnh thứ nhì trong dải 400–600 m tới **22.4 dB** (bin 191 ở
−32.27 dB).

Để so sánh, ô truth của R500 cũ có clutter −59.46 dB. R485 vì vậy có **nhiều
hơn khoảng 49.6 dB clutter** ngay tại ô cần phát hiện. Đây là một bài toán
khác hẳn về bản chất, không phải "R500 dịch đi 15 m".

**Dự kiến Pd thấp, có thể bằng 0 ở công suất danh nghĩa.** Đó là điều đang
được đo, không phải dấu hiệu chạy sai. Bin 155 nằm trong support mới ở cả ba cấu hình (K,E) được chạy — đã kiểm.

---

## 5. R200 chỉ đo được nhờ thay đổi này

Truth ước tính: **199.6121 m → native bin 64** (độ lệch initial→truth đo được
là 0.3879 m, nhất quán ở cả bốn range 19.4 m/s đã chạy).

| cấu hình | cận dưới CŨ | cận dưới MỚI | bin 64 |
|---|---|---|---|
| K=64, E=28 | 68 | 61 | **ngoài support cũ, trong support mới** |
| K=64, E=12 | 52 | 45 | trong cả hai |
| K=48, E=28 | 60 | 53 | trong cả hai |
| K=48, E=12 | 44 | 37 | trong cả hai |

Ở cấu hình production K=64/E=28, R200 **không đo được** với support cũ.
Bin 64 chỉ cách cận dưới mới 3 bin, nên cổng kiểm mục 7 là bắt buộc.

---

## 6. Chạy validation (check mới đã có sẵn)

```matlab
addpath(genpath(pwd));
report = tests.run_validation();
```

**Đọc bảng trả về**, không đọc dòng thông báo cuối. Kỳ vọng:

- **46 dòng**;
- không dòng nào có `Measured > Tolerance`, trừ các dòng `Metric` chứa
  "target" (đó là tỷ lệ so với đích, không phải sai số);
- hai dòng này phải đúng bằng 3:

```
Methods running at the B-independent support edge    3    3    method count
Methods refusing one bin beyond that edge            3    3    method count
```

Check đó dựng support ở đúng biên `1+E+K/2 : nRange-E-K/2`, đòi cả ba method
chạy được, rồi lùi biên một bin và đòi cả ba từ chối. Nó hỏng nếu margin B−1
quay lại hoặc helper Block đổi ràng buộc.

---

## 7. CỔNG KIỂM BẮT BUỘC trước khi cam kết 45 giờ

Chạy **một** lần R200 với Monte Carlo tối thiểu (đây là replay lạnh, ~1 giờ):

```matlab
out = Detection_Case2_SpatialACE_Benchmark(struct( ...
    'targetInitialRangeM',200, ...
    'spatialAceNumTrainingCells',64, 'spatialAceExclusionBins',28, ...
    'spatialAceNumH0Calibration',30, 'spatialAceNumH0Validation',10, ...
    'spatialAceNumCalibrationFolds',3, ...
    'adaptNumTrialsH1RealGeo',1, 'adaptNumTrialsSweep',1, ...
    'targetPowerOffsetDB',0));
```

Đối chiếu từng dòng:

| đại lượng | giá trị bắt buộc | nếu sai |
|---|---|---|
| `out.UAVSpeedMps` | **19.4000** | sai vận tốc — DỪNG, xem mục 0 |
| `out.TruthDopplerHz` | **634.172 Hz** | sai vận tốc hoặc sai tần số sóng mang |
| `out.TruthRangeM` | ≈ **199.6121** | sai hình học hoặc sai dwell offset |
| `numel(out.SpatialCutIdxNative)` | **240** | đang cầm bản code cũ — xem mục 3 |
| `out.SpatialCutIdxNative([1 end])` | **[61 300]** | như trên |
| truth bin nằm trong CUT | **true** | R200 ngoài tầm |
| `out.ChannelSeed` | **41** | sai seed |

`634.172 Hz` là bất biến mạnh nhất: cả bốn run 19.4 m/s đã lưu đều cho đúng
giá trị này bất kể range. **Thấy ~300 Hz nghĩa là đang chạy 9.18 m/s — dừng.**

Lần kiểm này ghi ra `spatial_ace_R200_K64_E28_seed41.mat`. Xoá file đó trước
khi chạy thật, nếu không nó sẽ bị lần chạy thật cùng cấu hình ghi đè (không
mất mát, nhưng đừng để nhầm lẫn).

**Báo cáo bảng trên trước khi bắt đầu 12 lần chạy.**

---

## 8. Ma trận Giai đoạn 1

4 range × **3 cấu hình** (K,E) = **12 lần chạy**, tất cả ở vận tốc mặc định
19.4 m/s (không truyền).

Ba cấu hình: **(48,28)**, **(64,12)**, **(64,28)**.
**(48,12) KHÔNG chạy.**

| range | `targetInitialRangeM` | cache |
|---|---|---|
| R200 | 200 | không — replay lạnh |
| **R485** | **485** | không — replay lạnh |
| R600 | 600 | không — replay lạnh |
| R750 | 750 | không — replay lạnh |

Vân tay cache không chứa K/E, nên **mỗi range chỉ replay lạnh một lần**. Chạy
**theo range**: xong cả bốn (K,E) của R200 rồi mới sang R485.

K = 48 phát `warning('Case2:benchmarkBelowRMB')` — đúng thiết kế, không phải
lỗi.

Kết quả tự ghi ra `spatial_ace_R<range>_K<K>_E<E>_seed41.mat`, không đè nhau.

### Chi phí

|                | số lần | ước tính |
|---                  |---|---     |
| replay lạnh         | 4 | ~3.5 h |
| K=64/E=28 (240 CUT) | 4 | 14.1 h |
| K=64/E=12 (272 CUT) | 4 | 16.0 h |
| K=48/E=28 (256 CUT) | 4 | 11.8 h |

**Tổng ≈ 45 giờ.**

**Rủi ro đã biết**: một replay lạnh ở 850 m từng mất **19715 s (5.5 h)**, gấp
6 lần các range khác, nguyên nhân chưa bao giờ tìm ra. R750 là range xa nhất
nên có thể dính. Nếu replay R750 vượt 2 giờ, **dừng và báo cáo** thay vì để
chạy tiếp.

---

## 9. Hệ quả phải nói rõ trong báo cáo

**Kết quả cũ và mới không so sánh được.** Ngưỡng ACE hiệu chuẩn từ cực đại bản
đồ H0; đổi số ô làm cực đại dịch, kéo theo ngưỡng, Pfa và **Pd**. Bảy file
trong `results/` của gói gốc thuộc chế độ 199 CUT và **không** so được với bất
kỳ kết quả nào của bạn.

Ba cấu hình (K,E) cho ba số CUT khác nhau (240/272/256), nên **ngay
trong bộ mới cũng không so trực tiếp Pd giữa các cấu hình (K,E)**. Chỉ so
được: giữa các range trong cùng một (K,E), và giữa ba method trong cùng một
lần chạy.

Khi dựng figure, các script sẽ hỏi K và E nếu một range có nhiều kết quả:
`build_clutter_figures(seed,ranges,K,E)` và
`build_tradeoff_figures(seed,ranges,K,E)`; còn `build_rmse_figures`,
`build_clutter_doppler_figure`, `build_target_psf_figure` nhận `opts.K` và
`opts.E`. `helperResolveResultFile` **không đoán** — nhiều match thì nó ném
`Case2:resultFileAmbiguous` và liệt kê.

`truthRow` đổi theo; `TruthNativeRow` không đổi.

Vùng phủ ở K=64/E=28 đi từ 211.34–835.91 m (199 CUT) lên **189.26–943.16 m
(240 CUT)**, do hai thay đổi cộng lại: bỏ margin B−1 (+22.08 m ở đầu gần) và
nâng lưới lên 360 bin (+107.25 m ở đầu xa).

**Hệ quả đo được, cần biết trước:** vùng mở rộng chứa hai ô clutter mạnh ở
842.22 m (−7.89 dB) và 870.61 m (−7.93 dB), **mạnh hơn** đỉnh −9.83 dB ở
485.77 m vốn được coi là đỉnh. Ở cấu hình mới, `ClutterDiagnostics.PeakRangeM`
chuyển từ 485.77 m sang **842.22 m** và `PeakPowerDB` từ −9.83 sang **−7.89**.
Ngưỡng ACE hiệu chuẩn từ cực đại bản đồ H0 nên nhiều khả năng ngưỡng tăng và
**Pd giảm so với chế độ cũ**. Đó là hệ quả của cấu hình, không phải lỗi.

---

## 10. Thứ tự thực hiện — Giai đoạn 1

1. Kiểm môi trường (mục 2), ghi lại phiên bản MATLAB.
2. Kiểm khối tham số khoá cứng (mục 1), **đặc biệt dòng 84 = 19.4**.
3. **Xác minh năm thay đổi code (mục 3). Dừng nếu lệch.**
4. Chạy `tests.run_validation()`, đọc bảng (mục 6).
5. **Cổng kiểm R200 (mục 7). Báo cáo bảng đối chiếu. Dừng nếu lệch.**
6. Chạy 16 lần thật, theo từng range.
7. Báo cáo kết quả trước khi sang Giai đoạn 2.

---

# GIAI ĐOẠN 2 — ba range ở 9.18 m/s

Chỉ bắt đầu **sau khi** 12 lần chạy của Giai đoạn 1 xong và đã báo cáo.

## 11. ĐẢO NGƯỢC QUY TẮC VẬN TỐC — đọc kỹ

Mục 0 cấm truyền `uavSpeedMps`. **Lệnh cấm đó chỉ áp dụng cho Giai đoạn 1.**

Ở đây thì ngược lại: **BẮT BUỘC truyền `uavSpeedMps = 9.18`** cho cả ba range.
Quên là chúng chạy ở mặc định 19.4 m/s — sai Doppler, sai cache, và ghi đè
cache của chính range đó.

| | vận tốc | Doppler | vị trí so với replica TDD |
|---|---|---|---|
| Giai đoạn 1 | 19.40 m/s | 634.172 Hz | thung lũng giữa +400 và +800 Hz |
| Giai đoạn 2 | 9.18 m/s | 300.088 Hz | **trên sườn replica +400 Hz** |

Đây là mục đích của Giai đoạn 2: đo cùng ba detector ở một Doppler nằm trong
vùng bị replica làm bẩn.

## 12. BẪY TÊN RANGE — `targetInitialRangeM` KHÔNG phải nhãn file

Nhãn file là `round(targetInitialRangeM)`, nên "R603" **không** nghĩa là 603.

| nhãn | `targetInitialRangeM` BẮT BUỘC | truth m | native bin |
|---|---|---|---|
| R603 | **602.5** | 602.3164 | 192 |
| R606 | **605.6** | 605.4164 | 193 |
| R612 | **612.0** | 611.8164 | 195 |

Truyền 603 thay vì 602.5 tạo kịch bản khác nhưng ghi vào **cùng thư mục
cache**. Đã xảy ra thật ngày 2026-09-30.

Cả ba bin 192/193/195 nằm trong support mới ở cả ba cấu hình (K,E) được chạy — đã kiểm.

## 13. Ma trận Giai đoạn 2

3 range × **3 cấu hình** (K,E) = **9 lần chạy**, cùng ba cấu hình như Giai
đoạn 1; **(48,12) không chạy**.

```matlab
out = Detection_Case2_SpatialACE_Benchmark(struct( ...
    'targetInitialRangeM', <602.5|605.6|612.0>, ...
    'uavSpeedMps', 9.18, ...                        % BẮT BUỘC ở giai đoạn này
    'spatialAceNumTrainingCells', <48|64>, ...
    'spatialAceExclusionBins',    <28|12>));
```

Bốn trường, không hơn. Chạy theo từng range.

## 14. Cổng kiểm Giai đoạn 2

Trước 9 lần chạy thật, chạy một lần R603 với Monte Carlo tối thiểu (giống
mục 7 nhưng thêm `'uavSpeedMps',9.18` và `'targetInitialRangeM',602.5`):

| đại lượng | giá trị bắt buộc | nếu sai |
|---|---|---|
| `out.UAVSpeedMps` | **9.1800** | quên truyền uavSpeedMps — DỪNG |
| `out.TruthDopplerHz` | **300.0876 Hz** | sai vận tốc — DỪNG |
| `out.TargetInitialRangeM` | **602.500** | truyền nhầm 603 — DỪNG |
| `out.TruthRangeM` | **602.3164** | như trên |
| `numel(out.SpatialCutIdxNative)` | **240** | ở K=64/E=28 |
| `out.SpatialCutIdxNative([1 end])` | **[61 300]** | như trên |

**300.0876 Hz là bất biến của giai đoạn này**, như 634.172 Hz là bất biến của
Giai đoạn 1. Thấy 634 Hz nghĩa là quên truyền vận tốc.

## 15. Chi phí Giai đoạn 2

| | số lần | ước tính |
|---|---|---|
| replay lạnh | 3 | ~2.6 h |
| benchmark, 3 cấu hình × 3 range | 9 | ~31.5 h |

**Giai đoạn 2 ≈ 34 giờ. Cộng Giai đoạn 1 ≈ 79 giờ tổng cộng.**

## 16. Kỳ vọng kết quả — nói trước để khỏi hiểu nhầm

Ở support cũ 199 CUT, cả ba range này cho **Pd = 0.0000** ở công suất danh
nghĩa (R603 có 0.00/0.02/0.05; R606 và R612 bằng 0 cả ba method). Chỉ từ +3
đến +9 dB trong dải quét mới bắt đầu có detection.

Support mới có nhiều ô hơn nên ngưỡng cao hơn. **Dự kiến Pd danh nghĩa vẫn
bằng 0, có thể kém hơn chút.** Đó không phải dấu hiệu chạy sai — thông tin nằm
ở dải quét công suất và các chỉ số contamination, không ở Pd danh nghĩa.

Đại lượng đáng đọc nhất của Giai đoạn 2 là **so sánh E=28 với E=12 ở cùng K**:
ba range này nằm trên vành clutter mạnh, nên đây là chỗ exclusion hẹp có khả
năng lộ ra khác biệt rõ nhất.


